# Individual Neural Holonomy

Code for the five-stage computational analysis accompanying the manuscript **“Individual neural holonomy: Retention–protention coupling and history-dependent transport.”**

## Requirements

Python 3.11 or 3.12.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

On Windows, activate the environment with `.venv\Scripts\activate`.

## Tests

```bash
python scripts/run_embedded_tests.py
```

## Full analysis

```bash
python scripts/run_analysis.py
```

The analysis runs Stages 1–5 in order and writes generated results and logs to `integrated/results/` and `integrated/qc/`. All data used by the analysis are synthetic; the repository contains no human, animal, or externally acquired neural data.

## Licence

MIT. See `LICENSE`.
