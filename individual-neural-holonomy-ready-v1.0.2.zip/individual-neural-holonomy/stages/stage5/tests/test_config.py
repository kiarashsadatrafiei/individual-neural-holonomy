from inh_stage5.config import Stage5Config
from inh_stage5.cli import build_parser


def test_locked_config_validates():
    Stage5Config().validate()


def test_cli_bootstrap_default_matches_locked_config():
    args = build_parser().parse_args([])
    assert args.bootstrap == Stage5Config().bootstrap_samples == 5000
