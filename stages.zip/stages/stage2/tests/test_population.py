import numpy as np

from inh_stage2.population import (
    BRANCH_ORDER, candidate_probe_config, make_clone_parameters, make_repeat_perturbation,
    simulate_population, results_to_arrays,
)
from inh_stage2.stage2_config import CandidateConfig, Stage2Config


def _design():
    cfg = Stage2Config(
        n_pilot_clones=6, n_validation_clones=12, n_pilot_repeats=2,
        n_validation_repeats=3, pilot_steps=96, validation_steps=128,
        retention_grid=(0.4,), protention_grid=(0.4,), chi_grid=(2.0,),
        bootstrap_samples=200, n_control_clones=6, n_control_repeats=2,
        n_independent_noise_clones=6, n_independent_noise_repeats=3,
    )
    rng = np.random.default_rng(1)
    clones = [make_clone_parameters(i, rng, cfg) for i in range(6)]
    bank = {}
    for clone in clones:
        for rep in range(3):
            for branch in BRANCH_ORDER:
                bank[(clone.clone_id, rep, branch)] = make_repeat_perturbation(rng, cfg)
    return cfg, clones, bank


def test_commutative_control_preserves_noise_but_collapses_interaction() -> None:
    cfg, clones, bank = _design()
    cand = CandidateConfig(0.4,0.4,2.0)
    primary = results_to_arrays(simulate_population(cand, clones, bank, n_repeats=2, n_steps=96, design=cfg, common_random_numbers=True))
    comm = results_to_arrays(simulate_population(cand, clones, bank, n_repeats=2, n_steps=96, design=cfg, common_random_numbers=True, commutative=True, constant_gate=True))
    ip = np.mean(0.5*(primary.interaction_r_then_p+primary.interaction_p_then_r))
    ic = np.mean(0.5*(comm.interaction_r_then_p+comm.interaction_p_then_r))
    assert ip > ic
    assert ic < 5e-3


def test_double_null_is_zero_under_common_random_numbers() -> None:
    cfg, clones, bank = _design()
    cand = CandidateConfig(0.4,0.4,2.0)
    null = results_to_arrays(simulate_population(cand, clones, bank, n_repeats=2, n_steps=96, design=cfg, common_random_numbers=True, retention_enabled=False, protention_enabled=False))
    assert max(np.max(null.common_r), np.max(null.common_p), np.max(null.common_rp)) < 1e-10
