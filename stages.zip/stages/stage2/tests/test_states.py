import numpy as np
from inh_stage2.config import Stage1Config
from inh_stage2.states import Branch, build_branch_states, protention_distribution, probability_errors


def test_protention_probability_constraints() -> None:
    cfg = Stage1Config(n_steps=128, convergence_steps=(32,64,128))
    states = build_branch_states(cfg)
    t = np.linspace(0,1,101)
    for state in states.values():
        norm, neg = probability_errors(protention_distribution(t, state, cfg))
        assert norm < 1e-12
        assert neg < 1e-14
    assert not np.allclose(protention_distribution(t, states[Branch.N], cfg), protention_distribution(t, states[Branch.P], cfg))
