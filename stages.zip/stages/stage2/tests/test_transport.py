from inh_stage2.config import Stage1Config
from inh_stage2.ric import compute_ric_timeseries
from inh_stage2.states import Branch, build_branch_states
from inh_stage2.connection import make_generator
from inh_stage2.transport import convergence_metrics, gauge_test_metrics, reference_integrator_error, reverse_path_error


def test_reference_gauge_reverse_and_convergence() -> None:
    cfg = Stage1Config(n_steps=128, convergence_steps=(32,64,128))
    ric = compute_ric_timeseries(cfg)
    gen = make_generator(build_branch_states(cfg)[Branch.RP], cfg, ric)
    gauge = gauge_test_metrics(gen, cfg, 128)
    assert gauge['covariance_error'] < 1e-8
    assert gauge['descriptor_error'] < 1e-8
    assert reverse_path_error(gen, 128) < 1e-8
    assert reference_integrator_error(gen, 128) < 5e-6
    conv = convergence_metrics(gen, (32,64,128))
    assert conv['distance_n2_n3'] < 1e-4
