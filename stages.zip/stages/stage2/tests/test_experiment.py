from inh_stage2.stage2_config import Stage2Config
from inh_stage2.stage2_experiment import run_stage2


def test_minimal_run_is_deterministic_and_split_is_clean() -> None:
    cfg = Stage2Config(
        n_pilot_clones=6, n_validation_clones=12,
        n_pilot_repeats=2, n_validation_repeats=3,
        pilot_steps=64, validation_steps=64,
        retention_grid=(0.40,), protention_grid=(0.40,), chi_grid=(2.0,),
        n_control_clones=6, n_control_repeats=2,
        n_independent_noise_clones=6, n_independent_noise_repeats=3,
        bootstrap_samples=200,
    )
    result = run_stage2(cfg)
    assert result.summary['design']['split_overlap'] is False
    assert result.summary['design']['shared_bootstrap_indices_across_candidates'] is True
    assert result.summary['numerical_and_gauge_validation']['passed'] is True
    assert isinstance(result.summary['overall_pass'], bool)
