import numpy as np

from inh_stage2.algebra import (
    GENERATORS, I2, P0, T1, antihermitian_error, conjugacy_distance,
    projector_hermiticity_error, projector_idempotence_error,
    special_unitary_error, su2_angle, su2_expm, traceless_error,
)


def test_generators_and_projector() -> None:
    assert max(antihermitian_error(g) for g in GENERATORS) < 1e-14
    assert max(traceless_error(g) for g in GENERATORS) < 1e-14
    assert projector_idempotence_error(P0) < 1e-14
    assert projector_hermiticity_error(P0) < 1e-14


def test_near_identity_angle_and_true_su2_check() -> None:
    theta = 1e-10
    matrix = su2_expm(2.0 * theta * T1)
    assert np.isclose(su2_angle(matrix), theta, rtol=1e-8, atol=1e-15)
    shifted = np.exp(0.2j) * I2
    assert special_unitary_error(shifted) > 0.1


def test_conjugacy_distance() -> None:
    assert np.isclose(conjugacy_distance(su2_expm(0.2*T1), su2_expm(0.5*T1)), 0.15, atol=1e-13)
