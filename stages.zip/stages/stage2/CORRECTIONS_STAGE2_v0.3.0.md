# Stage 2 v0.3.0 corrections

- Ported stable near-identity SU(2) angle, true det(U)=1 QC, traceless-generator QC, full gauge covariance, reverse-path, CF4 convergence and DOP853 reference checks from corrected Stage 1.
- Replaced direct exponential weighting with log-space protention normalization.
- Separated common-frame effects from gauge-invariant conjugacy effects.
- Added branch-dependent fast RIC values derived from retention support and predictive/protentional mismatch.
- Added constant-fast-RIC ablation without making RIC causality part of the primary pass criterion.
- Rebuilt the commutative control as a linear same-noise projection onto one Lie-algebra axis, preserving additive branch effects and background perturbations while removing commutators.
- Replaced candidate-specific sequential bootstrap draws with fixed resampling indices shared across all candidates.
- Separated pilot selection from an externally frozen confirmatory candidate.
- Calibrated primary thresholds from the matched CRN double-null estimand.
- Reclassified independent branch noise as a separate measurement-robustness claim and corrected it with an exact paired same-noise null.
- Added strict claim hierarchy: primary latent validation may pass while extended independent-noise robustness fails.
- Added held-out CSV, NPZ, 300-dpi figures, manifest, report and checksums.
