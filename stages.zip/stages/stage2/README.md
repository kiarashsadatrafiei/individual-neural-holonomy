# Individual Neural Holonomy — Stage 2 v0.3.0

Stage 2 is a **held-out population validation of noncommutative retention–protention transport**. It does not model slow remodeling; that claim belongs to Stage 3.

## Design

1. Pilot and validation clone sets are disjoint.
2. Candidate selection uses fixed bootstrap resamples shared across every candidate.
3. Scientific thresholds are frozen from a pilot null distribution with both histories disabled and matched branch-specific noise.
4. The primary analysis uses common random numbers across counterfactual branches.
5. Independent-noise results are paired with an exact same-noise null and reported only after null-bias subtraction.
6. The commutative control preserves pointwise perturbation magnitude while projecting all generators onto one Lie-algebra axis.
7. Common-frame and gauge-invariant conjugacy effects are reported separately.

## Run

```bash
python -m pip install -e .[dev]
pytest
inh-stage2 --output results/stage2_final --strict
```

Use `--quick` for a smoke-test configuration.

## Interpretation

A pass supports reliable nonfactorizability of retention- and protention-conditioned noncommuting transport in the held-out latent population. It does not establish experience-dependent remodeling or phenomenal differentiation.
