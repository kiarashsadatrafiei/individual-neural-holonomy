from inh_stage2.stage2_cli import main

if __name__ == "__main__":
    main()
