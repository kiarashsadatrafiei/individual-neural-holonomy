from __future__ import annotations

import argparse
import json

from inh_stage2.config import Stage1Config
from inh_stage2.experiment import run_stage1
from inh_stage2.io import save_result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="results/stage1")
    parser.add_argument("--steps", type=int, default=None)
    args = parser.parse_args()

    config = Stage1Config() if args.steps is None else Stage1Config(n_steps=args.steps)
    result = run_stage1(config)
    save_result(result, args.output)
    print(json.dumps(result.summary, indent=2))


if __name__ == "__main__":
    main()
