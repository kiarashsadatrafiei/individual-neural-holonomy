from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import numpy as np
from numpy.typing import NDArray

from .algebra import (
    GENERATORS,
    I2,
    T1,
    T2,
    T3,
    antihermitian_error,
    conjugacy_distance,
    group_distance,
    special_unitary_error,
    su2_angle,
    su2_expm,
    traceless_error,
    unitarity_error,
)
from .config import Stage1Config
from .ric import RICTimeseries, compute_ric_timeseries, kappa_at
from .stage2_config import CandidateConfig, Stage2Config
from .states import (
    Branch,
    BranchState,
    PROTENTION_CONTRAST,
    RETENTION_EVENT,
    RELEVANCE_EVENT,
    anticipated_occupancy,
    neural_path,
    neural_velocity,
    protention_distribution,
    protention_scalar,
    update_memory,
)

ComplexMatrix = NDArray[np.complex128]
RealArray = NDArray[np.float64]

BRANCH_ORDER: tuple[Branch, ...] = (Branch.N, Branch.R, Branch.P, Branch.RP)


@dataclass(frozen=True)
class CloneParameters:
    clone_id: int
    base_scale: float
    retention_scale: float
    protention_scale: float
    retention_history_scale: float
    relevance_history_scale: float
    deformation_sin: RealArray
    deformation_cos: RealArray


@dataclass(frozen=True)
class RepeatPerturbation:
    sin_coefficients: RealArray
    cos_coefficients: RealArray


@dataclass(frozen=True)
class CloneRepeatResult:
    clone_id: int
    repeat_id: int
    holonomies: dict[Branch, ComplexMatrix]
    angles: dict[Branch, float]
    common_effects: dict[str, float]
    conjugacy_effects: dict[str, float]
    interaction_r_then_p: float
    interaction_p_then_r: float
    max_unitarity_error: float
    max_special_unitary_error: float
    max_generator_antihermitian_error: float
    max_generator_traceless_error: float


@dataclass(frozen=True)
class PopulationArrays:
    clone_ids: NDArray[np.int64]
    repeat_ids: NDArray[np.int64]
    angles: RealArray
    common_r: RealArray
    common_p: RealArray
    common_rp: RealArray
    conjugacy_r: RealArray
    conjugacy_p: RealArray
    conjugacy_rp: RealArray
    interaction_r_then_p: RealArray
    interaction_p_then_r: RealArray


def _lognormal_unit(rng: np.random.Generator, sd: float) -> float:
    return float(np.exp(rng.normal(-0.5 * sd * sd, sd)))


def make_clone_parameters(clone_id: int, rng: np.random.Generator, config: Stage2Config) -> CloneParameters:
    shape = (2, config.n_fourier_terms, 3)
    return CloneParameters(
        clone_id=clone_id,
        base_scale=_lognormal_unit(rng, config.subject_base_sd),
        retention_scale=_lognormal_unit(rng, config.subject_retention_sd),
        protention_scale=_lognormal_unit(rng, config.subject_protention_sd),
        retention_history_scale=_lognormal_unit(rng, config.subject_history_sd),
        relevance_history_scale=_lognormal_unit(rng, config.subject_history_sd),
        deformation_sin=rng.normal(0.0, config.subject_deformation_sd, size=shape),
        deformation_cos=rng.normal(0.0, config.subject_deformation_sd, size=shape),
    )


def make_repeat_perturbation(rng: np.random.Generator, config: Stage2Config) -> RepeatPerturbation:
    shape = (2, config.n_fourier_terms, 3)
    return RepeatPerturbation(
        sin_coefficients=rng.normal(0.0, config.repeat_noise_sd, size=shape),
        cos_coefficients=rng.normal(0.0, config.repeat_noise_sd, size=shape),
    )


def candidate_probe_config(candidate: CandidateConfig, n_steps: int) -> Stage1Config:
    cfg = Stage1Config(
        n_steps=n_steps,
        convergence_steps=(n_steps // 4, n_steps // 2, n_steps),
        connection_retention=candidate.connection_retention,
        connection_protention=candidate.connection_protention,
        chi_slope=candidate.chi_slope,
    )
    cfg.validate()
    return cfg


def build_clone_branch_states(
    clone: CloneParameters,
    base_config: Stage1Config,
    *,
    retention_enabled: bool = True,
    protention_enabled: bool = True,
) -> dict[Branch, BranchState]:
    states: dict[Branch, BranchState] = {}
    for branch in BRANCH_ORDER:
        retention = np.zeros(2, dtype=np.float64)
        relevance = np.zeros(4, dtype=np.float64)
        use_r = retention_enabled and branch in (Branch.R, Branch.RP)
        use_p = protention_enabled and branch in (Branch.P, Branch.RP)
        r_event = clone.retention_history_scale * RETENTION_EVENT if use_r else np.zeros(2)
        p_event = clone.relevance_history_scale * RELEVANCE_EVENT if use_p else np.zeros(4)
        for _ in range(base_config.n_individuation_episodes):
            retention = update_memory(retention, r_event, base_config.gamma_r)
            relevance = update_memory(relevance, p_event, base_config.gamma_p)
        states[branch] = BranchState(branch, retention.astype(np.float64), relevance.astype(np.float64))
    return states


def _fourier_coefficients(time: RealArray, sin_coefficients: RealArray, cos_coefficients: RealArray) -> RealArray:
    output = np.zeros((2, time.size, 3), dtype=np.float64)
    for term in range(sin_coefficients.shape[1]):
        omega = 2.0 * np.pi * (term + 1)
        output += sin_coefficients[:, term, :][:, None, :] * np.sin(omega * time)[None, :, None]
        output += cos_coefficients[:, term, :][:, None, :] * np.cos(omega * time)[None, :, None]
    return output


def branch_kappa(
    times: RealArray,
    state: BranchState,
    base_config: Stage1Config,
    ric: RICTimeseries,
    design: Stage2Config,
) -> RealArray:
    base = np.array([kappa_at(float(t), base_config, ric.calibration) for t in times])
    q = anticipated_occupancy(times, base_config)
    p = protention_distribution(times, state, base_config)
    future_phase = 2.0 * np.pi * (times + base_config.tau_p)
    realized = np.sin(future_phase)
    q_mean = q @ PROTENTION_CONTRAST
    p_mean = p @ PROTENTION_CONTRAST
    mismatch = 0.5 * (np.abs(realized - q_mean) + np.abs(realized - p_mean))
    support = state.retention_scalar * (0.5 + 0.5 * np.cos(2.0 * np.pi * times))
    return base + design.ric_retention_gain * support - design.ric_mismatch_gain * mismatch


def _noncommuting_components(
    times: RealArray,
    state: BranchState,
    candidate: CandidateConfig,
    clone: CloneParameters,
    repeat: RepeatPerturbation,
    base_config: Stage1Config,
) -> tuple[RealArray, RealArray]:
    x = neural_path(times)
    retention = clone.retention_scale * state.retention_scalar
    protention = clone.protention_scale * np.asarray(protention_scalar(times, state, base_config))
    a1 = np.zeros((times.size, 3), dtype=np.float64)
    a2 = np.zeros((times.size, 3), dtype=np.float64)
    a1[:, 0] = base_config.connection_base * clone.base_scale * x[:, 1]
    a1[:, 1] = candidate.connection_retention * retention
    a1[:, 2] = candidate.connection_protention * protention
    a2[:, 0] = candidate.connection_protention * protention
    a2[:, 1] = -base_config.connection_base * clone.base_scale * x[:, 0]
    a2[:, 2] = candidate.connection_retention * retention
    deformation = _fourier_coefficients(
        times,
        clone.deformation_sin + repeat.sin_coefficients,
        clone.deformation_cos + repeat.cos_coefficients,
    )
    return a1 + deformation[0], a2 + deformation[1]


def _commutative_projection(coefficients: RealArray) -> RealArray:
    """Linearly project every contribution onto one common Lie-algebra axis.

    The linear projection preserves the additive retention/protention decomposition
    and retains the same smooth background and repeat perturbations. Only the
    commutator structure is removed.
    """
    output = np.zeros_like(coefficients)
    output[:, 0] = np.sum(coefficients, axis=1) / np.sqrt(3.0)
    return output


def generator_coefficients_at_nodes(
    times: RealArray,
    state: BranchState,
    candidate: CandidateConfig,
    clone: CloneParameters,
    repeat: RepeatPerturbation,
    base_config: Stage1Config,
    ric: RICTimeseries,
    design: Stage2Config,
    *,
    commutative: bool = False,
    constant_gate: bool = False,
) -> RealArray:
    a1, a2 = _noncommuting_components(times, state, candidate, clone, repeat, base_config)
    if commutative:
        a1 = _commutative_projection(a1)
        a2 = _commutative_projection(a2)
    if constant_gate:
        permeability = np.full(times.size, 0.5)
    else:
        kappa = branch_kappa(times, state, base_config, ric, design)
        permeability = 1.0 / (1.0 + np.exp(np.clip(candidate.chi_slope * kappa, -60.0, 60.0)))
    # P0 leaves T3 parallel and T1/T2 off-diagonal.
    a1[:, :2] *= permeability[:, None]
    a2[:, :2] *= permeability[:, None]
    dx = neural_velocity(times)
    return a1 * dx[:, 0, None] + a2 * dx[:, 1, None]


def _matrix(coefficients: RealArray) -> ComplexMatrix:
    return (coefficients[0] * T1 + coefficients[1] * T2 + coefficients[2] * T3).astype(np.complex128)


def integrate_branch_fast(
    state: BranchState,
    candidate: CandidateConfig,
    clone: CloneParameters,
    repeat: RepeatPerturbation,
    base_config: Stage1Config,
    ric: RICTimeseries,
    design: Stage2Config,
    n_steps: int,
    *,
    commutative: bool = False,
    constant_gate: bool = False,
) -> tuple[ComplexMatrix, dict[str, float]]:
    dt = 1.0 / n_steps
    sqrt3 = np.sqrt(3.0)
    c1, c2 = 0.5 - sqrt3 / 6.0, 0.5 + sqrt3 / 6.0
    w1, w2 = (3.0 - 2.0 * sqrt3) / 12.0, (3.0 + 2.0 * sqrt3) / 12.0
    starts = np.arange(n_steps, dtype=np.float64) * dt
    g1 = generator_coefficients_at_nodes(
        starts + c1 * dt, state, candidate, clone, repeat, base_config, ric, design,
        commutative=commutative, constant_gate=constant_gate,
    )
    g2 = generator_coefficients_at_nodes(
        starts + c2 * dt, state, candidate, clone, repeat, base_config, ric, design,
        commutative=commutative, constant_gate=constant_gate,
    )
    transport = I2.copy()
    max_u = max_su = max_ah = max_tr = 0.0
    for index in range(n_steps):
        left = _matrix(-dt * (w1 * g1[index] + w2 * g2[index]))
        right = _matrix(-dt * (w2 * g1[index] + w1 * g2[index]))
        max_ah = max(max_ah, antihermitian_error(left), antihermitian_error(right))
        max_tr = max(max_tr, traceless_error(left), traceless_error(right))
        transport = su2_expm(left) @ su2_expm(right) @ transport
        max_u = max(max_u, unitarity_error(transport))
        max_su = max(max_su, special_unitary_error(transport))
    return transport, {
        "unitarity": max_u,
        "special_unitary": max_su,
        "antihermitian": max_ah,
        "traceless": max_tr,
    }


def interaction_residual(h_n: ComplexMatrix, h_r: ComplexMatrix, h_p: ComplexMatrix, h_rp: ComplexMatrix, order: str) -> float:
    g_r = h_r @ h_n.conj().T
    g_p = h_p @ h_n.conj().T
    g_rp = h_rp @ h_n.conj().T
    if order == "R_then_P":
        residual = g_r @ g_p @ g_rp.conj().T
    elif order == "P_then_R":
        residual = g_p @ g_r @ g_rp.conj().T
    else:
        raise ValueError(order)
    return su2_angle(residual)


def simulate_clone_repeat(
    candidate: CandidateConfig,
    clone: CloneParameters,
    repeat_id: int,
    perturbations: Mapping[Branch, RepeatPerturbation],
    base_config: Stage1Config,
    ric: RICTimeseries,
    design: Stage2Config,
    n_steps: int,
    *,
    retention_enabled: bool = True,
    protention_enabled: bool = True,
    commutative: bool = False,
    constant_gate: bool = False,
) -> CloneRepeatResult:
    states = build_clone_branch_states(
        clone, base_config, retention_enabled=retention_enabled, protention_enabled=protention_enabled
    )
    holonomies: dict[Branch, ComplexMatrix] = {}
    qcs: list[dict[str, float]] = []
    for branch in BRANCH_ORDER:
        holonomies[branch], qc = integrate_branch_fast(
            states[branch], candidate, clone, perturbations[branch], base_config, ric, design, n_steps,
            commutative=commutative, constant_gate=constant_gate,
        )
        qcs.append(qc)
    h_n, h_r, h_p, h_rp = (holonomies[b] for b in BRANCH_ORDER)
    common = {
        "R": group_distance(h_n, h_r),
        "P": group_distance(h_n, h_p),
        "RP": group_distance(h_n, h_rp),
    }
    conjugacy = {
        "R": conjugacy_distance(h_n, h_r),
        "P": conjugacy_distance(h_n, h_p),
        "RP": conjugacy_distance(h_n, h_rp),
    }
    return CloneRepeatResult(
        clone.clone_id,
        repeat_id,
        holonomies,
        {b: su2_angle(holonomies[b]) for b in BRANCH_ORDER},
        common,
        conjugacy,
        interaction_residual(h_n, h_r, h_p, h_rp, "R_then_P"),
        interaction_residual(h_n, h_r, h_p, h_rp, "P_then_R"),
        max(q["unitarity"] for q in qcs),
        max(q["special_unitary"] for q in qcs),
        max(q["antihermitian"] for q in qcs),
        max(q["traceless"] for q in qcs),
    )


def simulate_population(
    candidate: CandidateConfig,
    clones: list[CloneParameters],
    repeat_bank: Mapping[tuple[int, int, Branch], RepeatPerturbation],
    *,
    n_repeats: int,
    n_steps: int,
    design: Stage2Config,
    common_random_numbers: bool,
    retention_enabled: bool = True,
    protention_enabled: bool = True,
    commutative: bool = False,
    constant_gate: bool = False,
) -> list[CloneRepeatResult]:
    base_config = candidate_probe_config(candidate, n_steps)
    ric = compute_ric_timeseries(base_config, n_steps=max(256, n_steps))
    results: list[CloneRepeatResult] = []
    for clone in clones:
        for repeat_id in range(n_repeats):
            if common_random_numbers:
                shared = repeat_bank[(clone.clone_id, repeat_id, Branch.N)]
                perturbations = {branch: shared for branch in BRANCH_ORDER}
            else:
                perturbations = {
                    branch: repeat_bank[(clone.clone_id, repeat_id, branch)] for branch in BRANCH_ORDER
                }
            results.append(
                simulate_clone_repeat(
                    candidate, clone, repeat_id, perturbations, base_config, ric, design, n_steps,
                    retention_enabled=retention_enabled,
                    protention_enabled=protention_enabled,
                    commutative=commutative,
                    constant_gate=constant_gate,
                )
            )
    return results


def results_to_arrays(results: list[CloneRepeatResult]) -> PopulationArrays:
    return PopulationArrays(
        clone_ids=np.array([r.clone_id for r in results], dtype=np.int64),
        repeat_ids=np.array([r.repeat_id for r in results], dtype=np.int64),
        angles=np.array([[r.angles[b] for b in BRANCH_ORDER] for r in results]),
        common_r=np.array([r.common_effects["R"] for r in results]),
        common_p=np.array([r.common_effects["P"] for r in results]),
        common_rp=np.array([r.common_effects["RP"] for r in results]),
        conjugacy_r=np.array([r.conjugacy_effects["R"] for r in results]),
        conjugacy_p=np.array([r.conjugacy_effects["P"] for r in results]),
        conjugacy_rp=np.array([r.conjugacy_effects["RP"] for r in results]),
        interaction_r_then_p=np.array([r.interaction_r_then_p for r in results]),
        interaction_p_then_r=np.array([r.interaction_p_then_r for r in results]),
    )


def project_to_su2(matrix: ComplexMatrix) -> ComplexMatrix:
    u, _, vh = np.linalg.svd(matrix)
    unitary = u @ vh
    determinant = np.linalg.det(unitary)
    return (unitary / np.sqrt(determinant)).astype(np.complex128)


def branch_mean_holonomies(results: list[CloneRepeatResult]) -> dict[int, dict[Branch, ComplexMatrix]]:
    output: dict[int, dict[Branch, ComplexMatrix]] = {}
    clone_ids = sorted({r.clone_id for r in results})
    for clone_id in clone_ids:
        rows = [r for r in results if r.clone_id == clone_id]
        output[clone_id] = {
            branch: project_to_su2(np.mean(np.stack([r.holonomies[branch] for r in rows]), axis=0))
            for branch in BRANCH_ORDER
        }
    return output


def clone_mean_interactions(results: list[CloneRepeatResult]) -> RealArray:
    means = branch_mean_holonomies(results)
    values = []
    for hol in means.values():
        values.append(
            0.5 * (
                interaction_residual(hol[Branch.N], hol[Branch.R], hol[Branch.P], hol[Branch.RP], "R_then_P")
                + interaction_residual(hol[Branch.N], hol[Branch.R], hol[Branch.P], hol[Branch.RP], "P_then_R")
            )
        )
    return np.asarray(values, dtype=np.float64)


def clone_mean_max_effect(results: list[CloneRepeatResult]) -> RealArray:
    means = branch_mean_holonomies(results)
    return np.asarray([
        max(group_distance(h[Branch.N], h[b]) for b in (Branch.R, Branch.P, Branch.RP))
        for h in means.values()
    ])
