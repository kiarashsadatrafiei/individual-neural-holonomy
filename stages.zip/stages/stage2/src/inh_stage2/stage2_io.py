from __future__ import annotations

import csv
import hashlib
import json
import platform
import subprocess
import sys
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np

from .stage2_experiment import Stage2Result


def _json_default(value: Any):
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(type(value).__name__)


def _git_hash() -> str | None:
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        return None


def build_manifest(result: Stage2Result) -> dict[str, Any]:
    return {
        "package_version": "0.3.0",
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "git_commit": _git_hash(),
        "root_seed": result.config.root_seed,
        "selected_candidate": result.selected_candidate.to_dict(),
        "configuration": result.config.to_dict(),
        "overall_pass": result.summary["overall_pass"],
    }


def save_candidate_table(result: Stage2Result, output: Path) -> None:
    rows = []
    for item in result.pilot_evaluations:
        row = {
            **item.candidate.to_dict(),
            "identifier": item.candidate.identifier,
            "admissible": item.admissible,
            "clone_success_fraction": item.clone_success_fraction,
            **{f"{k}_mean": v.mean for k, v in item.estimates.items()},
            **{f"{k}_lower": v.lower for k, v in item.estimates.items()},
            **{f"threshold_{k}": v for k, v in item.thresholds.items()},
        }
        rows.append(row)
    with (output / "pilot_candidates.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def save_validation_table(result: Stage2Result, output: Path) -> None:
    a = result.validation_arrays
    columns = {
        "clone_id": a.clone_ids,
        "repeat_id": a.repeat_ids,
        "common_R": a.common_r,
        "common_P": a.common_p,
        "common_RP": a.common_rp,
        "conjugacy_R": a.conjugacy_r,
        "conjugacy_P": a.conjugacy_p,
        "conjugacy_RP": a.conjugacy_rp,
        "interaction_R_then_P": a.interaction_r_then_p,
        "interaction_P_then_R": a.interaction_p_then_r,
    }
    with (output / "held_out_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(columns)
        writer.writerows(zip(*columns.values(), strict=True))


def save_figures(result: Stage2Result, output: Path) -> None:
    a = result.validation_arrays
    summary = result.summary["held_out_validation"]
    thresholds = summary["thresholds_frozen_from_pilot_null"]

    fig, axes = plt.subplots(2, 2, figsize=(11, 8.5), constrained_layout=True)
    names = ["R", "P", "RP"]
    common = [a.common_r, a.common_p, a.common_rp]
    conjugacy = [a.conjugacy_r, a.conjugacy_p, a.conjugacy_rp]
    axes[0, 0].boxplot(common, tick_labels=names, showfliers=False)
    axes[0, 0].axhline(thresholds["common_effect"], linestyle="--", linewidth=1)
    axes[0, 0].set_title("Common-frame transport effects")
    axes[0, 0].set_ylabel("SU(2) distance")

    axes[0, 1].boxplot(conjugacy, tick_labels=names, showfliers=False)
    axes[0, 1].axhline(thresholds["conjugacy_effect"], linestyle="--", linewidth=1)
    axes[0, 1].set_title("Gauge-invariant conjugacy effects")

    interaction = 0.5 * (a.interaction_r_then_p + a.interaction_p_then_r)
    axes[1, 0].hist(interaction, bins=20)
    axes[1, 0].axvline(thresholds["interaction"], linestyle="--", linewidth=1)
    axes[1, 0].set_title("Nonfactorizability residual")
    axes[1, 0].set_xlabel("Residual class angle")

    held = result.summary["held_out_validation"]["estimates"]
    labels = ["common R", "common P", "common RP", "conj RP", "interaction"]
    keys = ["common_R", "common_P", "common_RP", "conjugacy_RP", "interaction"]
    means = [held[k]["mean"] for k in keys]
    lower = [held[k]["mean"] - held[k]["lower"] for k in keys]
    upper = [held[k]["upper"] - held[k]["mean"] for k in keys]
    axes[1, 1].errorbar(np.arange(len(keys)), means, yerr=[lower, upper], fmt="o", capsize=4)
    axes[1, 1].set_xticks(np.arange(len(keys)), labels, rotation=30, ha="right")
    axes[1, 1].set_title("Held-out estimates with cluster-bootstrap CIs")
    fig.suptitle("Stage 2: held-out noncommutative retention–protention transport")
    fig.savefig(output / "stage2_main_figure.png", dpi=300)
    plt.close(fig)

    controls = result.summary["specificity_and_RIC_controls"]
    fig, ax = plt.subplots(figsize=(8.5, 5.5), constrained_layout=True)
    labels = ["Primary", "Commutative", "Constant RIC gate", "Double null"]
    values = [
        held["interaction"]["mean"],
        controls["matched_commutative_control"]["interaction"],
        controls["constant_fast_RIC_gate"]["interaction"],
        controls["double_null"]["interaction"],
    ]
    ax.bar(labels, values)
    ax.set_ylabel("Interaction residual")
    ax.set_title("Mechanistic specificity controls")
    ax.tick_params(axis="x", rotation=20)
    fig.savefig(output / "stage2_controls.png", dpi=300)
    plt.close(fig)


def save_report(result: Stage2Result, output: Path) -> None:
    s = result.summary
    held = s["held_out_validation"]
    independent = s["independent_noise_null_corrected"]
    lines = [
        "# Stage 2 Validation Report",
        "",
        "## Scope",
        s["scientific_scope"]["primary_claim"],
        "",
        "Stage 2 validates transport nonfactorizability. It does not claim slow remodeling.",
        "",
        "## Selected frozen candidate",
        f"`{result.selected_candidate.identifier}`",
        "",
        "## Held-out validation",
    ]
    for key, value in held["estimates"].items():
        lines.append(f"- **{key}**: {value['mean']:.6f} [{value['lower']:.6f}, {value['upper']:.6f}]")
    lines += [
        f"- Clone success fraction: {held['clone_success_fraction']:.3f}",
        f"- Held-out pass: **{held['passed']}**",
        "",
        "## Independent-noise paired-null correction",
        f"- Corrected interaction: {independent['null_corrected_interaction']}",
        f"- Paired null bias: {independent['paired_null_bias']}",
        "",
        "## Controls",
        f"- Specificity controls pass: **{s['specificity_and_RIC_controls']['passed']}**",
        f"- Numerical/gauge validation pass: **{s['numerical_and_gauge_validation']['passed']}**",
        "",
        f"# Overall pass: **{s['overall_pass']}**",
    ]
    (output / "VALIDATION_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_checksums(output: Path) -> None:
    lines = []
    for path in sorted(p for p in output.rglob("*") if p.is_file() and p.name != "SHA256SUMS.txt"):
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{digest}  {path.relative_to(output)}")
    (output / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def save_stage2_result(result: Stage2Result, output_dir: str | Path) -> Path:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    (output / "summary.json").write_text(json.dumps(result.summary, indent=2, default=_json_default), encoding="utf-8")
    (output / "manifest.json").write_text(json.dumps(build_manifest(result), indent=2, default=_json_default), encoding="utf-8")
    a = result.validation_arrays
    np.savez_compressed(
        output / "held_out_population.npz",
        clone_ids=a.clone_ids,
        repeat_ids=a.repeat_ids,
        angles=a.angles,
        common_R=a.common_r,
        common_P=a.common_p,
        common_RP=a.common_rp,
        conjugacy_R=a.conjugacy_r,
        conjugacy_P=a.conjugacy_p,
        conjugacy_RP=a.conjugacy_rp,
        interaction_R_then_P=a.interaction_r_then_p,
        interaction_P_then_R=a.interaction_p_then_r,
    )
    save_candidate_table(result, output)
    save_validation_table(result, output)
    save_figures(result, output)
    save_report(result, output)
    write_checksums(output)
    return output
