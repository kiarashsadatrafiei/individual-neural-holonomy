from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import sys
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import scipy

from .experiment import Stage1Result
from .states import Branch


def _json_default(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, complex):
        return {"real": value.real, "imag": value.imag}
    raise TypeError(f"Object of type {type(value)!r} is not JSON serializable")


def _git_commit() -> str | None:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL, text=True
        ).strip()
    except Exception:
        return None


def configuration_hash(config: dict[str, Any]) -> str:
    payload = json.dumps(config, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def build_manifest(result: Stage1Result) -> dict[str, Any]:
    config = result.config.to_dict()
    return {
        "project": "individual-neural-holonomy-stage1",
        "configuration_hash": configuration_hash(config),
        "configuration": config,
        "git_commit": _git_commit(),
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "pid": os.getpid(),
    }


def save_figure(result: Stage1Result, output_path: Path) -> None:
    time = result.arrays["time"]
    path = result.arrays["neural_path"]

    figure, axes = plt.subplots(2, 2, figsize=(11, 8.5), constrained_layout=True)

    axes[0, 0].plot(path[:, 0], path[:, 1], linewidth=2)
    axes[0, 0].scatter(path[0, 0], path[0, 1], marker="o", label="start/end")
    axes[0, 0].set_title("Shared neural probe loop")
    axes[0, 0].set_xlabel("x₁")
    axes[0, 0].set_ylabel("x₂")
    axes[0, 0].axis("equal")
    axes[0, 0].legend()

    for branch in Branch:
        axes[0, 1].plot(
            time,
            result.arrays[f"protention_scalar_{branch.value}"],
            label=branch.value,
        )
    axes[0, 1].set_title("Branch-specific protentional organization")
    axes[0, 1].set_xlabel("normalized probe time")
    axes[0, 1].set_ylabel("Pₛ(t)")
    axes[0, 1].legend()

    for branch in Branch:
        axes[1, 0].plot(time, result.arrays["kappa"], label=branch.value)
    axes[1, 0].set_title("Matched RIC margin")
    axes[1, 0].set_xlabel("normalized probe time")
    axes[1, 0].set_ylabel("κ(t)")

    labels = [branch.value for branch in Branch]
    angles = [result.branches[branch].angle for branch in Branch]
    axes[1, 1].bar(labels, angles)
    axes[1, 1].set_title("Gauge-invariant holonomy angle")
    axes[1, 1].set_xlabel("branch")
    axes[1, 1].set_ylabel("θ(H), radians")

    figure.savefig(output_path, dpi=240)
    plt.close(figure)


def save_result(result: Stage1Result, output_dir: str | Path) -> Path:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)

    with (output / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(result.summary, handle, indent=2, default=_json_default)

    with (output / "manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(build_manifest(result), handle, indent=2, default=_json_default)

    np.savez_compressed(output / "branch_timeseries.npz", **result.arrays)
    save_figure(result, output / "stage1_figure.png")
    return output
