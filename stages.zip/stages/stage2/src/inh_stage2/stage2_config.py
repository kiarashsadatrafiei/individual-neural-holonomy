from __future__ import annotations

from dataclasses import asdict, dataclass
from itertools import product
from typing import Any


@dataclass(frozen=True, order=True)
class CandidateConfig:
    connection_retention: float
    connection_protention: float
    chi_slope: float

    @property
    def identifier(self) -> str:
        return f"r{self.connection_retention:.3f}_p{self.connection_protention:.3f}_chi{self.chi_slope:.3f}"

    @property
    def complexity(self) -> tuple[float, float, float]:
        return (
            max(self.connection_retention, self.connection_protention),
            self.connection_retention**2 + self.connection_protention**2,
            abs(self.chi_slope - 2.0),
        )

    def to_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass(frozen=True)
class Stage2Config:
    """Predeclared pilot/held-out design for Stage 2.

    The primary estimand is shared-frame nonfactorizability under common random
    numbers.  Conjugacy-class separation is a distinct invariant estimand;
    neither is described as unrestricted cross-subject gauge identification.
    Practical thresholds are frozen from a pilot double-null numerical floor.
    """

    root_seed: int = 20260721

    n_pilot_clones: int = 8
    n_validation_clones: int = 20
    n_pilot_repeats: int = 2
    n_validation_repeats: int = 4
    pilot_steps: int = 128
    validation_steps: int = 256

    retention_grid: tuple[float, ...] = (0.30, 0.45)
    protention_grid: tuple[float, ...] = (0.30, 0.45)
    chi_grid: tuple[float, ...] = (1.0, 2.0)

    subject_base_sd: float = 0.08
    subject_retention_sd: float = 0.10
    subject_protention_sd: float = 0.10
    subject_history_sd: float = 0.10
    subject_deformation_sd: float = 0.025
    repeat_noise_sd: float = 0.018
    n_fourier_terms: int = 2

    # Endogenous fast-RIC perturbation around the calibrated base field.
    ric_retention_gain: float = 0.35
    ric_mismatch_gain: float = 0.45

    n_control_clones: int = 8
    n_control_repeats: int = 2
    n_independent_noise_clones: int = 20
    n_independent_noise_repeats: int = 10

    bootstrap_samples: int = 20_000
    ci_level: float = 0.95
    null_quantile: float = 0.95
    minimum_practical_margin: float = 0.002

    min_clone_success_fraction: float = 0.80
    min_effect_icc: float = 0.60
    min_signature_icc: float = 0.70
    max_mean_effect: float = 0.45
    control_tolerance: float = 0.004
    max_independent_null_bias: float = 0.20

    # Confirmatory mode: the single candidate was frozen before this root seed.
    candidate_frozen_externally: bool = False
    frozen_candidate_provenance: str = ""

    def validate(self) -> None:
        if self.n_pilot_clones < 6 or self.n_validation_clones < 12:
            raise ValueError("pilot and validation splits are too small")
        if self.n_pilot_repeats < 2 or self.n_validation_repeats < 3:
            raise ValueError("insufficient repeated traversals")
        if self.pilot_steps < 64 or self.validation_steps < self.pilot_steps:
            raise ValueError("invalid integration resolutions")
        if not 0.0 < self.ci_level < 1.0 or not 0.5 < self.null_quantile < 1.0:
            raise ValueError("invalid confidence/null quantiles")
        if self.bootstrap_samples < 200:
            raise ValueError("bootstrap_samples must be >= 200")
        if self.n_fourier_terms < 1:
            raise ValueError("n_fourier_terms must be positive")
        if min(self.retention_grid + self.protention_grid + self.chi_grid) <= 0.0:
            raise ValueError("candidate values must be positive")

    def candidates(self) -> tuple[CandidateConfig, ...]:
        return tuple(
            CandidateConfig(r, p, chi)
            for r, p, chi in product(self.retention_grid, self.protention_grid, self.chi_grid)
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
