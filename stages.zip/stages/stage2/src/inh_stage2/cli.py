from __future__ import annotations

import argparse
import json

from .config import Stage1Config
from .experiment import run_stage1
from .io import save_result


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the locked Stage 1 INH simulation")
    parser.add_argument("--output", default="results/stage1", help="Output directory")
    parser.add_argument("--steps", type=int, default=None, help="Override the main step count")
    args = parser.parse_args()

    config = Stage1Config() if args.steps is None else Stage1Config(n_steps=args.steps)
    result = run_stage1(config)
    output = save_result(result, args.output)
    print(json.dumps(result.summary, indent=2))
    print(f"\nSaved outputs to: {output.resolve()}")


if __name__ == "__main__":
    main()
