from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from numpy.typing import NDArray

from .algebra import (
    P0,
    antihermitian_error,
    determinant_modulus_error,
    group_distance,
    projector_hermiticity_error,
    projector_idempotence_error,
    sorted_eigenphases,
    su2_angle,
    unitarity_error,
)
from .config import Stage1Config
from .connection import make_generator, raw_connection_components
from .ric import RICTimeseries, compute_ric_timeseries
from .states import (
    Branch,
    BranchState,
    anticipated_occupancy,
    build_branch_states,
    neural_path,
    probability_errors,
    protention_distribution,
    protention_scalar,
)
from .transport import (
    convergence_metrics,
    gauge_descriptor_error,
    integrate_generator,
    reverse_path_error,
)

ComplexMatrix = NDArray[np.complex128]


@dataclass(frozen=True)
class BranchResult:
    state: BranchState
    holonomy: ComplexMatrix
    angle: float
    eigenphases: NDArray[np.float64]
    max_transport_unitarity_error: float
    final_unitarity_error: float
    determinant_error: float


@dataclass(frozen=True)
class Stage1Result:
    config: Stage1Config
    ric: RICTimeseries
    branches: dict[Branch, BranchResult]
    summary: dict[str, Any]
    arrays: dict[str, NDArray[np.generic]]


def _branch_result(
    state: BranchState,
    config: Stage1Config,
    ric: RICTimeseries,
    *,
    commutative: bool = False,
) -> BranchResult:
    generator = make_generator(state, config, ric, commutative=commutative)
    transport = integrate_generator(generator, config.n_steps)
    holonomy = transport.holonomy
    return BranchResult(
        state=state,
        holonomy=holonomy,
        angle=su2_angle(holonomy),
        eigenphases=sorted_eigenphases(holonomy),
        max_transport_unitarity_error=transport.max_unitarity_error,
        final_unitarity_error=unitarity_error(holonomy),
        determinant_error=determinant_modulus_error(holonomy),
    )


def _relative_effect(holonomy: ComplexMatrix, neutral: ComplexMatrix) -> ComplexMatrix:
    return holonomy @ neutral.conj().T


def _interaction_residual(
    h_n: ComplexMatrix,
    h_r: ComplexMatrix,
    h_p: ComplexMatrix,
    h_rp: ComplexMatrix,
    *,
    order: str,
) -> ComplexMatrix:
    g_r = _relative_effect(h_r, h_n)
    g_p = _relative_effect(h_p, h_n)
    g_rp = _relative_effect(h_rp, h_n)
    if order == "R_then_P":
        return g_r @ g_p @ g_rp.conj().T
    if order == "P_then_R":
        return g_p @ g_r @ g_rp.conj().T
    raise ValueError(f"Unknown order: {order}")


def _run_control(
    config: Stage1Config,
    *,
    gamma_r: float | None = None,
    gamma_p: float | None = None,
    commutative: bool = False,
) -> dict[Branch, BranchResult]:
    control_config = Stage1Config(
        **{
            **config.to_dict(),
            "gamma_r": config.gamma_r if gamma_r is None else gamma_r,
            "gamma_p": config.gamma_p if gamma_p is None else gamma_p,
        }
    )
    control_config.validate()
    ric = compute_ric_timeseries(control_config)
    states = build_branch_states(control_config)
    return {
        branch: _branch_result(
            state,
            control_config,
            ric,
            commutative=commutative,
        )
        for branch, state in states.items()
    }


def run_stage1(config: Stage1Config | None = None) -> Stage1Result:
    config = Stage1Config() if config is None else config
    config.validate()

    ric = compute_ric_timeseries(config)
    states = build_branch_states(config)
    branches = {
        branch: _branch_result(state, config, ric)
        for branch, state in states.items()
    }

    h_n = branches[Branch.N].holonomy
    h_r = branches[Branch.R].holonomy
    h_p = branches[Branch.P].holonomy
    h_rp = branches[Branch.RP].holonomy

    delta_r = group_distance(h_n, h_r)
    delta_p = group_distance(h_n, h_p)
    delta_rp = group_distance(h_n, h_rp)

    interaction_rp = su2_angle(
        _interaction_residual(h_n, h_r, h_p, h_rp, order="R_then_P")
    )
    interaction_pr = su2_angle(
        _interaction_residual(h_n, h_r, h_p, h_rp, order="P_then_R")
    )

    time = ric.time
    x_neutral = neural_path(time)
    x_errors: dict[str, float] = {}
    endpoint_errors: dict[str, float] = {}
    kappa_errors: dict[str, float] = {}
    probability_summary: dict[str, dict[str, float]] = {}

    q_reference = anticipated_occupancy(time, config)
    q_branch_errors: dict[str, float] = {}
    for branch, state in states.items():
        x_branch = neural_path(time)
        x_errors[branch.value] = float(np.max(np.linalg.norm(x_branch - x_neutral, axis=1)))
        endpoint_errors[branch.value] = float(np.linalg.norm(x_branch[-1] - x_neutral[-1]))
        kappa_errors[branch.value] = 0.0
        q_branch = anticipated_occupancy(time, config)
        q_branch_errors[branch.value] = float(np.max(np.abs(q_branch - q_reference)))
        probabilities = protention_distribution(time, state, config)
        norm_error, negativity = probability_errors(probabilities)
        probability_summary[branch.value] = {
            "normalization_error": norm_error,
            "negative_mass": negativity,
        }

    # Geometry/QC checks on the main branch family.
    antihermitian_errors: list[float] = []
    for state in states.values():
        for t in np.linspace(0.0, 1.0, 65, endpoint=False):
            a1, a2 = raw_connection_components(float(t), state, config)
            antihermitian_errors.extend([antihermitian_error(a1), antihermitian_error(a2)])

    neutral_generator = make_generator(states[Branch.N], config, ric)
    gauge_error = gauge_descriptor_error(neutral_generator, config, config.n_steps)
    reverse_error = reverse_path_error(neutral_generator, config.n_steps)
    convergence = convergence_metrics(neutral_generator, config.convergence_steps)

    # Specificity controls.
    retention_control = _run_control(config, gamma_r=0.0)
    protention_control = _run_control(config, gamma_p=0.0)
    null_control = _run_control(config, gamma_r=0.0, gamma_p=0.0)
    commutative_control = _run_control(config, commutative=True)

    retention_ablation_effect = group_distance(
        retention_control[Branch.N].holonomy,
        retention_control[Branch.R].holonomy,
    )
    protention_ablation_effect = group_distance(
        protention_control[Branch.N].holonomy,
        protention_control[Branch.P].holonomy,
    )
    null_max_effect = max(
        group_distance(null_control[Branch.N].holonomy, null_control[branch].holonomy)
        for branch in (Branch.R, Branch.P, Branch.RP)
    )

    comm_h_n = commutative_control[Branch.N].holonomy
    comm_h_r = commutative_control[Branch.R].holonomy
    comm_h_p = commutative_control[Branch.P].holonomy
    comm_h_rp = commutative_control[Branch.RP].holonomy
    comm_interaction_rp = su2_angle(
        _interaction_residual(
            comm_h_n, comm_h_r, comm_h_p, comm_h_rp, order="R_then_P"
        )
    )
    comm_interaction_pr = su2_angle(
        _interaction_residual(
            comm_h_n, comm_h_r, comm_h_p, comm_h_rp, order="P_then_R"
        )
    )

    epsilon_num = max(
        gauge_error,
        reverse_error,
        convergence["distance_n2_n3"],
    )
    epsilon_h = max(50.0 * epsilon_num, config.min_holonomy_effect)
    epsilon_ablation = max(10.0 * epsilon_num, config.min_ablation_effect)

    design_pass = (
        max(x_errors.values()) <= config.tol_state_match
        and max(endpoint_errors.values()) <= config.tol_endpoint_match
        and max(kappa_errors.values()) <= config.tol_kappa_match
        and max(q_branch_errors.values()) <= config.tol_probability
    )
    numerical_pass = (
        max(antihermitian_errors) <= config.tol_antihermitian
        and projector_idempotence_error(P0) <= config.tol_projector
        and projector_hermiticity_error(P0) <= config.tol_projector
        and max(result.max_transport_unitarity_error for result in branches.values())
        <= config.tol_unitarity
        and max(result.final_unitarity_error for result in branches.values())
        <= config.tol_unitarity
        and max(result.determinant_error for result in branches.values())
        <= config.tol_determinant
        and max(v["normalization_error"] for v in probability_summary.values())
        <= config.tol_probability
        and max(v["negative_mass"] for v in probability_summary.values())
        <= config.tol_probability_negative
        and reverse_error <= config.tol_reverse
        and gauge_error <= config.tol_gauge
        and convergence["distance_n2_n3"] <= config.tol_convergence
        and convergence["observed_order"] >= config.min_observed_order
    )
    scientific_pass = (
        delta_r > epsilon_h
        and delta_p > epsilon_h
        and delta_rp > epsilon_h
        and max(interaction_rp, interaction_pr) > epsilon_h
    )
    specificity_pass = (
        retention_ablation_effect <= epsilon_ablation
        and protention_ablation_effect <= epsilon_ablation
        and null_max_effect <= epsilon_ablation
        and max(comm_interaction_rp, comm_interaction_pr) <= epsilon_ablation
    )

    summary: dict[str, Any] = {
        "estimands": {
            "delta_R": delta_r,
            "delta_P": delta_p,
            "delta_RP": delta_rp,
            "interaction_R_then_P": interaction_rp,
            "interaction_P_then_R": interaction_pr,
            "branch_angles": {branch.value: result.angle for branch, result in branches.items()},
            "branch_eigenphases": {
                branch.value: result.eigenphases.tolist() for branch, result in branches.items()
            },
        },
        "design_integrity": {
            "max_state_path_error": max(x_errors.values()),
            "max_endpoint_error": max(endpoint_errors.values()),
            "max_kappa_error": max(kappa_errors.values()),
            "max_Q_error": max(q_branch_errors.values()),
            "passed": design_pass,
        },
        "numerical_qc": {
            "max_raw_connection_antihermitian_error": max(antihermitian_errors),
            "projector_idempotence_error": projector_idempotence_error(P0),
            "projector_hermiticity_error": projector_hermiticity_error(P0),
            "max_transport_unitarity_error": max(
                result.max_transport_unitarity_error for result in branches.values()
            ),
            "max_final_unitarity_error": max(
                result.final_unitarity_error for result in branches.values()
            ),
            "max_determinant_modulus_error": max(
                result.determinant_error for result in branches.values()
            ),
            "gauge_descriptor_error": gauge_error,
            "reverse_path_error": reverse_error,
            "convergence": convergence,
            "epsilon_num": epsilon_num,
            "passed": numerical_pass,
        },
        "specificity_controls": {
            "retention_ablation_effect": retention_ablation_effect,
            "protention_ablation_effect": protention_ablation_effect,
            "null_max_effect": null_max_effect,
            "commutative_interaction_R_then_P": comm_interaction_rp,
            "commutative_interaction_P_then_R": comm_interaction_pr,
            "epsilon_ablation": epsilon_ablation,
            "passed": specificity_pass,
        },
        "scientific_criteria": {
            "epsilon_H": epsilon_h,
            "passed": scientific_pass,
        },
        "overall_pass": design_pass and numerical_pass and scientific_pass and specificity_pass,
    }

    arrays: dict[str, NDArray[np.generic]] = {
        "time": time,
        "neural_path": x_neutral,
        "kappa": ric.kappa,
        "curvature": ric.curvature,
        "recursive_gain": ric.recursive_gain,
        "dispersion": ric.dispersion,
        "anticipated_occupancy": q_reference,
    }
    for branch, state in states.items():
        arrays[f"retention_{branch.value}"] = state.retention
        arrays[f"relevance_{branch.value}"] = state.relevance
        arrays[f"protention_{branch.value}"] = protention_distribution(time, state, config)
        arrays[f"protention_scalar_{branch.value}"] = protention_scalar(time, state, config)
        arrays[f"holonomy_{branch.value}"] = branches[branch].holonomy

    return Stage1Result(config=config, ric=ric, branches=branches, summary=summary, arrays=arrays)
