from __future__ import annotations

import argparse
import json

from .stage2_config import Stage2Config
from .stage2_experiment import run_stage2
from .stage2_io import save_stage2_result


def main() -> None:
    parser = argparse.ArgumentParser(description="Run corrected Stage 2 held-out validation")
    parser.add_argument("--output", default="results/stage2_final")
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--strict", action="store_true", help="Return non-zero exit status when scientific validation fails")
    args = parser.parse_args()
    if args.quick:
        config = Stage2Config(
            n_pilot_clones=6,
            n_validation_clones=12,
            n_pilot_repeats=2,
            n_validation_repeats=3,
            pilot_steps=96,
            validation_steps=192,
            retention_grid=(0.30, 0.45),
            protention_grid=(0.30, 0.45),
            chi_grid=(1.0, 2.0),
            n_control_clones=6,
            n_control_repeats=2,
            n_independent_noise_clones=6,
            n_independent_noise_repeats=4,
            bootstrap_samples=300,
        )
    else:
        config = Stage2Config()
    result = run_stage2(config)
    output = save_stage2_result(result, args.output)
    print(json.dumps(result.summary, indent=2))
    print(f"Saved outputs to: {output.resolve()}")
    if args.strict and not result.summary["overall_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
