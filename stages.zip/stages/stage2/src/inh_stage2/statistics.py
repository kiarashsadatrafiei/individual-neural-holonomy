from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray

RealArray = NDArray[np.float64]
IntArray = NDArray[np.int64]


@dataclass(frozen=True)
class Estimate:
    mean: float
    lower: float
    upper: float

    def to_dict(self) -> dict[str, float]:
        return {"mean": self.mean, "lower": self.lower, "upper": self.upper}


def fixed_bootstrap_indices(seed: int, samples: int, n_clusters: int) -> IntArray:
    rng = np.random.default_rng(seed)
    return rng.integers(0, n_clusters, size=(samples, n_clusters), dtype=np.int64)


def cluster_matrix(values: RealArray, clone_ids: IntArray, repeat_ids: IntArray) -> tuple[IntArray, RealArray]:
    clones = np.unique(clone_ids)
    repeats = np.unique(repeat_ids)
    matrix = np.full((clones.size, repeats.size), np.nan, dtype=np.float64)
    ci = {int(v): i for i, v in enumerate(clones)}
    ri = {int(v): i for i, v in enumerate(repeats)}
    for value, clone_id, repeat_id in zip(values, clone_ids, repeat_ids, strict=True):
        matrix[ci[int(clone_id)], ri[int(repeat_id)]] = value
    if np.isnan(matrix).any():
        raise ValueError("incomplete clone-by-repeat matrix")
    return clones, matrix


def icc_absolute_single(matrix: RealArray) -> float:
    if matrix.ndim != 2:
        raise ValueError("ICC input must be 2D")
    n, k = matrix.shape
    if n < 2 or k < 2:
        return float("nan")
    grand = float(np.mean(matrix))
    row_means = np.mean(matrix, axis=1)
    col_means = np.mean(matrix, axis=0)
    ms_rows = k * float(np.sum((row_means - grand) ** 2)) / (n - 1)
    ms_cols = n * float(np.sum((col_means - grand) ** 2)) / (k - 1)
    residual = matrix - row_means[:, None] - col_means[None, :] + grand
    ms_error = float(np.sum(residual**2)) / ((n - 1) * (k - 1))
    denom = ms_rows + (k - 1) * ms_error + k * (ms_cols - ms_error) / n
    if denom <= 0.0:
        return float("nan")
    return float((ms_rows - ms_error) / denom)


def estimate_from_matrix(matrix: RealArray, indices: IntArray, ci_level: float) -> Estimate:
    clone_means = np.mean(matrix, axis=1)
    if indices.shape[1] != clone_means.size:
        raise ValueError("bootstrap indices do not match cluster count")
    boot = np.mean(clone_means[indices], axis=1)
    alpha = 0.5 * (1.0 - ci_level)
    lower, upper = np.quantile(boot, [alpha, 1.0 - alpha])
    return Estimate(float(np.mean(clone_means)), float(lower), float(upper))


def estimate_vector(values: RealArray, indices: IntArray, ci_level: float) -> Estimate:
    if values.ndim != 1 or indices.shape[1] != values.size:
        raise ValueError("invalid vector/bootstrap dimensions")
    boot = np.mean(values[indices], axis=1)
    alpha = 0.5 * (1.0 - ci_level)
    lo, hi = np.quantile(boot, [alpha, 1.0 - alpha])
    return Estimate(float(np.mean(values)), float(lo), float(hi))
