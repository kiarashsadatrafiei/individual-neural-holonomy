from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class Stage1Config:
    """Shared probe, geometry and numerical configuration."""

    n_steps: int = 512
    convergence_steps: tuple[int, int, int] = (128, 256, 512)

    n_individuation_episodes: int = 12
    gamma_r: float = 0.25
    gamma_p: float = 0.25
    beta_q: float = 2.5
    beta_w: float = 1.5
    tau_p: float = 0.25

    beta_s: float = 4.0
    recurrence_l0: float = 0.35
    recurrence_l1: float = 0.15
    recurrence_omega: float = 0.10
    rho_ref: float = 1.0
    ric_alpha: float = 1.0
    ric_beta: float = 1.0

    connection_base: float = 0.40
    connection_retention: float = 0.20
    connection_protention: float = 0.20
    chi_slope: float = 2.0

    gauge_amplitude: float = 0.40

    tol_antihermitian: float = 1e-12
    tol_traceless: float = 1e-12
    tol_projector: float = 1e-12
    tol_unitarity: float = 1e-10
    tol_determinant: float = 1e-10
    tol_probability: float = 1e-12
    tol_probability_negative: float = 1e-14
    tol_reverse: float = 1e-8
    tol_gauge: float = 1e-8
    tol_convergence: float = 1e-6
    convergence_roundoff_floor: float = 5e-13
    min_observed_order: float = 2.5
    tol_reference_integrator: float = 5e-7

    def validate(self) -> None:
        if self.n_steps < 32 or self.n_steps % 2:
            raise ValueError("n_steps must be an even integer >= 32")
        if not 0.0 <= self.gamma_r <= 1.0 or not 0.0 <= self.gamma_p <= 1.0:
            raise ValueError("memory update rates must lie in [0, 1]")
        if self.rho_ref <= 0.0 or self.chi_slope <= 0.0:
            raise ValueError("rho_ref and chi_slope must be positive")
        n1, n2, n3 = self.convergence_steps
        if not (n1 < n2 < n3):
            raise ValueError("convergence steps must be strictly increasing")
        if abs(n2 / n1 - n3 / n2) > 1e-12:
            raise ValueError("convergence steps require a common refinement ratio")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
