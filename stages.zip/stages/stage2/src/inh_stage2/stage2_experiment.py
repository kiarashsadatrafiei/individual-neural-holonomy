from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from .algebra import conjugacy_distance, group_distance
from .population import (
    BRANCH_ORDER,
    CloneParameters,
    PopulationArrays,
    RepeatPerturbation,
    branch_mean_holonomies,
    candidate_probe_config,
    clone_mean_interactions,
    clone_mean_max_effect,
    generator_coefficients_at_nodes,
    make_clone_parameters,
    make_repeat_perturbation,
    results_to_arrays,
    simulate_population,
)
from .ric import compute_ric_timeseries
from .stage2_config import CandidateConfig, Stage2Config
from .states import Branch, build_branch_states
from .statistics import (
    Estimate,
    cluster_matrix,
    estimate_from_matrix,
    estimate_vector,
    fixed_bootstrap_indices,
    icc_absolute_single,
)
from .transport import (
    convergence_metrics,
    gauge_test_metrics,
    reference_integrator_error,
    reverse_path_error,
)


@dataclass(frozen=True)
class CandidateEvaluation:
    candidate: CandidateConfig
    estimates: dict[str, Estimate]
    iccs: dict[str, float]
    thresholds: dict[str, float]
    clone_success_fraction: float
    admissible: bool
    selection_key: tuple[Any, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "candidate": self.candidate.to_dict(),
            "estimates": {k: v.to_dict() for k, v in self.estimates.items()},
            "iccs": self.iccs,
            "thresholds": self.thresholds,
            "clone_success_fraction": self.clone_success_fraction,
            "admissible": self.admissible,
            "selection_key": list(self.selection_key),
        }


@dataclass(frozen=True)
class Stage2Result:
    config: Stage2Config
    selected_candidate: CandidateConfig
    pilot_evaluations: tuple[CandidateEvaluation, ...]
    validation_arrays: PopulationArrays
    validation_results: list
    summary: dict[str, Any]


def _make_design(config: Stage2Config):
    rng = np.random.default_rng(config.root_seed)
    pilot = [make_clone_parameters(i, rng, config) for i in range(config.n_pilot_clones)]
    validation = [
        make_clone_parameters(10_000 + i, rng, config) for i in range(config.n_validation_clones)
    ]
    max_repeats = max(
        config.n_validation_repeats,
        config.n_independent_noise_repeats,
        config.n_control_repeats,
    )
    bank: dict[tuple[int, int, Branch], RepeatPerturbation] = {}
    for clone in pilot + validation:
        for repeat in range(max_repeats):
            for branch in BRANCH_ORDER:
                bank[(clone.clone_id, repeat, branch)] = make_repeat_perturbation(rng, config)
    return pilot, validation, bank


def _metric_matrix(arrays: PopulationArrays, values: np.ndarray):
    return cluster_matrix(values, arrays.clone_ids, arrays.repeat_ids)[1]


def _signature_iccs(arrays: PopulationArrays) -> dict[str, float]:
    return {
        branch.value: icc_absolute_single(_metric_matrix(arrays, arrays.angles[:, i]))
        for i, branch in enumerate(BRANCH_ORDER)
    }


def _null_thresholds(
    candidate: CandidateConfig,
    clones: list[CloneParameters],
    bank,
    config: Stage2Config,
    *,
    n_repeats: int,
    n_steps: int,
) -> dict[str, float]:
    null = simulate_population(
        candidate,
        clones,
        bank,
        n_repeats=n_repeats,
        n_steps=n_steps,
        design=config,
        common_random_numbers=True,
        retention_enabled=False,
        protention_enabled=False,
    )
    interactions = clone_mean_interactions(null)
    common = clone_mean_max_effect(null)
    means = branch_mean_holonomies(null)
    conjugacy = np.asarray([
        max(conjugacy_distance(h[Branch.N], h[b]) for b in (Branch.R, Branch.P, Branch.RP))
        for h in means.values()
    ])
    margin = config.minimum_practical_margin
    return {
        "interaction": float(np.quantile(interactions, config.null_quantile) + margin),
        "common_effect": float(np.quantile(common, config.null_quantile) + margin),
        "conjugacy_effect": float(np.quantile(conjugacy, config.null_quantile) + margin),
        "null_interaction_mean": float(np.mean(interactions)),
    }


def _evaluate_candidate(
    candidate: CandidateConfig,
    arrays: PopulationArrays,
    thresholds: dict[str, float],
    config: Stage2Config,
    bootstrap_indices: np.ndarray,
) -> CandidateEvaluation:
    metrics = {
        "common_R": arrays.common_r,
        "common_P": arrays.common_p,
        "common_RP": arrays.common_rp,
        "conjugacy_RP": arrays.conjugacy_rp,
        "interaction": 0.5 * (arrays.interaction_r_then_p + arrays.interaction_p_then_r),
    }
    estimates: dict[str, Estimate] = {}
    iccs: dict[str, float] = {}
    matrices: dict[str, np.ndarray] = {}
    for name, values in metrics.items():
        matrix = _metric_matrix(arrays, values)
        matrices[name] = matrix
        estimates[name] = estimate_from_matrix(matrix, bootstrap_indices, config.ci_level)
        iccs[name] = icc_absolute_single(matrix)
    clone_success = (
        (np.mean(matrices["common_R"], axis=1) > thresholds["common_effect"])
        & (np.mean(matrices["common_P"], axis=1) > thresholds["common_effect"])
        & (np.mean(matrices["common_RP"], axis=1) > thresholds["common_effect"])
        & (np.mean(matrices["conjugacy_RP"], axis=1) > thresholds["conjugacy_effect"])
        & (np.mean(matrices["interaction"], axis=1) > thresholds["interaction"])
    )
    lower_pass = (
        estimates["common_R"].lower > thresholds["common_effect"]
        and estimates["common_P"].lower > thresholds["common_effect"]
        and estimates["common_RP"].lower > thresholds["common_effect"]
        and estimates["conjugacy_RP"].lower > thresholds["conjugacy_effect"]
        and estimates["interaction"].lower > thresholds["interaction"]
    )
    reliability = all(np.isfinite(v) and v >= config.min_effect_icc for v in iccs.values())
    bounded = max(e.mean for e in estimates.values()) <= config.max_mean_effect
    admissible = bool(
        lower_pass
        and reliability
        and float(np.mean(clone_success)) >= config.min_clone_success_fraction
        and bounded
    )
    minimum_margin = min(
        estimates["common_R"].lower - thresholds["common_effect"],
        estimates["common_P"].lower - thresholds["common_effect"],
        estimates["common_RP"].lower - thresholds["common_effect"],
        estimates["conjugacy_RP"].lower - thresholds["conjugacy_effect"],
        estimates["interaction"].lower - thresholds["interaction"],
    )
    selection_key = (
        0 if admissible else 1,
        *candidate.complexity,
        -minimum_margin,
        candidate.identifier,
    )
    return CandidateEvaluation(
        candidate,
        estimates,
        iccs,
        thresholds,
        float(np.mean(clone_success)),
        admissible,
        selection_key,
    )


def _validation_summary(results, arrays, thresholds, config, bootstrap_indices):
    metrics = {
        "common_R": arrays.common_r,
        "common_P": arrays.common_p,
        "common_RP": arrays.common_rp,
        "conjugacy_R": arrays.conjugacy_r,
        "conjugacy_P": arrays.conjugacy_p,
        "conjugacy_RP": arrays.conjugacy_rp,
        "interaction": 0.5 * (arrays.interaction_r_then_p + arrays.interaction_p_then_r),
    }
    estimates, iccs, matrices = {}, {}, {}
    for name, values in metrics.items():
        matrix = _metric_matrix(arrays, values)
        matrices[name] = matrix
        estimates[name] = estimate_from_matrix(matrix, bootstrap_indices, config.ci_level).to_dict()
        iccs[name] = icc_absolute_single(matrix)
    success = (
        (np.mean(matrices["common_R"], axis=1) > thresholds["common_effect"])
        & (np.mean(matrices["common_P"], axis=1) > thresholds["common_effect"])
        & (np.mean(matrices["common_RP"], axis=1) > thresholds["common_effect"])
        & (np.mean(matrices["conjugacy_RP"], axis=1) > thresholds["conjugacy_effect"])
        & (np.mean(matrices["interaction"], axis=1) > thresholds["interaction"])
    )
    signature = _signature_iccs(arrays)
    pass_effects = (
        estimates["common_R"]["lower"] > thresholds["common_effect"]
        and estimates["common_P"]["lower"] > thresholds["common_effect"]
        and estimates["common_RP"]["lower"] > thresholds["common_effect"]
        and estimates["conjugacy_RP"]["lower"] > thresholds["conjugacy_effect"]
        and estimates["interaction"]["lower"] > thresholds["interaction"]
    )
    pass_reliability = all(np.isfinite(v) and v >= config.min_effect_icc for v in iccs.values())
    pass_signature = all(np.isfinite(v) and v >= config.min_signature_icc for v in signature.values())
    qc = {
        "max_unitarity_error": max(r.max_unitarity_error for r in results),
        "max_special_unitary_error": max(r.max_special_unitary_error for r in results),
        "max_generator_antihermitian_error": max(r.max_generator_antihermitian_error for r in results),
        "max_generator_traceless_error": max(r.max_generator_traceless_error for r in results),
    }
    passed = bool(
        pass_effects
        and pass_reliability
        and pass_signature
        and float(np.mean(success)) >= config.min_clone_success_fraction
        and max(qc.values()) < 1e-9
    )
    return {
        "estimates": estimates,
        "effect_iccs": iccs,
        "signature_iccs": signature,
        "clone_success_fraction": float(np.mean(success)),
        "thresholds_frozen_from_pilot_null": thresholds,
        "numerical_qc": qc,
        "passed": passed,
    }, passed


def _controls(candidate, clones, bank, config):
    subset = clones[: config.n_control_clones]
    kwargs = dict(
        candidate=candidate,
        clones=subset,
        repeat_bank=bank,
        n_repeats=config.n_control_repeats,
        n_steps=config.pilot_steps,
        design=config,
        common_random_numbers=True,
    )
    r_off = simulate_population(**kwargs, retention_enabled=False)
    p_off = simulate_population(**kwargs, protention_enabled=False)
    null = simulate_population(**kwargs, retention_enabled=False, protention_enabled=False)
    comm = simulate_population(**kwargs, commutative=True, constant_gate=True)
    const = simulate_population(**kwargs, constant_gate=True)
    def means(rows):
        a = results_to_arrays(rows)
        return {
            "R": float(np.mean(a.common_r)),
            "P": float(np.mean(a.common_p)),
            "RP": float(np.mean(a.common_rp)),
            "interaction": float(np.mean(0.5 * (a.interaction_r_then_p + a.interaction_p_then_r))),
        }
    r_m, p_m, n_m, c_m, k_m = map(means, (r_off, p_off, null, comm, const))
    primary = simulate_population(**kwargs)
    primary_i = means(primary)["interaction"]
    primary_clone = clone_mean_interactions(primary)
    constant_clone = clone_mean_interactions(const)
    fast_delta = primary_clone - constant_clone
    fast_indices = fixed_bootstrap_indices(
        config.root_seed + 404, config.bootstrap_samples, fast_delta.size
    )
    fast_estimate = estimate_vector(fast_delta, fast_indices, config.ci_level)
    passed = bool(
        r_m["R"] <= config.control_tolerance
        and p_m["P"] <= config.control_tolerance
        and max(n_m.values()) <= config.control_tolerance
        and c_m["interaction"] <= config.control_tolerance
    )
    return {
        "retention_ablation": r_m,
        "protention_ablation": p_m,
        "double_null": n_m,
        "matched_commutative_control": c_m,
        "constant_fast_RIC_gate": k_m,
        "fast_RIC_modulation_delta": fast_estimate.to_dict(),
        "fast_RIC_modulation_supported": bool(fast_estimate.lower > 0.0),
        "interpretation": (
            "Fast RIC modulation is supported only if the paired clone-bootstrap lower bound is positive; "
            "Stage 2 primary validity does not depend on that secondary claim."
        ),
        "passed": passed,
    }


def _independent_noise(candidate, clones, bank, config, bootstrap_indices):
    subset = clones[: config.n_independent_noise_clones]
    kwargs = dict(
        candidate=candidate,
        clones=subset,
        repeat_bank=bank,
        n_repeats=config.n_independent_noise_repeats,
        n_steps=config.pilot_steps,
        design=config,
        common_random_numbers=False,
    )
    observed = simulate_population(**kwargs)
    null = simulate_population(**kwargs, retention_enabled=False, protention_enabled=False)
    observed_values = clone_mean_interactions(observed)
    null_values = clone_mean_interactions(null)
    corrected = observed_values - null_values
    indices = bootstrap_indices[:, : corrected.size]
    estimate = estimate_vector(corrected, indices, config.ci_level)
    null_estimate = estimate_vector(null_values, indices, config.ci_level)
    return {
        "observed_clone_mean_interaction": float(np.mean(observed_values)),
        "paired_null_bias": null_estimate.to_dict(),
        "null_corrected_interaction": estimate.to_dict(),
        "passed": bool(estimate.lower > 0.0 and null_estimate.mean < config.max_independent_null_bias),
    }


def _numerical_qc(candidate, clone, bank, config):
    from .population import _matrix
    base = candidate_probe_config(candidate, 512)
    ric = compute_ric_timeseries(base, 512)
    state = build_branch_states(base)[Branch.RP]
    repeat = bank[(clone.clone_id, 0, Branch.N)]
    def generator(t: float):
        coeff = generator_coefficients_at_nodes(
            np.array([t]), state, candidate, clone, repeat, base, ric, config
        )[0]
        return _matrix(coeff)
    gauge = gauge_test_metrics(generator, base, 512)
    convergence = convergence_metrics(generator, (128, 256, 512), roundoff_floor=5e-13)
    reference = reference_integrator_error(generator, 512)
    reverse = reverse_path_error(generator, 512)
    passed = bool(
        gauge["covariance_error"] < 1e-8
        and gauge["descriptor_error"] < 1e-8
        and reverse < 1e-8
        and convergence["distance_n2_n3"] < 2e-6
        and reference < 5e-7
    )
    return {"gauge": gauge, "convergence": convergence, "reference_error": reference, "reverse_error": reverse, "passed": passed}


def run_stage2(config: Stage2Config | None = None) -> Stage2Result:
    config = Stage2Config() if config is None else config
    config.validate()
    pilot, validation, bank = _make_design(config)
    pilot_bootstrap = fixed_bootstrap_indices(config.root_seed + 101, config.bootstrap_samples, config.n_pilot_clones)
    evaluations: list[CandidateEvaluation] = []
    threshold_cache: dict[float, dict[str, float]] = {}
    for candidate in config.candidates():
        if candidate.chi_slope not in threshold_cache:
            threshold_cache[candidate.chi_slope] = _null_thresholds(
                candidate, pilot, bank, config,
                n_repeats=config.n_pilot_repeats,
                n_steps=config.pilot_steps,
            )
        thresholds = threshold_cache[candidate.chi_slope]
        results = simulate_population(
            candidate, pilot, bank,
            n_repeats=config.n_pilot_repeats,
            n_steps=config.pilot_steps,
            design=config,
            common_random_numbers=True,
        )
        evaluations.append(
            _evaluate_candidate(candidate, results_to_arrays(results), thresholds, config, pilot_bootstrap)
        )
    evaluations.sort(key=lambda item: item.selection_key)
    selected = evaluations[0]

    validation_results = simulate_population(
        selected.candidate, validation, bank,
        n_repeats=config.n_validation_repeats,
        n_steps=config.validation_steps,
        design=config,
        common_random_numbers=True,
    )
    validation_arrays = results_to_arrays(validation_results)
    validation_bootstrap = fixed_bootstrap_indices(
        config.root_seed + 202, config.bootstrap_samples, config.n_validation_clones
    )
    validation_summary, validation_pass = _validation_summary(
        validation_results,
        validation_arrays,
        selected.thresholds,
        config,
        validation_bootstrap,
    )
    controls = _controls(selected.candidate, validation, bank, config)
    independent = _independent_noise(
        selected.candidate,
        validation,
        bank,
        config,
        fixed_bootstrap_indices(
            config.root_seed + 303,
            config.bootstrap_samples,
            config.n_independent_noise_clones,
        ),
    )
    numerical = _numerical_qc(selected.candidate, validation[0], bank, config)
    split_overlap = bool({c.clone_id for c in pilot} & {c.clone_id for c in validation})
    selection_requirement = bool(
        selected.admissible
        or (config.candidate_frozen_externally and len(config.candidates()) == 1)
    )
    primary_pass = bool(
        selection_requirement
        and validation_pass
        and controls["passed"]
        and numerical["passed"]
        and not split_overlap
    )
    extended_robustness_pass = bool(primary_pass and independent["passed"])
    overall = primary_pass
    summary = {
        "scientific_scope": {
            "primary_claim": "Held-out shared-frame nonfactorizability under common random numbers, accompanied by separate within-clone conjugacy-class separation.",
            "excluded_claims": [
                "Stage 2 does not establish slow experience-dependent remodeling.",
                "Fast RIC causality is a secondary ablation result, not required for the primary claim.",
                "The interaction residual is not an unrestricted gauge-invariant or cross-subject estimand.",
            ],
        },
        "design": {
            "pilot_clone_ids": [c.clone_id for c in pilot],
            "validation_clone_ids": [c.clone_id for c in validation],
            "split_overlap": split_overlap,
            "candidate_count": len(config.candidates()),
            "candidate_frozen_externally": config.candidate_frozen_externally,
            "frozen_candidate_provenance": config.frozen_candidate_provenance,
            "shared_bootstrap_indices_across_candidates": True,
            "common_random_numbers_primary": True,
        },
        "pilot_selection": {
            "selected_candidate": selected.candidate.to_dict(),
            "selected_admissible_in_current_pilot": selected.admissible,
            "selection_requirement_passed": selection_requirement,
            "admissible_candidate_count": int(sum(e.admissible for e in evaluations)),
            "selected_evaluation": selected.to_dict(),
            "top_candidates": [e.to_dict() for e in evaluations[:10]],
            "full_candidate_table_exported": True,
        },
        "held_out_validation": validation_summary,
        "specificity_and_RIC_controls": controls,
        "independent_noise_null_corrected": independent,
        "numerical_and_gauge_validation": numerical,
        "primary_shared_frame_CRN_validation_pass": primary_pass,
        "extended_independent_noise_robustness_pass": extended_robustness_pass,
        "shared_frame_interaction_robust_to_independent_noise_supported": extended_robustness_pass,
        "overall_pass_for_limited_CRN_claim": overall,
        "overall_pass": overall,
    }
    return Stage2Result(
        config,
        selected.candidate,
        tuple(evaluations),
        validation_arrays,
        validation_results,
        summary,
    )
