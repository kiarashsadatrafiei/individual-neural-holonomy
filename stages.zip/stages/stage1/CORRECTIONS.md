# Corrections in version 0.2.0

## Mathematical corrections

1. Replaced unstable `arccos(Re tr(H)/2)` evaluation with a near-identity-stable `atan2(|sin θ|, cos θ)` SU(2) class angle.
2. Added the true special-unitary test `|det(H)-1|`; determinant modulus is retained only as a secondary U(2) diagnostic.
3. Added explicit tracelessness checks for raw connection components and the pulled-back generator.
4. Separated common-frame SU(2) distance from conjugacy-class and eigenphase descriptor distances.
5. Added full gauge covariance testing, `H' = g(1)^{-1} H g(0)`, for all four counterfactual branches.
6. Added an independent DOP853 reference integration.
7. Required a common refinement ratio for convergence-order estimation and removed `Infinity` reports under roundoff saturation.

## Numerical and software corrections

1. Retained CF4 as the primary Lie-group integrator and corrected README documentation.
2. Added explicit CLI `--convergence-steps` and `--strict` modes.
3. Stabilized relevance-weighted protention in log space.
4. Separated main-estimand resolution from explicitly recorded auxiliary QC resolution.
5. Expanded unit tests from 12 to 20, including near-identity angle recovery, full gauge covariance, SU(2) determinant, extreme relevance stability, reference integration, and locked scientific-status reporting.
6. Added CSV outputs, three publication-resolution figures, and a generated validation report.

## Scientific interpretation correction

Stage 1 is reported as a **constructive common-frame proof-of-principle**. It demonstrates that matched base trajectories and RIC profiles can coexist with different transport operators when counterfactual branches share a declared fiber frame. It does not yet establish emergent connection remodeling, suprathreshold gauge-invariant cross-subject separation, or a suprathreshold retention–protention interaction.
