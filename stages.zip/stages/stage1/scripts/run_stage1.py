from inh_stage1.cli import main


if __name__ == "__main__":
    main()
