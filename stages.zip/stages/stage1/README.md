# Individual Neural Holonomy — Corrected Stage 1 Reference Implementation

This repository implements a locked, constructive Stage 1 counterfactual test for a single four-branch clone set:

- `N`: neutral retention, neutral prospective relevance
- `R`: altered retention only
- `P`: altered prospective relevance only
- `RP`: altered retention and prospective relevance

The neural probe trajectory, endpoint, anticipated occupancy, recurrence profile, and RIC margin are shared exactly across branches. Branch differences enter through retentional history and prospective relevance. Transport is computed on a fixed complex rank-2 fiber using an `SU(2) ⊂ U(2)` connection.

## Exact scientific scope

Stage 1 asks whether matched neural-state trajectories and matched RIC profiles can coexist with different transport operators in an explicitly shared counterfactual fiber frame.

It is a **constructive proof-of-principle**. Retention and protention enter the declared connection directly, so Stage 1 does not yet establish that experience-dependent remodeling produces connection differences emergently. It also does not make a phenomenological claim.

The corrected output reports two distinct estimands:

1. **Common-frame SU(2) distance**, valid for cloned branches with an explicit shared fiber identification.
2. **Gauge-invariant conjugacy/eigenphase distance**, appropriate for claims that must survive independent basis choice.

These quantities are never conflated.

## Installation

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\\Scripts\\activate
pip install -e ".[dev]"
```

## Run tests

```bash
pytest
```

## Run the corrected experiment

```bash
inh-stage1 --output results/stage1
```

Optional controls:

```bash
inh-stage1 \
  --steps 4096 \
  --convergence-steps 256 512 1024 \
  --output results/stage1
```

`--strict` saves all outputs but returns exit code `2` when the frozen scientific criterion is not met:

```bash
inh-stage1 --strict --output results/stage1
```

## Numerical conventions

- Primary integration uses a fourth-order two-exponential commutator-free Magnus (`CF4`) method.
- A midpoint exponential integrator remains available as an independent second-order implementation.
- A high-accuracy `DOP853` integration provides a cross-method reference check.
- Main estimands use `n_steps`; repeated gauge, reverse-path, and specificity controls use the explicitly recorded `auxiliary_steps` resolution to avoid redundant computation.
- The connection one-form is explicitly pulled back onto the probe path.
- `SU(2)` membership is tested using both unitarity and the full condition `det(H)=1`; checking only `|det(H)|=1` is not accepted.
- The conjugacy-class angle uses a stable `atan2(|sin θ|, cos θ)` formula rather than `arccos(tr(H)/2)` near the identity.
- Gauge QC tests the full covariance law `H' = g(1)^{-1} H g(0)` and descriptor invariance for every branch.
- Convergence resolutions must use a common refinement ratio.

## Generated outputs

The output directory contains:

- `summary.json`: estimands, explicit claim status, and pass/fail results
- `manifest.json`: environment and locked configuration metadata
- `VALIDATION_REPORT.md`: manuscript-oriented interpretation
- `figures/figure_stage1_main.png`: shared loop, protention, RIC, and class angles
- `figures/figure_transport_effects.png`: common-frame versus gauge-invariant effects and interaction
- `figures/figure_numerical_qc.png`: convergence and geometric/numerical QC
- `data/branch_summary.csv`: branch-level estimands and QC
- `data/timeseries.csv`: transparent time-resolved quantities
- `data/branch_timeseries.npz`: full numerical arrays

## Current locked result

The implementation, construction checks, and specificity controls pass. Common-frame branch effects exceed the frozen practical threshold. The gauge-invariant conjugacy-class effects and retention–protention interaction do not exceed that threshold. The software reports this result without post-hoc coefficient tuning.

The next model stage should generate connection differences through slow remodeling rather than placing all branch dependence directly in the Stage 1 connection.
