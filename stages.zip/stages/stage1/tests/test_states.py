import numpy as np

from inh_stage1.config import Stage1Config
from inh_stage1.states import (
    Branch,
    BranchState,
    anticipated_occupancy,
    build_branch_states,
    neural_path,
    probability_errors,
    protention_distribution,
)


def test_probe_is_closed() -> None:
    path = neural_path(np.array([0.0, 1.0]))
    assert np.linalg.norm(path[0] - path[1]) < 1e-14


def test_branches_share_initial_design_but_diverge_by_history() -> None:
    config = Stage1Config()
    states = build_branch_states(config)
    assert np.allclose(states[Branch.N].retention, 0.0)
    assert np.allclose(states[Branch.N].relevance, 0.0)
    assert not np.allclose(states[Branch.R].retention, states[Branch.N].retention)
    assert not np.allclose(states[Branch.P].relevance, states[Branch.N].relevance)


def test_predicted_occupancy_is_shared_and_probabilities_are_valid() -> None:
    config = Stage1Config()
    states = build_branch_states(config)
    time = np.linspace(0.0, 1.0, 257)
    q = anticipated_occupancy(time, config)
    assert np.max(np.abs(np.sum(q, axis=1) - 1.0)) < 1e-14
    for state in states.values():
        p = protention_distribution(time, state, config)
        normalization_error, negativity = probability_errors(p)
        assert normalization_error < 1e-14
        assert negativity == 0.0


def test_log_space_protention_remains_finite_for_extreme_relevance() -> None:
    config = Stage1Config(beta_w=1000.0)
    state = BranchState(
        branch=Branch.P,
        retention=np.zeros(2),
        relevance=np.array([-100.0, -1.0, 1.0, 100.0]),
    )
    p = protention_distribution(np.linspace(0.0, 1.0, 17), state, config)
    assert np.all(np.isfinite(p))
    assert np.max(np.abs(np.sum(p, axis=-1) - 1.0)) < 1e-14
