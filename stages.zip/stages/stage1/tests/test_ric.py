import numpy as np

from inh_stage1.config import Stage1Config
from inh_stage1.ric import compute_ric_timeseries, recursive_gain


def test_recursive_gain_is_nonnegative_in_locked_specification() -> None:
    config = Stage1Config()
    time = np.linspace(0.0, 1.0, 129)
    gain = recursive_gain(time, config)
    assert np.min(gain) >= 0.19
    assert np.max(gain) <= 0.51


def test_ric_calibration_is_finite_and_nondegenerate() -> None:
    ric = compute_ric_timeseries(Stage1Config(), n_steps=512)
    assert np.all(np.isfinite(ric.kappa))
    assert ric.calibration.scale > 0.0
