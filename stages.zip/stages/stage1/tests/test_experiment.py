from inh_stage1.config import Stage1Config
from inh_stage1.experiment import run_stage1


def test_stage1_design_numerics_and_specificity_pass() -> None:
    config = Stage1Config(
        n_steps=256,
        convergence_steps=(64, 128, 256),
        tol_convergence=5e-6,
        tol_reference_integrator=5e-7,
        min_observed_order=1.4,
    )
    result = run_stage1(config)
    assert result.summary["locked_design_checks"]["passed"]
    assert result.summary["numerical_qc"]["passed"]
    assert result.summary["specificity_controls"]["passed"]
    assert result.summary["implementation_validation_pass"]


def test_locked_scientific_status_is_reported_without_tuning() -> None:
    result = run_stage1(
        Stage1Config(n_steps=256, convergence_steps=(64, 128, 256), tol_convergence=5e-6, tol_reference_integrator=5e-7)
    )
    scientific = result.summary["scientific_criteria"]
    assert scientific["common_frame_main_effects_pass"]
    assert not scientific["gauge_invariant_conjugacy_main_effects_pass"]
    assert not scientific["interaction_pass"]
    assert scientific["status"] == "constructive_common_frame_effect_only"
    assert not scientific["passed"]
    assert not result.summary["overall_pass"]


def test_invalid_convergence_ratio_is_rejected() -> None:
    config = Stage1Config(convergence_steps=(100, 250, 500))
    try:
        config.validate()
    except ValueError as error:
        assert "common refinement ratio" in str(error)
    else:
        raise AssertionError("Expected convergence ratio validation failure")
