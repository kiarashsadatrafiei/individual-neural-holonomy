import numpy as np

from inh_stage1.algebra import (
    conjugacy_distance,
    special_unitary_error,
    unitarity_error,
)
from inh_stage1.config import Stage1Config
from inh_stage1.connection import make_generator
from inh_stage1.ric import compute_ric_timeseries
from inh_stage1.states import Branch, build_branch_states
from inh_stage1.transport import (
    convergence_metrics,
    gauge_test_metrics,
    integrate_generator,
    reference_integrator_error,
    reverse_path_error,
)


def test_transport_is_unitary_and_special_unitary() -> None:
    config = Stage1Config(n_steps=256)
    ric = compute_ric_timeseries(config)
    state = build_branch_states(config)[Branch.N]
    generator = make_generator(state, config, ric)
    result = integrate_generator(generator, config.n_steps)
    assert result.max_unitarity_error < config.tol_unitarity
    assert unitarity_error(result.holonomy) < config.tol_unitarity
    assert special_unitary_error(result.holonomy) < config.tol_determinant


def test_reverse_path_identity_for_all_branches() -> None:
    config = Stage1Config(n_steps=256)
    ric = compute_ric_timeseries(config)
    for state in build_branch_states(config).values():
        generator = make_generator(state, config, ric)
        assert reverse_path_error(generator, config.n_steps) < config.tol_reverse


def test_full_gauge_covariance_and_descriptor_invariance_for_all_branches() -> None:
    config = Stage1Config(n_steps=256)
    ric = compute_ric_timeseries(config)
    for state in build_branch_states(config).values():
        generator = make_generator(state, config, ric)
        metrics = gauge_test_metrics(generator, config, config.n_steps)
        assert metrics["raw_matrix_change"] > 1e-3
        assert metrics["covariance_error"] < config.tol_gauge
        assert metrics["descriptor_error"] < config.tol_gauge


def test_cf4_converges_with_finite_or_roundoff_limited_report() -> None:
    config = Stage1Config(n_steps=256, convergence_steps=(64, 128, 256), tol_convergence=5e-6)
    ric = compute_ric_timeseries(config)
    state = build_branch_states(config)[Branch.N]
    generator = make_generator(state, config, ric)
    metrics = convergence_metrics(
        generator,
        config.convergence_steps,
        roundoff_floor=config.convergence_roundoff_floor,
    )
    assert metrics["distance_n2_n3"] < config.tol_convergence
    if metrics["status"] == "resolved":
        assert metrics["observed_order"] is not None
        assert metrics["observed_order"] > config.min_observed_order
    else:
        assert metrics["status"] == "roundoff_limited"
        assert metrics["observed_order"] is None


def test_cf4_agrees_with_independent_dop853_reference() -> None:
    config = Stage1Config(n_steps=256, tol_reference_integrator=5e-7)
    ric = compute_ric_timeseries(config)
    generator = make_generator(build_branch_states(config)[Branch.N], config, ric)
    assert reference_integrator_error(generator, config.n_steps) < config.tol_reference_integrator


def test_common_frame_and_conjugacy_distances_are_distinct_estimands() -> None:
    config = Stage1Config(n_steps=256)
    ric = compute_ric_timeseries(config)
    states = build_branch_states(config)
    h_n = integrate_generator(make_generator(states[Branch.N], config, ric), 256).holonomy
    h_r = integrate_generator(make_generator(states[Branch.R], config, ric), 256).holonomy
    # Common-frame distance includes orientation differences; conjugacy distance
    # retains only the class-angle difference.
    from inh_stage1.algebra import group_distance

    assert group_distance(h_n, h_r) >= conjugacy_distance(h_n, h_r)
