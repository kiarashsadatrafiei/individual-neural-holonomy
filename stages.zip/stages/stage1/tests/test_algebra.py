import numpy as np

from inh_stage1.algebra import (
    GENERATORS,
    I2,
    P0,
    T1,
    antihermitian_error,
    conjugacy_distance,
    projector_hermiticity_error,
    projector_idempotence_error,
    special_unitary_error,
    su2_angle,
    su2_expm,
    traceless_error,
)


def test_su2_generators_are_antihermitian_and_traceless() -> None:
    assert max(antihermitian_error(generator) for generator in GENERATORS) < 1e-14
    assert max(traceless_error(generator) for generator in GENERATORS) < 1e-14


def test_projector_is_valid_rank_one_projector() -> None:
    assert projector_idempotence_error(P0) < 1e-14
    assert projector_hermiticity_error(P0) < 1e-14
    assert np.linalg.matrix_rank(P0) == 1


def test_stable_su2_angle_resolves_near_identity_rotations() -> None:
    theta = 1e-10
    matrix = su2_expm(2.0 * theta * T1)
    assert np.isclose(su2_angle(matrix), theta, rtol=1e-8, atol=1e-15)


def test_special_unitary_error_checks_det_equals_one() -> None:
    phase_shifted_identity = np.exp(0.2j) * I2
    assert np.isclose(abs(np.linalg.det(phase_shifted_identity)), 1.0)
    assert special_unitary_error(phase_shifted_identity) > 0.1
    assert special_unitary_error(I2) == 0.0


def test_conjugacy_distance_is_class_angle_difference() -> None:
    left = su2_expm(0.2 * T1)
    right = su2_expm(0.5 * T1)
    assert np.isclose(conjugacy_distance(left, right), 0.15, atol=1e-13)
