from __future__ import annotations

import csv
import hashlib
import json
import os
import platform
import subprocess
import sys
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import scipy

from .experiment import Stage1Result
from .states import Branch


def _json_default(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, complex):
        return {"real": value.real, "imag": value.imag}
    raise TypeError(f"Object of type {type(value)!r} is not JSON serializable")


def _git_commit() -> str | None:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL, text=True
        ).strip()
    except Exception:
        return None


def configuration_hash(config: dict[str, Any]) -> str:
    payload = json.dumps(config, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def build_manifest(result: Stage1Result) -> dict[str, Any]:
    config = result.config.to_dict()
    return {
        "project": "individual-neural-holonomy-stage1",
        "version": "0.2.0",
        "configuration_hash": configuration_hash(config),
        "configuration": config,
        "git_commit": _git_commit(),
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "pid": os.getpid(),
    }


def _save_main_figure(result: Stage1Result, output_path: Path) -> None:
    time = result.arrays["time"]
    path = result.arrays["neural_path"]

    figure, axes = plt.subplots(2, 2, figsize=(11, 8.5), constrained_layout=True)

    axes[0, 0].plot(path[:, 0], path[:, 1], linewidth=2)
    axes[0, 0].scatter(path[0, 0], path[0, 1], marker="o", label="start/end")
    axes[0, 0].set_title("Shared neural probe loop")
    axes[0, 0].set_xlabel("x₁")
    axes[0, 0].set_ylabel("x₂")
    axes[0, 0].axis("equal")
    axes[0, 0].legend()

    for branch in Branch:
        axes[0, 1].plot(
            time,
            result.arrays[f"protention_scalar_{branch.value}"],
            label=branch.value,
        )
    axes[0, 1].set_title("Branch-specific protentional organization")
    axes[0, 1].set_xlabel("normalized probe time")
    axes[0, 1].set_ylabel("protentional contrast")
    axes[0, 1].legend()

    axes[1, 0].plot(time, result.arrays["kappa"], linewidth=2)
    axes[1, 0].axhline(0.0, linewidth=1, linestyle="--")
    axes[1, 0].set_title("RIC margin shared by construction")
    axes[1, 0].set_xlabel("normalized probe time")
    axes[1, 0].set_ylabel("κ(t)")

    labels = [branch.value for branch in Branch]
    angles = [result.branches[branch].angle for branch in Branch]
    axes[1, 1].bar(labels, angles)
    axes[1, 1].set_title("Gauge-invariant holonomy class angle")
    axes[1, 1].set_xlabel("counterfactual branch")
    axes[1, 1].set_ylabel("θ(H), radians")

    figure.suptitle("Individual Neural Holonomy — Stage 1")
    figure.savefig(output_path, dpi=300)
    plt.close(figure)


def _save_effect_figure(result: Stage1Result, output_path: Path) -> None:
    estimands = result.summary["estimands"]
    threshold = result.summary["scientific_criteria"]["epsilon_H"]
    branches = ["R", "P", "RP"]
    common = [estimands["common_frame_transport_effects"][key] for key in branches]
    conjugacy = [estimands["gauge_invariant_conjugacy_effects"][key] for key in branches]
    eigenphase = [estimands["gauge_invariant_eigenphase_effects"][key] for key in branches]

    figure, axes = plt.subplots(1, 2, figsize=(12, 4.8), constrained_layout=True)
    x = np.arange(len(branches), dtype=float)
    width = 0.25
    axes[0].bar(x - width, common, width=width, label="common-frame distance")
    axes[0].bar(x, conjugacy, width=width, label="conjugacy-angle distance")
    axes[0].bar(x + width, eigenphase, width=width, label="eigenphase distance")
    axes[0].axhline(threshold, linestyle="--", linewidth=1, label="frozen threshold")
    axes[0].set_xticks(x, branches)
    axes[0].set_ylabel("transport difference, radians")
    axes[0].set_title("Frame-dependent and gauge-invariant estimands")
    axes[0].legend(fontsize=8)

    interaction_labels = ["R→P", "P→R"]
    interactions = [
        estimands["interaction_R_then_P"],
        estimands["interaction_P_then_R"],
    ]
    axes[1].bar(interaction_labels, interactions)
    axes[1].axhline(threshold, linestyle="--", linewidth=1, label="frozen threshold")
    axes[1].set_ylabel("interaction residual angle, radians")
    axes[1].set_title("Retention–protention interaction criterion")
    axes[1].legend(fontsize=8)

    figure.suptitle("Stage 1 scientific estimands")
    figure.savefig(output_path, dpi=300)
    plt.close(figure)


def _save_qc_figure(result: Stage1Result, output_path: Path) -> None:
    numerical = result.summary["numerical_qc"]
    convergence = numerical["convergence"]
    steps = np.asarray(convergence["steps"], dtype=float)
    errors = np.asarray(
        [convergence["distance_n1_n2"], convergence["distance_n2_n3"]],
        dtype=float,
    )
    error_steps = steps[1:]

    qc_labels = [
        "unitarity",
        "det(H)-1",
        "gauge covariance",
        "gauge descriptor",
        "reverse path",
        "CF4 vs DOP853",
    ]
    qc_values = [
        numerical["max_final_unitarity_error"],
        numerical["max_special_unitary_error"],
        numerical["max_gauge_covariance_error"],
        numerical["max_gauge_descriptor_error"],
        numerical["max_reverse_path_error"],
        numerical["cf4_vs_dop853_reference_error"],
    ]

    figure, axes = plt.subplots(1, 2, figsize=(12, 4.8), constrained_layout=True)
    axes[0].loglog(error_steps, errors, marker="o")
    axes[0].set_xlabel("finer resolution (steps)")
    axes[0].set_ylabel("successive holonomy distance")
    axes[0].set_title(
        f"CF4 convergence ({convergence['status']}; order={convergence['observed_order']:.2f})" if convergence['observed_order'] is not None else f"CF4 convergence ({convergence['status']})"
    )
    axes[0].grid(True, which="both", alpha=0.3)

    positions = np.arange(len(qc_labels))
    safe_values = np.maximum(np.asarray(qc_values, dtype=float), np.finfo(float).tiny)
    axes[1].barh(positions, safe_values)
    axes[1].set_yticks(positions, qc_labels)
    axes[1].set_xscale("log")
    axes[1].set_xlabel("error magnitude")
    axes[1].set_title("Numerical and geometric validation")

    figure.suptitle("Stage 1 numerical QC")
    figure.savefig(output_path, dpi=300)
    plt.close(figure)


def _save_branch_csv(result: Stage1Result, output_path: Path) -> None:
    estimands = result.summary["estimands"]
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "branch",
                "class_angle_rad",
                "eigenphase_1_rad",
                "eigenphase_2_rad",
                "common_frame_distance_from_N",
                "conjugacy_distance_from_N",
                "eigenphase_distance_from_N",
                "unitarity_error",
                "special_unitary_error",
            ]
        )
        for branch in Branch:
            key = branch.value
            writer.writerow(
                [
                    key,
                    result.branches[branch].angle,
                    result.branches[branch].eigenphases[0],
                    result.branches[branch].eigenphases[1],
                    0.0
                    if branch is Branch.N
                    else estimands["common_frame_transport_effects"][key],
                    0.0
                    if branch is Branch.N
                    else estimands["gauge_invariant_conjugacy_effects"][key],
                    0.0
                    if branch is Branch.N
                    else estimands["gauge_invariant_eigenphase_effects"][key],
                    result.branches[branch].final_unitarity_error,
                    result.branches[branch].special_unitary_error,
                ]
            )


def _save_timeseries_csv(result: Stage1Result, output_path: Path) -> None:
    time = result.arrays["time"]
    fields = [
        "time",
        "x1",
        "x2",
        "kappa",
        "curvature",
        "recursive_gain",
        "dispersion",
        "protention_N",
        "protention_R",
        "protention_P",
        "protention_RP",
    ]
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for index, t in enumerate(time):
            writer.writerow(
                {
                    "time": t,
                    "x1": result.arrays["neural_path"][index, 0],
                    "x2": result.arrays["neural_path"][index, 1],
                    "kappa": result.arrays["kappa"][index],
                    "curvature": result.arrays["curvature"][index],
                    "recursive_gain": result.arrays["recursive_gain"][index],
                    "dispersion": result.arrays["dispersion"][index],
                    "protention_N": result.arrays["protention_scalar_N"][index],
                    "protention_R": result.arrays["protention_scalar_R"][index],
                    "protention_P": result.arrays["protention_scalar_P"][index],
                    "protention_RP": result.arrays["protention_scalar_RP"][index],
                }
            )


def _save_report(result: Stage1Result, output_path: Path) -> None:
    summary = result.summary
    estimands = summary["estimands"]
    scientific = summary["scientific_criteria"]
    numerical = summary["numerical_qc"]
    specificity = summary["specificity_controls"]

    lines = [
        "# Stage 1 corrected validation report",
        "",
        "## Scope",
        "",
        summary["interpretation_scope"]["supported_claim"],
        "",
        "**Not yet supported:** " + summary["interpretation_scope"]["not_yet_supported"],
        "",
        "## Status",
        "",
        f"- Locked construction checks: **{'PASS' if summary['locked_design_checks']['passed'] else 'FAIL'}**",
        f"- Numerical and geometric QC: **{'PASS' if numerical['passed'] else 'FAIL'}**",
        f"- Specificity controls: **{'PASS' if specificity['passed'] else 'FAIL'}**",
        f"- Implementation validation: **{'PASS' if summary['implementation_validation_pass'] else 'FAIL'}**",
        f"- Scientific criterion: **{scientific['status']}**",
        "",
        "## Main estimands",
        "",
        "### Common-frame counterfactual distances",
        "",
    ]
    for key, value in estimands["common_frame_transport_effects"].items():
        lines.append(f"- {key} vs N: {value:.8f} rad")
    lines.extend(["", "### Gauge-invariant conjugacy-class distances", ""])
    for key, value in estimands["gauge_invariant_conjugacy_effects"].items():
        lines.append(f"- {key} vs N: {value:.8f} rad")
    lines.extend(
        [
            "",
            "### Interaction residuals",
            "",
            f"- R then P: {estimands['interaction_R_then_P']:.8f} rad",
            f"- P then R: {estimands['interaction_P_then_R']:.8f} rad",
            f"- Frozen scientific threshold: {scientific['epsilon_H']:.8f} rad",
            "",
            "The common-frame branch effects exceed the frozen threshold, but the "
            "gauge-invariant conjugacy effects and the interaction residual do not. "
            "Accordingly, Stage 1 is retained as a constructive common-frame proof-"
            "of-principle rather than evidence for emergent cross-subject neural "
            "individuation.",
            "",
            "## Numerical validation",
            "",
            f"- Maximum final unitarity error: {numerical['max_final_unitarity_error']:.3e}",
            f"- Maximum SU(2) determinant error |det(H)-1|: {numerical['max_special_unitary_error']:.3e}",
            f"- Maximum full gauge covariance error: {numerical['max_gauge_covariance_error']:.3e}",
            f"- Maximum gauge descriptor error: {numerical['max_gauge_descriptor_error']:.3e}",
            f"- Maximum reverse-path error: {numerical['max_reverse_path_error']:.3e}",
            f"- CF4 versus DOP853 reference error: {numerical['cf4_vs_dop853_reference_error']:.3e}",
            f"- Convergence status: {numerical['convergence']['status']}",
            f"- Observed order: {numerical['convergence']['observed_order']}",
            "",
            "## Interpretation for the manuscript",
            "",
            "This corrected Stage 1 implementation validates the mathematical "
            "possibility of transport differentiation under exactly matched base "
            "trajectories and RIC profiles. Retention and prospective relevance "
            "enter the declared connection in the shared clone frame, so the run "
            "is a constructive proof-of-principle. It does not yet demonstrate "
            "that slow experience-dependent remodeling produces the connection "
            "difference emergently. That stronger claim belongs to Stage 2.",
            "",
        ]
    )
    output_path.write_text("\n".join(lines), encoding="utf-8")


def save_result(result: Stage1Result, output_dir: str | Path) -> Path:
    output = Path(output_dir)
    figures = output / "figures"
    data = output / "data"
    figures.mkdir(parents=True, exist_ok=True)
    data.mkdir(parents=True, exist_ok=True)

    with (output / "summary.json").open("w", encoding="utf-8") as handle:
        json.dump(result.summary, handle, indent=2, default=_json_default, allow_nan=False)

    with (output / "manifest.json").open("w", encoding="utf-8") as handle:
        json.dump(build_manifest(result), handle, indent=2, default=_json_default, allow_nan=False)

    np.savez_compressed(data / "branch_timeseries.npz", **result.arrays)
    _save_branch_csv(result, data / "branch_summary.csv")
    _save_timeseries_csv(result, data / "timeseries.csv")
    _save_main_figure(result, figures / "figure_stage1_main.png")
    _save_effect_figure(result, figures / "figure_transport_effects.png")
    _save_qc_figure(result, figures / "figure_numerical_qc.png")
    _save_report(result, output / "VALIDATION_REPORT.md")
    return output
