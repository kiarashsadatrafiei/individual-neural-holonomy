from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Any

import numpy as np
from numpy.typing import NDArray
from scipy.integrate import solve_ivp

from .algebra import I2, T1, T3, group_distance, su2_angle, su2_expm
from .config import Stage1Config

ComplexMatrix = NDArray[np.complex128]
Generator = Callable[[float], ComplexMatrix]


@dataclass(frozen=True)
class TransportResult:
    holonomy: ComplexMatrix
    max_unitarity_error: float


def integrate_generator(
    generator: Generator,
    n_steps: int,
    *,
    method: str = "cf4",
) -> TransportResult:
    """Integrate dU/dt = -A(t)U with Lie-group-preserving exponential steps.

    ``cf4`` is a fourth-order two-exponential commutator-free Magnus method.
    ``midpoint`` is retained as an independent second-order reference method.
    Both preserve unitarity up to matrix-exponential roundoff when A is
    anti-Hermitian.
    """
    if n_steps <= 0:
        raise ValueError("n_steps must be positive")
    if method not in {"cf4", "midpoint"}:
        raise ValueError(f"Unknown integration method: {method}")

    dt = 1.0 / n_steps
    transport = I2.copy()
    max_unitarity_error = 0.0

    sqrt3 = np.sqrt(3.0)
    c1 = 0.5 - sqrt3 / 6.0
    c2 = 0.5 + sqrt3 / 6.0
    a1 = (3.0 - 2.0 * sqrt3) / 12.0
    a2 = (3.0 + 2.0 * sqrt3) / 12.0

    for index in range(n_steps):
        t0 = index * dt
        if method == "midpoint":
            local_generator = generator(t0 + 0.5 * dt)
            step_operator = su2_expm(-local_generator * dt)
        else:
            g1 = generator(t0 + c1 * dt)
            g2 = generator(t0 + c2 * dt)
            omega_left = -dt * (a1 * g1 + a2 * g2)
            omega_right = -dt * (a2 * g1 + a1 * g2)
            step_operator = su2_expm(omega_left) @ su2_expm(omega_right)

        transport = step_operator @ transport
        error = float(np.linalg.norm(transport.conj().T @ transport - I2, ord="fro"))
        max_unitarity_error = max(max_unitarity_error, error)

    return TransportResult(
        holonomy=transport.astype(np.complex128),
        max_unitarity_error=max_unitarity_error,
    )


def integrate_generator_reference(
    generator: Generator,
    *,
    rtol: float = 1e-12,
    atol: float = 1e-14,
) -> ComplexMatrix:
    """High-accuracy DOP853 integration used only as a numerical cross-check."""

    def rhs(t: float, flattened: NDArray[np.complex128]) -> NDArray[np.complex128]:
        matrix = flattened.reshape(2, 2)
        return (-generator(t) @ matrix).reshape(-1)

    solution = solve_ivp(
        rhs,
        (0.0, 1.0),
        I2.reshape(-1),
        method="DOP853",
        rtol=rtol,
        atol=atol,
    )
    if not solution.success:
        raise RuntimeError(f"Reference integration failed: {solution.message}")
    return solution.y[:, -1].reshape(2, 2).astype(np.complex128)


def reverse_generator(generator: Generator) -> Generator:
    return lambda t: -generator(1.0 - t)


def gauge_matrix_and_derivative(t: float, amplitude: float) -> tuple[ComplexMatrix, ComplexMatrix]:
    x = amplitude * (
        np.sin(2.0 * np.pi * t) * T1 + np.cos(2.0 * np.pi * t) * T3
    )
    x_dot = amplitude * 2.0 * np.pi * (
        np.cos(2.0 * np.pi * t) * T1 - np.sin(2.0 * np.pi * t) * T3
    )
    # ||x|| in su(2) is constant along this periodic gauge path, so the
    # derivative of exp(x(t)) has a closed form.
    half_angle = amplitude / 2.0
    if abs(amplitude) < 1e-12:
        factor = 1.0
    else:
        factor = 2.0 * np.sin(half_angle) / amplitude
    g = np.cos(half_angle) * I2 + factor * x
    g_dot = factor * x_dot
    return g.astype(np.complex128), g_dot.astype(np.complex128)


def gauge_transform_generator(generator: Generator, amplitude: float) -> Generator:
    def transformed(t: float) -> ComplexMatrix:
        g, g_dot = gauge_matrix_and_derivative(t, amplitude)
        g_inv = g.conj().T
        return (g_inv @ generator(t) @ g + g_inv @ g_dot).astype(np.complex128)

    return transformed


def reverse_path_error(generator: Generator, n_steps: int) -> float:
    forward = integrate_generator(generator, n_steps).holonomy
    reverse = integrate_generator(reverse_generator(generator), n_steps).holonomy
    return float(np.linalg.norm(reverse @ forward - I2, ord="fro"))


def gauge_test_metrics(
    generator: Generator,
    config: Stage1Config,
    n_steps: int,
) -> dict[str, float]:
    """Test full gauge covariance and descriptor invariance.

    For A' = g^-1 A g + g^-1 dg and dU/dt=-AU,
    U'(1,0)=g(1)^-1 U(1,0) g(0).
    """
    original = integrate_generator(generator, n_steps).holonomy
    transformed = integrate_generator(
        gauge_transform_generator(generator, config.gauge_amplitude), n_steps
    ).holonomy
    g0, _ = gauge_matrix_and_derivative(0.0, config.gauge_amplitude)
    g1, _ = gauge_matrix_and_derivative(1.0, config.gauge_amplitude)
    expected = g1.conj().T @ original @ g0
    return {
        "covariance_error": float(np.linalg.norm(transformed - expected, ord="fro")),
        "descriptor_error": float(abs(su2_angle(original) - su2_angle(transformed))),
        "raw_matrix_change": float(np.linalg.norm(transformed - original, ord="fro")),
    }


def gauge_descriptor_error(generator: Generator, config: Stage1Config, n_steps: int) -> float:
    """Backward-compatible scalar wrapper around :func:`gauge_test_metrics`."""
    return gauge_test_metrics(generator, config, n_steps)["descriptor_error"]


def convergence_metrics(
    generator: Generator,
    steps: tuple[int, int, int],
    *,
    roundoff_floor: float = 5e-13,
) -> dict[str, Any]:
    n1, n2, n3 = steps
    ratio_1 = n2 / n1
    ratio_2 = n3 / n2
    if abs(ratio_1 - ratio_2) > 1e-12:
        raise ValueError("Convergence resolutions require a common refinement ratio")

    h1 = integrate_generator(generator, n1).holonomy
    h2 = integrate_generator(generator, n2).holonomy
    h3 = integrate_generator(generator, n3).holonomy
    e12 = group_distance(h1, h2)
    e23 = group_distance(h2, h3)

    if e12 <= roundoff_floor or e23 <= roundoff_floor:
        order: float | None = None
        status = "roundoff_limited"
    else:
        order = float(np.log(e12 / e23) / np.log(ratio_1))
        status = "resolved"

    return {
        "steps": [n1, n2, n3],
        "refinement_ratio": ratio_1,
        "distance_n1_n2": e12,
        "distance_n2_n3": e23,
        "observed_order": order,
        "status": status,
    }


def reference_integrator_error(generator: Generator, n_steps: int) -> float:
    numerical = integrate_generator(generator, n_steps, method="cf4").holonomy
    reference = integrate_generator_reference(generator)
    return group_distance(numerical, reference)
