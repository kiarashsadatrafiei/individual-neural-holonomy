from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray
from scipy.linalg import eigvals, expm

from .config import Stage1Config
from .states import neural_path

RealVector = NDArray[np.float64]

STATE_CENTERS = np.array(
    [[1.0, 0.0], [0.0, 1.0], [-1.0, 0.0], [0.0, -1.0]], dtype=np.float64
)
J_ROT = np.array([[0.0, -1.0], [1.0, 0.0]], dtype=np.float64)


@dataclass(frozen=True)
class RICCalibration:
    critical: float
    scale: float


@dataclass(frozen=True)
class RICTimeseries:
    time: RealVector
    entropy: RealVector
    dispersion: RealVector
    recursive_gain: RealVector
    curvature: RealVector
    kappa: RealVector
    calibration: RICCalibration


def symbolic_distribution(x: RealVector, config: Stage1Config) -> RealVector:
    logits = config.beta_s * np.einsum("...d,kd->...k", x, STATE_CENTERS)
    logits = logits - np.max(logits, axis=-1, keepdims=True)
    exp_logits = np.exp(logits)
    return exp_logits / np.sum(exp_logits, axis=-1, keepdims=True)


def symbolic_entropy(x: RealVector, config: Stage1Config) -> RealVector:
    q = symbolic_distribution(x, config)
    return -np.sum(q * np.log(np.clip(q, 1e-15, None)), axis=-1)


def entropy_gradient(x: RealVector, config: Stage1Config) -> RealVector:
    """Analytic gradient of S(x) for a softmax distribution over fixed state centers."""
    q = symbolic_distribution(x, config)
    center_mean = np.einsum("...k,kd->...d", q, STATE_CENTERS)
    dq = config.beta_s * q[..., :, None] * (STATE_CENTERS - center_mean[..., None, :])
    factors = -(np.log(np.clip(q, 1e-15, None)) + 1.0)
    return np.einsum("...k,...kd->...d", factors, dq)


def entropy_dispersion(x: RealVector, config: Stage1Config) -> RealVector:
    grad = entropy_gradient(x, config)
    return np.linalg.norm(grad, axis=-1)


def recurrence_operator(t: float, config: Stage1Config) -> NDArray[np.float64]:
    amplitude = config.recurrence_l0 + config.recurrence_l1 * np.cos(2.0 * np.pi * t)
    generator = amplitude * np.eye(2) + config.recurrence_omega * J_ROT
    return expm(generator).astype(np.float64)


def recursive_gain(t: float | RealVector, config: Stage1Config) -> RealVector:
    t_arr = np.asarray(t, dtype=np.float64)
    amplitude = config.recurrence_l0 + config.recurrence_l1 * np.cos(2.0 * np.pi * t_arr)
    # For R_rec = exp(amplitude I + omega J), the rotational factor has unit
    # spectral modulus and rho(R_rec) = exp(amplitude).
    gain = amplitude - np.log(config.rho_ref)
    return np.asarray(gain, dtype=np.float64)


def robust_calibration(curvature: RealVector) -> RICCalibration:
    critical = float(np.median(curvature))
    mad = float(np.median(np.abs(curvature - critical)))
    scale = 1.4826 * mad
    if not np.isfinite(scale) or scale <= 1e-12:
        raise ValueError("RIC calibration scale is degenerate")
    return RICCalibration(critical=critical, scale=scale)


def compute_ric_timeseries(config: Stage1Config, n_steps: int | None = None) -> RICTimeseries:
    steps = config.n_steps if n_steps is None else n_steps
    time = np.linspace(0.0, 1.0, steps + 1, dtype=np.float64)
    x = neural_path(time)
    entropy = symbolic_entropy(x, config)
    dispersion = entropy_dispersion(x, config)
    gain = recursive_gain(time, config)
    curvature = config.ric_alpha * gain - config.ric_beta * dispersion
    calibration = robust_calibration(curvature)
    kappa = (curvature - calibration.critical) / calibration.scale
    return RICTimeseries(
        time=time,
        entropy=entropy,
        dispersion=dispersion,
        recursive_gain=gain,
        curvature=curvature,
        kappa=kappa,
        calibration=calibration,
    )



def curvature_at(t: float, config: Stage1Config) -> float:
    x = neural_path(float(t))
    dispersion = float(entropy_dispersion(x, config))
    gain = float(recursive_gain(float(t), config))
    return config.ric_alpha * gain - config.ric_beta * dispersion


def kappa_at(t: float, config: Stage1Config, calibration: RICCalibration) -> float:
    return (curvature_at(t % 1.0, config) - calibration.critical) / calibration.scale


def interpolate_kappa(t: float, ric: RICTimeseries) -> float:
    # Periodic interpolation on [0, 1].
    t_wrapped = t % 1.0
    return float(np.interp(t_wrapped, ric.time, ric.kappa))
