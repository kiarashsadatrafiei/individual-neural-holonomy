from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

import numpy as np
from numpy.typing import NDArray

from .config import Stage1Config

RealVector = NDArray[np.float64]


class Branch(str, Enum):
    N = "N"
    R = "R"
    P = "P"
    RP = "RP"


@dataclass(frozen=True)
class BranchState:
    branch: Branch
    retention: RealVector
    relevance: RealVector

    @property
    def retention_scalar(self) -> float:
        return float(np.tanh(self.retention[0]))


RETENTION_EVENT = np.array([1.0, 0.0], dtype=np.float64)
RELEVANCE_EVENT = np.array([-0.5, -0.5, 0.5, 0.5], dtype=np.float64)
PROTENTION_CONTRAST = np.array([-1.0, -1.0 / 3.0, 1.0 / 3.0, 1.0], dtype=np.float64)
TARGET_PHASES = 2.0 * np.pi * np.arange(4, dtype=np.float64) / 4.0


def neural_path(t: float | NDArray[np.float64]) -> RealVector:
    t_arr = np.asarray(t, dtype=np.float64)
    return np.stack((np.cos(2.0 * np.pi * t_arr), np.sin(2.0 * np.pi * t_arr)), axis=-1)


def neural_velocity(t: float | NDArray[np.float64]) -> RealVector:
    t_arr = np.asarray(t, dtype=np.float64)
    return 2.0 * np.pi * np.stack(
        (-np.sin(2.0 * np.pi * t_arr), np.cos(2.0 * np.pi * t_arr)), axis=-1
    )


def update_memory(
    current: RealVector,
    event: RealVector,
    gamma: float,
) -> RealVector:
    return ((1.0 - gamma) * current + gamma * event).astype(np.float64)


def build_branch_states(config: Stage1Config) -> dict[Branch, BranchState]:
    states: dict[Branch, BranchState] = {}
    for branch in Branch:
        retention = np.zeros(2, dtype=np.float64)
        relevance = np.zeros(4, dtype=np.float64)
        retention_event = RETENTION_EVENT if branch in (Branch.R, Branch.RP) else np.zeros(2)
        relevance_event = RELEVANCE_EVENT if branch in (Branch.P, Branch.RP) else np.zeros(4)

        for _ in range(config.n_individuation_episodes):
            retention = update_memory(retention, retention_event, config.gamma_r)
            relevance = update_memory(relevance, relevance_event, config.gamma_p)

        states[branch] = BranchState(branch=branch, retention=retention, relevance=relevance)
    return states


def anticipated_occupancy(t: float | NDArray[np.float64], config: Stage1Config) -> NDArray[np.float64]:
    t_arr = np.asarray(t, dtype=np.float64)
    future_phase = 2.0 * np.pi * (t_arr[..., None] + config.tau_p)
    logits = config.beta_q * np.cos(TARGET_PHASES - future_phase)
    logits = logits - np.max(logits, axis=-1, keepdims=True)
    exp_logits = np.exp(logits)
    return exp_logits / np.sum(exp_logits, axis=-1, keepdims=True)


def relevance_log_weights(state: BranchState, config: Stage1Config) -> NDArray[np.float64]:
    """Unnormalized log relevance weights.

    Keeping this quantity in log space prevents overflow during future parameter
    sweeps and makes the separation between occupancy and prospective relevance
    explicit.
    """
    return (config.beta_w * state.relevance).astype(np.float64)


def relevance_weights(state: BranchState, config: Stage1Config) -> NDArray[np.float64]:
    """Numerically stabilized relative weights (maximum normalized to one)."""
    logits = relevance_log_weights(state, config)
    return np.exp(logits - np.max(logits)).astype(np.float64)


def protention_distribution(
    t: float | NDArray[np.float64],
    state: BranchState,
    config: Stage1Config,
) -> NDArray[np.float64]:
    q = anticipated_occupancy(t, config)
    log_q = np.log(np.clip(q, np.finfo(np.float64).tiny, None))
    logits = log_q + relevance_log_weights(state, config)
    logits = logits - np.max(logits, axis=-1, keepdims=True)
    numerator = np.exp(logits)
    return numerator / np.sum(numerator, axis=-1, keepdims=True)


def protention_scalar(
    t: float | NDArray[np.float64],
    state: BranchState,
    config: Stage1Config,
) -> NDArray[np.float64]:
    p = protention_distribution(t, state, config)
    return np.asarray(p @ PROTENTION_CONTRAST, dtype=np.float64)


def probability_errors(probabilities: NDArray[np.float64]) -> tuple[float, float]:
    sums = np.sum(probabilities, axis=-1)
    normalization_error = float(np.max(np.abs(sums - 1.0)))
    negativity = float(max(0.0, -np.min(probabilities)))
    return normalization_error, negativity
