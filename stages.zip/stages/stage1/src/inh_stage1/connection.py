from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from numpy.typing import NDArray

from .algebra import P0, Q0, T1, T2, T3, antihermitian_error, traceless_error
from .config import Stage1Config
from .ric import RICTimeseries, kappa_at
from .states import BranchState, neural_path, neural_velocity, protention_scalar

ComplexMatrix = NDArray[np.complex128]


@dataclass(frozen=True)
class ConnectionComponents:
    a1: ComplexMatrix
    a2: ComplexMatrix
    a1_parallel: ComplexMatrix
    a2_parallel: ComplexMatrix
    b1: ComplexMatrix
    b2: ComplexMatrix


def chi(kappa: float, config: Stage1Config) -> float:
    argument = np.clip(config.chi_slope * kappa, -60.0, 60.0)
    return float(1.0 / (1.0 + np.exp(argument)))


def raw_connection_components(
    t: float,
    state: BranchState,
    config: Stage1Config,
    *,
    commutative: bool = False,
) -> tuple[ComplexMatrix, ComplexMatrix]:
    x1, x2 = neural_path(t)
    retention = state.retention_scalar
    protention = float(protention_scalar(t, state, config))

    if commutative:
        a1_scalar = (
            config.connection_base * x2
            + config.connection_retention * retention
            + config.connection_protention * protention
        )
        a2_scalar = (
            -config.connection_base * x1
            + config.connection_retention * retention
            + config.connection_protention * protention
        )
        return a1_scalar * T3, a2_scalar * T3

    a1 = (
        config.connection_base * x2 * T1
        + config.connection_retention * retention * T2
        + config.connection_protention * protention * T3
    )
    a2 = (
        -config.connection_base * x1 * T2
        + config.connection_retention * retention * T3
        + config.connection_protention * protention * T1
    )
    return a1.astype(np.complex128), a2.astype(np.complex128)


def decompose_component(component: ComplexMatrix) -> tuple[ComplexMatrix, ComplexMatrix]:
    parallel = P0 @ component @ P0 + Q0 @ component @ Q0
    mixing = P0 @ component @ Q0 + Q0 @ component @ P0
    return parallel.astype(np.complex128), mixing.astype(np.complex128)


def connection_components(
    t: float,
    state: BranchState,
    config: Stage1Config,
    *,
    commutative: bool = False,
) -> ConnectionComponents:
    a1, a2 = raw_connection_components(t, state, config, commutative=commutative)
    a1_parallel, b1 = decompose_component(a1)
    a2_parallel, b2 = decompose_component(a2)
    return ConnectionComponents(a1, a2, a1_parallel, a2_parallel, b1, b2)


def effective_components(
    t: float,
    state: BranchState,
    config: Stage1Config,
    ric: RICTimeseries,
    *,
    commutative: bool = False,
) -> tuple[ComplexMatrix, ComplexMatrix]:
    components = connection_components(t, state, config, commutative=commutative)
    permeability = chi(kappa_at(t, config, ric.calibration), config)
    a1_eff = components.a1_parallel + permeability * components.b1
    a2_eff = components.a2_parallel + permeability * components.b2
    if antihermitian_error(a1_eff) > config.tol_antihermitian:
        raise FloatingPointError("A1 effective component lost anti-Hermiticity")
    if antihermitian_error(a2_eff) > config.tol_antihermitian:
        raise FloatingPointError("A2 effective component lost anti-Hermiticity")
    if traceless_error(a1_eff) > config.tol_traceless:
        raise FloatingPointError("A1 effective component left su(2): nonzero trace")
    if traceless_error(a2_eff) > config.tol_traceless:
        raise FloatingPointError("A2 effective component left su(2): nonzero trace")
    return a1_eff, a2_eff


def pulled_back_generator(
    t: float,
    state: BranchState,
    config: Stage1Config,
    ric: RICTimeseries,
    *,
    commutative: bool = False,
) -> ComplexMatrix:
    a1_eff, a2_eff = effective_components(t, state, config, ric, commutative=commutative)
    dx1, dx2 = neural_velocity(t)
    generator = a1_eff * dx1 + a2_eff * dx2
    if antihermitian_error(generator) > config.tol_antihermitian:
        raise FloatingPointError("Pulled-back connection lost anti-Hermiticity")
    if traceless_error(generator) > config.tol_traceless:
        raise FloatingPointError("Pulled-back connection left su(2): nonzero trace")
    return generator.astype(np.complex128)


def make_generator(
    state: BranchState,
    config: Stage1Config,
    ric: RICTimeseries,
    *,
    commutative: bool = False,
) -> Callable[[float], ComplexMatrix]:
    return lambda t: pulled_back_generator(
        t, state, config, ric, commutative=commutative
    )
