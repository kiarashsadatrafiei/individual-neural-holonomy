from __future__ import annotations

import argparse
import json
import sys

import numpy as np

from .config import Stage1Config
from .experiment import run_stage1
from .io import save_result


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the corrected locked Stage 1 INH simulation"
    )
    parser.add_argument("--output", default="results/stage1", help="Output directory")
    parser.add_argument("--steps", type=int, default=None, help="Override main CF4 step count")
    parser.add_argument(
        "--convergence-steps",
        type=int,
        nargs=3,
        metavar=("N1", "N2", "N3"),
        default=None,
        help="Three resolutions with a common refinement ratio",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Return a nonzero exit status unless the frozen scientific criterion passes",
    )
    args = parser.parse_args()

    overrides: dict[str, object] = {}
    if args.steps is not None:
        overrides["n_steps"] = args.steps
    if args.convergence_steps is not None:
        overrides["convergence_steps"] = tuple(args.convergence_steps)

    config = Stage1Config(**overrides)
    result = run_stage1(config)
    output = save_result(result, args.output)
    print(json.dumps(result.summary, indent=2, allow_nan=False, default=lambda value: value.item() if isinstance(value, np.generic) else str(value)))
    print(f"\nSaved outputs to: {output.resolve()}")

    if args.strict and not result.summary["scientific_criteria"]["passed"]:
        print(
            "Strict mode: frozen scientific criterion did not pass; "
            "implementation outputs were still saved.",
            file=sys.stderr,
        )
        raise SystemExit(2)


if __name__ == "__main__":
    main()
