from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class Stage1Config:
    """Locked numerical and mathematical configuration for Stage 1."""

    # Probe and discretization
    n_steps: int = 4096
    convergence_steps: tuple[int, int, int] = (256, 512, 1024)
    auxiliary_steps: int = 1024

    # Retention/protention individuation
    n_individuation_episodes: int = 12
    gamma_r: float = 0.25
    gamma_p: float = 0.25
    beta_q: float = 2.5
    beta_w: float = 1.5
    tau_p: float = 0.25

    # RIC
    beta_s: float = 4.0
    recurrence_l0: float = 0.35
    recurrence_l1: float = 0.15
    recurrence_omega: float = 0.10
    rho_ref: float = 1.0
    ric_alpha: float = 1.0
    ric_beta: float = 1.0

    # Connection and RIC gating
    connection_base: float = 0.40
    connection_retention: float = 0.20
    connection_protention: float = 0.20
    chi_slope: float = 2.0

    # Gauge test
    gauge_amplitude: float = 0.40

    # QC tolerances
    tol_antihermitian: float = 1e-12
    tol_traceless: float = 1e-12
    tol_projector: float = 1e-12
    tol_unitarity: float = 1e-10
    tol_determinant: float = 1e-10
    tol_probability: float = 1e-12
    tol_probability_negative: float = 1e-14
    tol_reverse: float = 1e-8
    tol_gauge: float = 1e-8
    tol_convergence: float = 1e-6
    tol_reference_integrator: float = 1e-7
    min_observed_order: float = 1.5
    convergence_roundoff_floor: float = 5e-13

    # Locked construction checks
    tol_state_match: float = 1e-12
    tol_endpoint_match: float = 1e-12
    tol_kappa_match: float = 1e-10

    # Scientific thresholds: frozen before interpreting the corrected run.
    min_holonomy_effect: float = 0.02
    min_ablation_effect: float = 0.002

    def validate(self) -> None:
        if self.n_steps < 32:
            raise ValueError("n_steps must be at least 32")
        if self.n_steps % 2:
            raise ValueError("n_steps must be even")
        if self.auxiliary_steps < 32:
            raise ValueError("auxiliary_steps must be at least 32")
        if not (0.0 <= self.gamma_r <= 1.0):
            raise ValueError("gamma_r must be in [0, 1]")
        if not (0.0 <= self.gamma_p <= 1.0):
            raise ValueError("gamma_p must be in [0, 1]")
        if self.rho_ref <= 0:
            raise ValueError("rho_ref must be positive")
        if self.chi_slope <= 0:
            raise ValueError("chi_slope must be positive")
        if len(self.convergence_steps) != 3:
            raise ValueError("convergence_steps must contain exactly three resolutions")
        n1, n2, n3 = self.convergence_steps
        if not (n1 < n2 < n3):
            raise ValueError("convergence_steps must be strictly increasing")
        if any(step < 16 for step in self.convergence_steps):
            raise ValueError("all convergence resolutions must be at least 16")
        ratio_1 = n2 / n1
        ratio_2 = n3 / n2
        if abs(ratio_1 - ratio_2) > 1e-12:
            raise ValueError(
                "convergence_steps must use a common refinement ratio "
                "(for example 1024, 2048, 4096)"
            )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
