"""Stage 1 reference implementation for Individual Neural Holonomy."""

from .config import Stage1Config
from .experiment import run_stage1

__all__ = ["Stage1Config", "run_stage1"]
