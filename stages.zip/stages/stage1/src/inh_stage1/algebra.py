from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from scipy.linalg import expm

ComplexMatrix = NDArray[np.complex128]


I2: ComplexMatrix = np.eye(2, dtype=np.complex128)

SIGMA_1: ComplexMatrix = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128)
SIGMA_2: ComplexMatrix = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=np.complex128)
SIGMA_3: ComplexMatrix = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=np.complex128)

# Anti-Hermitian su(2) basis: T_a = i sigma_a / 2.
T1: ComplexMatrix = 0.5j * SIGMA_1
T2: ComplexMatrix = 0.5j * SIGMA_2
T3: ComplexMatrix = 0.5j * SIGMA_3
GENERATORS: tuple[ComplexMatrix, ComplexMatrix, ComplexMatrix] = (T1, T2, T3)

P0: ComplexMatrix = np.array([[1.0, 0.0], [0.0, 0.0]], dtype=np.complex128)
Q0: ComplexMatrix = I2 - P0


def frobenius_norm(matrix: ComplexMatrix) -> float:
    return float(np.linalg.norm(matrix, ord="fro"))


def antihermitian_error(matrix: ComplexMatrix) -> float:
    return frobenius_norm(matrix + matrix.conj().T)


def traceless_error(matrix: ComplexMatrix) -> float:
    """Absolute trace error for an intended su(2) matrix."""
    return float(abs(np.trace(matrix)))


def projector_idempotence_error(projector: ComplexMatrix = P0) -> float:
    return frobenius_norm(projector @ projector - projector)


def projector_hermiticity_error(projector: ComplexMatrix = P0) -> float:
    return frobenius_norm(projector - projector.conj().T)


def unitarity_error(matrix: ComplexMatrix) -> float:
    return frobenius_norm(matrix.conj().T @ matrix - I2)


def determinant_modulus_error(matrix: ComplexMatrix) -> float:
    """Legacy U(2) check: | |det(U)| - 1 |.

    This is retained for diagnostics only. It does not establish membership in
    SU(2); use :func:`special_unitary_error` for that purpose.
    """
    return float(abs(abs(np.linalg.det(matrix)) - 1.0))


def special_unitary_error(matrix: ComplexMatrix) -> float:
    """Error in the SU(2) determinant constraint det(U)=1."""
    return float(abs(np.linalg.det(matrix) - 1.0))


def su2_angle(matrix: ComplexMatrix) -> float:
    """Stable conjugacy-class angle in [0, pi] for a numerical SU(2) matrix.

    For U in SU(2), tr(U)/2 = cos(theta) and
    ||U-U^†||_F/(2 sqrt(2)) = |sin(theta)|.  Using atan2 retains accuracy near
    the identity, where arccos(tr(U)/2) loses the O(theta^2) signal to rounding.
    """
    cosine = float(np.real(np.trace(matrix)) / 2.0)
    sine = float(
        np.linalg.norm(matrix - matrix.conj().T, ord="fro")
        / (2.0 * np.sqrt(2.0))
    )
    return float(
        np.arctan2(
            max(0.0, sine),
            np.clip(cosine, -1.0, 1.0),
        )
    )


def group_distance(left: ComplexMatrix, right: ComplexMatrix) -> float:
    """Bi-invariant SU(2) distance in a declared common fiber frame.

    This distance is invariant under a *simultaneous* left/right gauge action
    and is appropriate for counterfactual clone branches with an explicit
    shared fiber identification. It is not, by itself, a distance between
    independently gauged cross-subject conjugacy classes.
    """
    return su2_angle(left.conj().T @ right)


def conjugacy_distance(left: ComplexMatrix, right: ComplexMatrix) -> float:
    """Distance between SU(2) conjugacy classes using their class angles."""
    return float(abs(su2_angle(left) - su2_angle(right)))


def sorted_eigenphases(matrix: ComplexMatrix) -> NDArray[np.float64]:
    phases = np.angle(np.linalg.eigvals(matrix))
    return np.sort(phases.astype(np.float64))


def eigenphase_descriptor_distance(left: ComplexMatrix, right: ComplexMatrix) -> float:
    """Euclidean distance between sorted, gauge-invariant eigenphase vectors."""
    return float(np.linalg.norm(sorted_eigenphases(left) - sorted_eigenphases(right)))


def su2_expm(matrix: ComplexMatrix) -> ComplexMatrix:
    """Fast exponential for a traceless anti-Hermitian 2x2 matrix."""
    if antihermitian_error(matrix) > 1e-10:
        raise ValueError("Matrix is not anti-Hermitian")
    trace_error = abs(np.trace(matrix))
    if trace_error > 1e-10:
        # Safe fallback if a future U(2) scalar term is intentionally added.
        return expm(matrix).astype(np.complex128)
    theta_sq = max(0.0, float(np.real(-0.5 * np.trace(matrix @ matrix))))
    theta = float(np.sqrt(theta_sq))
    if theta < 1e-8:
        # sin(theta)/theta with a stable local expansion.
        factor = 1.0 - theta_sq / 6.0 + theta_sq * theta_sq / 120.0
    else:
        factor = float(np.sin(theta) / theta)
    return (np.cos(theta) * I2 + factor * matrix).astype(np.complex128)


def exp_su2(generator: ComplexMatrix, step: float = 1.0) -> ComplexMatrix:
    if antihermitian_error(generator) > 1e-10:
        raise ValueError("Generator is not anti-Hermitian")
    if traceless_error(generator) > 1e-10:
        raise ValueError("Generator is not traceless")
    return expm(step * generator).astype(np.complex128)
