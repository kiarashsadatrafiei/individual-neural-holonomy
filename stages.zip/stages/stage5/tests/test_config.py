from inh_stage5.config import Stage5Config


def test_locked_config_validates():
    Stage5Config().validate()
