from pathlib import Path

from inh_stage4.lineage import sha256_file


def test_frozen_stage4_artifacts_exist():
    root = Path(__file__).resolve().parents[1]
    assert (root / "data/stage4_frozen/stage4_summary.json").exists()
    assert (root / "data/stage4_frozen/stage4_manifest.json").exists()
    assert len(sha256_file(root / "data/stage4_frozen/stage4_summary.json")) == 64
