import numpy as np

from inh_stage4.observation import ObservationBatch
from inh_stage5.transformations import TransformSpec, apply_transform, invert_transform


def batch():
    rng = np.random.default_rng(1)
    signals = rng.normal(size=(5, 4, 33, 8))
    return ObservationBatch(signals, np.ones(5), 0.0, np.array([0, 1]), np.array([2, 3]))


def test_exact_channel_permutation_inverse():
    source = batch()
    spec = TransformSpec("equivalence", "channel_permutation", "p", 0.0, 1.0, invertible=True)
    transformed, state = apply_transform(source, spec, root_seed=3, clone_id=4)
    restored = invert_transform(transformed, spec, state)
    assert np.max(np.abs(restored.signals - source.signals)) < 1e-12


def test_exact_orthogonal_inverse():
    source = batch()
    spec = TransformSpec("equivalence", "orthogonal_channel_mixing", "q", 0.0, 1.0, invertible=True)
    transformed, state = apply_transform(source, spec, root_seed=3, clone_id=4)
    restored = invert_transform(transformed, spec, state)
    assert np.max(np.abs(restored.signals - source.signals)) < 1e-11


def test_exact_anisotropic_inverse():
    source = batch()
    spec = TransformSpec("known_invertible", "anisotropic_scaling", "a", 1.0, 8.0, invertible=True)
    transformed, state = apply_transform(source, spec, root_seed=3, clone_id=4)
    restored = invert_transform(transformed, spec, state)
    assert np.max(np.abs(restored.signals - source.signals)) < 1e-12


def test_exact_signed_power_inverse():
    source = batch()
    spec = TransformSpec("known_invertible", "signed_power", "s", 1.0, 2.5, invertible=True)
    transformed, state = apply_transform(source, spec, root_seed=3, clone_id=4)
    restored = invert_transform(transformed, spec, state)
    assert np.max(np.abs(restored.signals - source.signals)) < 1e-10


def test_paired_seed_is_identity_independent():
    source = batch()
    spec = TransformSpec("information_loss", "phase_scrambling", "x", 1.0, 0.5, draw=1)
    left, _ = apply_transform(source, spec, root_seed=8, clone_id=12)
    right, _ = apply_transform(source, spec, root_seed=8, clone_id=12)
    assert np.array_equal(left.signals, right.signals)
