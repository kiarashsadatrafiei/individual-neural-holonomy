from inh_stage5.config import Stage5Config
from inh_stage5.experiment import _claims


def test_claim_lattice_flags_scalar_without_ordinal():
    metrics = {
        "scalar_spearman": {"lower": 0.9},
        "scalar_mae": {"upper": 0.01},
        "ordinal_accuracy": {"lower": 0.2},
        "pairwise_spearman": {"lower": 0.9},
        "pairwise_relative_distortion": {"upper": 0.1},
        "path_auc": {"lower": 0.95},
    }
    claims = _claims(metrics, Stage5Config())
    assert claims["scalar_value"]
    assert not claims["ordinal_structure"]
    assert not claims["lattice_consistent"]
