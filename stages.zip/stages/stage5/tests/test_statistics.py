import numpy as np

from inh_stage5.statistics import ordinal_accuracy


def test_ordinal_accuracy():
    truth = np.array([[0.0, 1.0, 2.0, 3.0]])
    assert ordinal_accuracy(truth, truth) == 1.0
    assert ordinal_accuracy(truth, truth[:, ::-1]) == 0.0
