from __future__ import annotations

from dataclasses import dataclass, replace
from itertools import combinations
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import NDArray

from inh_stage3.algebra import group_distance, su2_angle
from inh_stage4.config import RecoveryCandidate, Stage4Config
from inh_stage4.lineage import load_export, sha256_file, sha256_tree
from inh_stage4.observation import ObservationBatch, generate_observation_batch
from inh_stage4.recovery import prepare_recovery, recover_holonomies
from inh_stage4.statistics import apply_affine, relative_distortion, safe_spearman

from .config import Stage5Config
from .statistics import hierarchical_delta, hierarchical_metric_contrast, metric_bundle
from .transformations import TransformSpec, apply_transform, invert_transform

RealArray = NDArray[np.float64]
ComplexArray = NDArray[np.complex128]
PAIRS = tuple(combinations(range(4), 2))


@dataclass(frozen=True)
class ScenarioOutput:
    spec: TransformSpec
    scalar: RealArray  # clone, draw, branch
    pairwise: RealArray  # clone, draw, pair
    positive_angles: RealArray  # clone, draw, branch
    null_angles: RealArray  # clone, draw, branch
    metrics: dict[str, Any]
    claims: dict[str, bool]
    max_unitarity_error: float
    max_special_unitary_error: float
    max_condition_number: float
    max_rms: float
    inverse_reconstruction_error: float | None = None
    corrected_spotcheck_delta: float | None = None


@dataclass(frozen=True)
class Stage5Result:
    config: Stage5Config
    summary: dict[str, Any]
    scenarios: tuple[ScenarioOutput, ...]
    arrays: dict[str, Any]


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _frozen_stage4(root: Path) -> tuple[Stage4Config, RecoveryCandidate, dict[str, tuple[float, float]], dict[str, Any]]:
    summary_path = root / "data" / "stage4_frozen" / "stage4_summary.json"
    manifest_path = root / "data" / "stage4_frozen" / "stage4_manifest.json"
    summary = _read_json(summary_path)
    manifest = _read_json(manifest_path)
    base = Stage4Config()
    candidate_data = summary["selected_candidate"]
    candidate = RecoveryCandidate(
        int(candidate_data["n_bins"]), float(candidate_data["ridge"]), str(candidate_data["projection"])
    )
    calibration = {
        "angle": (float(summary["calibration"]["angle"]["intercept"]), float(summary["calibration"]["angle"]["slope"])),
        "pairwise": (float(summary["calibration"]["pairwise"]["intercept"]), float(summary["calibration"]["pairwise"]["slope"])),
    }
    lineage = {
        "stage4_version": "0.5.0",
        "stage4_summary_sha256": sha256_file(summary_path),
        "stage4_manifest_sha256": sha256_file(manifest_path),
        "stage4_source_tree_sha256": manifest["source_tree_sha256"],
        "stage3_source_tree_sha256": manifest["stage3_source_tree_sha256"],
        "stage3_cohort_export_sha256": manifest["stage3_cohort_export_sha256"],
        "selected_candidate": candidate.to_dict(),
        "calibration": summary["calibration"],
        "frozen_stage4_criteria": summary["criteria"],
    }
    return base, candidate, calibration, lineage


def _pairwise(holonomies: ComplexArray) -> RealArray:
    return np.asarray([group_distance(holonomies[left], holonomies[right]) for left, right in PAIRS], dtype=np.float64)


def _recover(
    batch: ObservationBatch,
    stage4_config: Stage4Config,
    candidate: RecoveryCandidate,
    calibration: dict[str, tuple[float, float]],
) -> tuple[RealArray, RealArray, RealArray, float, float, float]:
    prepared = prepare_recovery(batch, stage4_config)
    recovered = recover_holonomies(prepared, candidate)
    raw_scalar = recovered.scalar_angles[:4] - recovered.scalar_angles[4]
    scalar = apply_affine(raw_scalar, calibration["angle"])
    pairs = apply_affine(_pairwise(recovered.holonomies[:4]), calibration["pairwise"])
    return (
        np.asarray(scalar, dtype=np.float64),
        np.asarray(pairs, dtype=np.float64),
        np.asarray(recovered.scalar_angles[:4], dtype=np.float64),
        recovered.max_unitarity_error,
        recovered.max_special_unitary_error,
        recovered.max_condition_number,
    )


def _claims(metrics: dict[str, Any], config: Stage5Config) -> dict[str, bool]:
    scalar = bool(
        metrics["scalar_spearman"]["lower"] > config.min_scalar_spearman_lcb
        and metrics["scalar_mae"]["upper"] < config.max_scalar_mae_ucb
    )
    ordinal = bool(metrics["ordinal_accuracy"]["lower"] > config.min_ordinal_accuracy_lcb)
    metric = bool(
        metrics["pairwise_spearman"]["lower"] > config.min_metric_spearman_lcb
        and metrics["pairwise_relative_distortion"]["upper"] < config.max_metric_distortion_ucb
    )
    path = bool(metrics["path_auc"]["lower"] > config.min_path_auc_lcb)
    return {
        "scalar_value": scalar,
        "ordinal_structure": ordinal,
        "metric_geometry": metric,
        "nontrivial_path_dependence": path,
        "lattice_consistent": bool(not scalar or ordinal),
    }


def _candidate_for_spec(base: RecoveryCandidate, spec: TransformSpec) -> RecoveryCandidate:
    if spec.name == "bin_count":
        return RecoveryCandidate(int(round(spec.value)), base.ridge, base.projection)
    if spec.name == "ridge":
        return RecoveryCandidate(base.n_bins, float(spec.value), base.projection)
    return base


def _draws(spec: TransformSpec, config: Stage5Config) -> int:
    if spec.name in {"channel_permutation", "orthogonal_channel_mixing"}:
        return config.equivalence_draws
    if spec.name in {"anisotropic_scaling", "channel_projection", "phase_scrambling", "trial_timing_jitter"}:
        return config.random_loss_draws
    return 1


def _scenario_specs(config: Stage5Config) -> tuple[TransformSpec, ...]:
    specs: list[TransformSpec] = [TransformSpec("reference", "baseline", "Baseline", 0.0, 0.0)]
    specs += [
        TransformSpec("equivalence", "channel_permutation", "Channel permutation", 0.0, 1.0, equivalence=True, invertible=True),
        TransformSpec("equivalence", "orthogonal_channel_mixing", "Orthogonal channel mixing", 0.0, 1.0, equivalence=True, invertible=True),
    ]
    for index, value in enumerate(config.anisotropic_conditions, start=1):
        specs.append(TransformSpec("known_invertible", "anisotropic_scaling", f"Anisotropic scaling κ={value:g}", index / len(config.anisotropic_conditions), value, invertible=True))
    for index, value in enumerate(config.signed_power_exponents, start=1):
        specs.append(TransformSpec("known_invertible", "signed_power", f"Signed power p={value:g}", index / len(config.signed_power_exponents), value, invertible=True))
    for index, value in enumerate(config.channel_fractions, start=1):
        specs.append(TransformSpec("information_loss", "channel_projection", f"Retained channels={value:.2f}", index / len(config.channel_fractions), value))
    for index, value in enumerate(config.temporal_block_factors, start=1):
        specs.append(TransformSpec("information_loss", "temporal_coarse_graining", f"Temporal block={value}", index / len(config.temporal_block_factors), float(value)))
    for index, value in enumerate(config.phase_scramble_fractions, start=1):
        specs.append(TransformSpec("information_loss", "phase_scrambling", f"Phase scrambling={value:.2f}", index / len(config.phase_scramble_fractions), value))
    for index, value in enumerate(config.timing_jitter_samples, start=1):
        specs.append(TransformSpec("temporal_nuisance", "trial_timing_jitter", f"Circular timing shift=±{value}", index / len(config.timing_jitter_samples), float(value)))
    for index, value in enumerate(config.time_warp_gammas, start=1):
        specs.append(TransformSpec("time_model", "monotone_time_warp", f"Uncorrected time warp γ={value:g}", index / len(config.time_warp_gammas), value))
    bin_degradation = [abs(np.log2(value / 10.0)) for value in config.estimator_bins]
    max_bin = max(bin_degradation)
    for value, degradation in zip(config.estimator_bins, bin_degradation, strict=True):
        specs.append(TransformSpec("estimator", "bin_count", f"Estimator bins={value}", degradation / max_bin, float(value), estimator_only=True))
    ridge_degradation = [abs(np.log10(value / 1e-3)) for value in config.estimator_ridges]
    max_ridge = max(ridge_degradation)
    for value, degradation in zip(config.estimator_ridges, ridge_degradation, strict=True):
        specs.append(TransformSpec("estimator", "ridge", f"Estimator ridge={value:g}", degradation / max_ridge, float(value), estimator_only=True))
    return tuple(specs)


def _generate_frozen_batches(
    export: Any,
    clone_indices: tuple[int, ...],
    config: Stage4Config,
    repeat: int,
) -> tuple[list[ObservationBatch], list[ObservationBatch]]:
    positive = []
    null = []
    for clone in clone_indices:
        positive.append(generate_observation_batch(export, clone, repeat, config))
        null.append(generate_observation_batch(export, clone, repeat, config, null_kind="dynamic_zero"))
    return positive, null


def _run_scenario(
    spec: TransformSpec,
    *,
    clone_indices: tuple[int, ...],
    clone_ids: NDArray[np.int64],
    positive_batches: list[ObservationBatch],
    null_batches: list[ObservationBatch],
    truth_scalar: RealArray,
    truth_pairwise: RealArray,
    stage4_config: Stage4Config,
    candidate: RecoveryCandidate,
    calibration: dict[str, tuple[float, float]],
    config: Stage5Config,
    baseline: ScenarioOutput | None,
) -> ScenarioOutput:
    n_draw = _draws(spec, config)
    scalar = np.empty((len(clone_indices), n_draw, 4), dtype=np.float64)
    pairs = np.empty((len(clone_indices), n_draw, 6), dtype=np.float64)
    positive_angles = np.empty((len(clone_indices), n_draw, 4), dtype=np.float64)
    null_angles = np.empty_like(positive_angles)
    max_u = max_su = max_condition = max_rms = 0.0
    max_inverse_error = 0.0 if spec.invertible else None
    max_spotcheck = 0.0 if spec.invertible else None
    scenario_candidate = _candidate_for_spec(candidate, spec)
    for local, clone_index in enumerate(clone_indices):
        clone_id = int(clone_ids[clone_index])
        for draw in range(n_draw):
            draw_spec = replace(spec, draw=draw)
            if spec.estimator_only or spec.name == "baseline":
                positive = positive_batches[local]
                negative = null_batches[local]
                state: dict[str, Any] = {}
            else:
                positive, state = apply_transform(positive_batches[local], draw_spec, root_seed=config.root_seed, clone_id=clone_id)
                negative, _ = apply_transform(null_batches[local], draw_spec, root_seed=config.root_seed, clone_id=clone_id)
            s, p, a, u, su, condition = _recover(positive, stage4_config, scenario_candidate, calibration)
            _, _, n, un, sun, condition_n = _recover(negative, stage4_config, scenario_candidate, calibration)
            scalar[local, draw] = s
            pairs[local, draw] = p
            positive_angles[local, draw] = a
            null_angles[local, draw] = n
            max_u = max(max_u, u, un)
            max_su = max(max_su, su, sun)
            max_condition = max(max_condition, condition, condition_n)
            max_rms = max(max_rms, float(np.max(positive.rms_by_regime)), float(np.max(negative.rms_by_regime)))
            if spec.invertible and not spec.estimator_only:
                restored = invert_transform(positive, draw_spec, state)
                error = float(np.max(np.abs(restored.signals - positive_batches[local].signals)))
                max_inverse_error = max(float(max_inverse_error), error)
                if local < 2 and draw == 0 and baseline is not None:
                    restored_s, restored_p, _, *_ = _recover(restored, stage4_config, candidate, calibration)
                    baseline_s = baseline.scalar[local, 0]
                    baseline_p = baseline.pairwise[local, 0]
                    max_spotcheck = max(float(max_spotcheck), float(np.max(np.abs(restored_s - baseline_s))), float(np.max(np.abs(restored_p - baseline_p))))
    rng = np.random.default_rng(np.random.SeedSequence([config.root_seed, 620, sum(ord(x) for x in spec.label)]))
    metrics = metric_bundle(
        truth_scalar, truth_pairwise, scalar, pairs, positive_angles, null_angles,
        samples=config.bootstrap_samples, ci_level=config.ci_level, rng=rng,
    )
    claims = _claims(metrics, config)
    return ScenarioOutput(
        spec, scalar, pairs, positive_angles, null_angles, metrics, claims,
        max_u, max_su, max_condition, max_rms,
        max_inverse_error, max_spotcheck,
    )


def _boundary_rows(scenarios: tuple[ScenarioOutput, ...]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    claims = ("scalar_value", "ordinal_structure", "metric_geometry", "nontrivial_path_dependence")
    names = sorted({item.spec.name for item in scenarios if item.spec.family == "information_loss"})
    for name in names:
        items = sorted((item for item in scenarios if item.spec.name == name), key=lambda item: item.spec.degradation_index)
        for claim in claims:
            failed = [item for item in items if not item.claims[claim]]
            rows.append({
                "transformation": name,
                "claim": claim,
                "first_failed_degradation_index": None if not failed else failed[0].spec.degradation_index,
                "first_failed_value": None if not failed else failed[0].spec.value,
                "all_tested_preserved": not failed,
            })
    return rows


def _information_loss_diagnostics(
    scenarios: tuple[ScenarioOutput, ...],
    truth_scalar: RealArray,
    truth_pairwise: RealArray,
    config: Stage5Config,
) -> dict[str, Any]:
    output: dict[str, Any] = {}
    successful_families = 0
    names = sorted({item.spec.name for item in scenarios if item.spec.family == "information_loss"})
    for name in names:
        items = sorted((item for item in scenarios if item.spec.name == name), key=lambda item: item.spec.degradation_index)
        weak = items[0]
        strong = items[-1]
        rng = np.random.default_rng(
            np.random.SeedSequence([config.root_seed, 740, sum(ord(x) for x in name)])
        )
        scalar_order_drop = hierarchical_metric_contrast(
            truth_scalar, weak.scalar, strong.scalar, safe_spearman,
            strong_minus_weak=False, samples=config.bootstrap_samples,
            ci_level=config.ci_level, rng=rng,
        )
        pair_order_drop = hierarchical_metric_contrast(
            truth_pairwise, weak.pairwise, strong.pairwise, safe_spearman,
            strong_minus_weak=False, samples=config.bootstrap_samples,
            ci_level=config.ci_level, rng=rng,
        )
        scalar_error_rise = hierarchical_metric_contrast(
            truth_scalar, weak.scalar, strong.scalar,
            lambda a,b: float(np.mean(np.abs(a-b))),
            strong_minus_weak=True, samples=config.bootstrap_samples,
            ci_level=config.ci_level, rng=rng,
        )
        pair_error_rise = hierarchical_metric_contrast(
            truth_pairwise, weak.pairwise, strong.pairwise, relative_distortion,
            strong_minus_weak=True, samples=config.bootstrap_samples,
            ci_level=config.ci_level, rng=rng,
        )
        ordering_degraded = bool(
            scalar_order_drop.lower > 0.0 or pair_order_drop.lower > 0.0
        )
        error_increased = bool(
            scalar_error_rise.lower > 0.0 or pair_error_rise.lower > 0.0
        )
        boundary_present = any(not item.claims[key] for item in items for key in ("scalar_value", "metric_geometry"))
        family_success = bool(ordering_degraded and error_increased and boundary_present)
        successful_families += int(family_success)
        output[name] = {
            "ordering_degraded": ordering_degraded,
            "error_increased": error_increased,
            "boundary_present": boundary_present,
            "scalar_spearman_drop": scalar_order_drop.to_dict(),
            "pairwise_spearman_drop": pair_order_drop.to_dict(),
            "scalar_mae_increase": scalar_error_rise.to_dict(),
            "pairwise_distortion_increase": pair_error_rise.to_dict(),
            "family_success": family_success,
        }
    output["successful_families"] = successful_families
    output["required_families"] = len(names)
    output["pass"] = bool(len(names) == 3 and successful_families == len(names))
    return output


def run_stage5(config: Stage5Config | None = None, *, package_root: str | Path | None = None) -> Stage5Result:
    config = Stage5Config() if config is None else config
    config.validate()
    root = Path(package_root) if package_root is not None else Path(__file__).resolve().parents[2]
    stage4_config, candidate, calibration, lineage = _frozen_stage4(root)
    export_path = root / "data" / "stage3_v0.4.0_stage4_cohort_export.npz"
    export = load_export(export_path)
    clone_indices = tuple(stage4_config.validation_indices[: config.n_adversarial_clones])
    truth_scalar = np.empty((len(clone_indices), 4), dtype=np.float64)
    truth_pairs = np.empty((len(clone_indices), 6), dtype=np.float64)
    for local, clone in enumerate(clone_indices):
        branch_angles = np.asarray([su2_angle(h) for h in export.holonomy[clone]], dtype=np.float64)
        reference_angle = su2_angle(export.reference_holonomy[clone])
        truth_scalar[local] = branch_angles - reference_angle
        truth_pairs[local] = _pairwise(export.holonomy[clone])
    positive_batches, null_batches = _generate_frozen_batches(export, clone_indices, stage4_config, config.observation_repeat)

    scenarios: list[ScenarioOutput] = []
    baseline_spec = _scenario_specs(config)[0]
    baseline = _run_scenario(
        baseline_spec, clone_indices=clone_indices, clone_ids=export.clone_ids,
        positive_batches=positive_batches, null_batches=null_batches,
        truth_scalar=truth_scalar, truth_pairwise=truth_pairs,
        stage4_config=stage4_config, candidate=candidate, calibration=calibration,
        config=config, baseline=None,
    )
    scenarios.append(baseline)

    # Stage 5 deliberately evaluates one prespecified observation repeat rather
    # than the Stage 4 repeat-averaged primary estimand.  Verify that this
    # baseline is an exact numerical reproduction of the corresponding frozen
    # Stage 4 repeat, and keep that implementation check distinct from whether
    # the single-repeat confidence bounds satisfy every Stage 4 claim cutoff.
    frozen_arrays = np.load(
        root / "data" / "stage4_frozen" / "stage4_recovery_arrays.npz"
    )
    repeat = config.observation_repeat
    reproduction_deltas = {
        "scalar": float(np.max(np.abs(baseline.scalar[:, 0] - frozen_arrays["calibrated_angles"][:, repeat]))),
        "pairwise": float(np.max(np.abs(baseline.pairwise[:, 0] - frozen_arrays["estimated_pairwise_calibrated"][:, repeat]))),
        "positive_angles": float(np.max(np.abs(baseline.positive_angles[:, 0] - frozen_arrays["absolute_angles"][:, repeat]))),
        "null_angles": float(np.max(np.abs(baseline.null_angles[:, 0] - frozen_arrays["dynamic_null_absolute_angles"][:, repeat]))),
    }
    exact_reproduction_delta = max(reproduction_deltas.values())
    for spec in _scenario_specs(config)[1:]:
        scenarios.append(_run_scenario(
            spec, clone_indices=clone_indices, clone_ids=export.clone_ids,
            positive_batches=positive_batches, null_batches=null_batches,
            truth_scalar=truth_scalar, truth_pairwise=truth_pairs,
            stage4_config=stage4_config, candidate=candidate, calibration=calibration,
            config=config, baseline=baseline,
        ))
    scenario_tuple = tuple(scenarios)

    rng = np.random.default_rng(np.random.SeedSequence([config.root_seed, 730]))
    equivalence = {}
    for item in scenario_tuple:
        if item.spec.family != "equivalence":
            continue
        scalar_delta = hierarchical_delta(item.scalar, baseline.scalar, samples=config.bootstrap_samples, ci_level=config.ci_level, rng=rng)
        pair_delta = hierarchical_delta(item.pairwise, baseline.pairwise, samples=config.bootstrap_samples, ci_level=config.ci_level, rng=rng)
        equivalence[item.spec.name] = {
            "scalar_delta": scalar_delta.to_dict(),
            "pairwise_delta": pair_delta.to_dict(),
            "pass": bool(
                scalar_delta.upper < config.max_equiv_scalar_delta_ucb
                and pair_delta.upper < config.max_equiv_pair_delta_ucb
                and item.claims["lattice_consistent"]
            ),
        }

    inverse_controls = {}
    for item in scenario_tuple:
        if item.spec.family not in {"equivalence", "known_invertible"}:
            continue
        inverse_controls[item.spec.label] = {
            "raw_reconstruction_error": item.inverse_reconstruction_error,
            "corrected_recovery_spotcheck_delta": item.corrected_spotcheck_delta,
            "fixed_estimator_claims": item.claims,
            "information_preserved": bool(
                item.inverse_reconstruction_error is not None
                and item.inverse_reconstruction_error < config.max_inverse_reconstruction_error
                and item.corrected_spotcheck_delta is not None
                and item.corrected_spotcheck_delta < config.max_corrected_spotcheck_delta
            ),
        }

    boundaries = _boundary_rows(scenario_tuple)
    info_diagnostics = _information_loss_diagnostics(
        scenario_tuple, truth_scalar, truth_pairs, config,
    )
    lattice_consistent = all(item.claims["lattice_consistent"] for item in scenario_tuple)
    numerical_pass = bool(
        max(item.max_unitarity_error for item in scenario_tuple) < 1e-8
        and max(item.max_special_unitary_error for item in scenario_tuple) < 1e-8
        and max(item.max_rms for item in scenario_tuple) < config.max_rms_explosion
        and max(item.max_condition_number for item in scenario_tuple) < config.max_condition_number
    )
    baseline_pass = bool(all(baseline.claims[key] for key in ("scalar_value", "ordinal_structure", "metric_geometry", "nontrivial_path_dependence")))
    equivalence_pass = bool(equivalence and all(item["pass"] for item in equivalence.values()))
    inverse_pass = bool(inverse_controls and all(item["information_preserved"] for item in inverse_controls.values()))
    criteria = {
        "frozen_lineage_pass": bool(
            lineage["frozen_stage4_criteria"]["overall_pass"]
            and lineage["stage3_cohort_export_sha256"] == sha256_file(export_path)
        ),
        "baseline_exact_reproduction_pass": bool(exact_reproduction_delta <= 1e-12),
        "single_repeat_baseline_claim_pass": baseline_pass,
        "equivalence_pass": equivalence_pass,
        "known_invertible_information_preservation_pass": inverse_pass,
        "information_loss_boundary_pass": info_diagnostics["pass"],
        "claim_lattice_consistency_pass": lattice_consistent,
        "numerical_pass": numerical_pass,
    }
    criteria["overall_pass"] = bool(all(criteria.values()))

    summary = {
        "model_scope": {
            "primary_claim": "Claim-specific robustness and information-loss boundaries for the frozen Stage 4 v0.5.0 recovery pipeline.",
            "identifiability_distinction": "Known invertible transforms are evaluated separately under the frozen estimator and after exact inverse correction; frozen-estimator failure is not interpreted as information loss.",
            "full_connection_claim": False,
            "real_ecog_claim": False,
        },
        "lineage": lineage,
        "design": {
            "clone_indices": list(clone_indices),
            "clone_ids": [int(export.clone_ids[index]) for index in clone_indices],
            "observation_repeat": config.observation_repeat,
            "baseline_estimand": "one prespecified Stage 4 observation repeat; distinct from the Stage 4 repeat-averaged primary estimand",
            "baseline_exact_reproduction_max_delta": exact_reproduction_delta,
            "baseline_exact_reproduction_component_deltas": reproduction_deltas,
            "paired_positive_null_transformations": True,
            "cohort_status": "Stage 4 validation cohort reused for prespecified sensitivity analysis; not a new confirmatory cohort.",
            "random_transformation_draws": config.random_loss_draws,
            "equivalence_draws": config.equivalence_draws,
            "severity_uses_degradation_index": True,
            "frozen_candidate": candidate.to_dict(),
            "frozen_calibration": {
                "angle": {"intercept": calibration["angle"][0], "slope": calibration["angle"][1]},
                "pairwise": {"intercept": calibration["pairwise"][0], "slope": calibration["pairwise"][1]},
            },
        },
        "baseline": {"metrics": baseline.metrics, "claims": baseline.claims},
        "equivalence": equivalence,
        "known_invertible_controls": inverse_controls,
        "information_loss_diagnostics": info_diagnostics,
        "failure_boundaries": boundaries,
        "scenarios": [
            {
                "family": item.spec.family,
                "transformation": item.spec.name,
                "label": item.spec.label,
                "degradation_index": item.spec.degradation_index,
                "value": item.spec.value,
                "metrics": item.metrics,
                "claims": item.claims,
                "inverse_reconstruction_error": item.inverse_reconstruction_error,
                "corrected_spotcheck_delta": item.corrected_spotcheck_delta,
            }
            for item in scenario_tuple
        ],
        "numerical_qc": {
            "max_unitarity_error": max(item.max_unitarity_error for item in scenario_tuple),
            "max_special_unitary_error": max(item.max_special_unitary_error for item in scenario_tuple),
            "max_condition_number": max(item.max_condition_number for item in scenario_tuple),
            "max_transformed_rms": max(item.max_rms for item in scenario_tuple),
        },
        "criteria": criteria,
        "interpretation_limits": [
            "A failure of the frozen estimator under an invertible transform is estimator dependence, not non-identifiability.",
            "Information-loss boundaries are specific to the controlled Stage 4 observation model and selected estimator.",
            "Metric geometry refers to calibrated within-clone branch distances, not the full connection.",
            "Time-warp results are uncorrected temporal-model sensitivity and are not classified as information destruction.",
            "Circular trial shifts are classified as temporal-alignment nuisance, not information loss, because the operation is invertible when shifts are known.",
            "Stage 5 reuses the Stage 4 validation cohort and is therefore a sensitivity analysis rather than an independent replication.",
        ],
    }
    max_draws=max(item.scalar.shape[1] for item in scenario_tuple)
    scenario_scalar=np.full((len(scenario_tuple),len(clone_indices),max_draws,4),np.nan,dtype=np.float64)
    scenario_pairwise=np.full((len(scenario_tuple),len(clone_indices),max_draws,6),np.nan,dtype=np.float64)
    scenario_positive=np.full((len(scenario_tuple),len(clone_indices),max_draws,4),np.nan,dtype=np.float64)
    scenario_null=np.full_like(scenario_positive,np.nan)
    scenario_draw_counts=np.empty(len(scenario_tuple),dtype=np.int64)
    for index,item in enumerate(scenario_tuple):
        count=item.scalar.shape[1]
        scenario_draw_counts[index]=count
        scenario_scalar[index,:,:count]=item.scalar
        scenario_pairwise[index,:,:count]=item.pairwise
        scenario_positive[index,:,:count]=item.positive_angles
        scenario_null[index,:,:count]=item.null_angles
    arrays = {
        "truth_scalar": truth_scalar,
        "truth_pairwise": truth_pairs,
        "baseline_scalar": baseline.scalar,
        "baseline_pairwise": baseline.pairwise,
        "scenario_scalar": scenario_scalar,
        "scenario_pairwise": scenario_pairwise,
        "scenario_positive_angles": scenario_positive,
        "scenario_null_angles": scenario_null,
        "scenario_draw_counts": scenario_draw_counts,
        "scenario_labels": np.asarray([item.spec.label for item in scenario_tuple]),
        "scenario_families": np.asarray([item.spec.family for item in scenario_tuple]),
        "degradation_indices": np.asarray([item.spec.degradation_index for item in scenario_tuple], dtype=np.float64),
    }
    return Stage5Result(config, summary, scenario_tuple, arrays)
