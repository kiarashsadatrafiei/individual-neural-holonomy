from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class Stage5Config:
    root_seed: int = 20260725
    n_adversarial_clones: int = 16
    observation_repeat: int = 0
    bootstrap_samples: int = 5_000
    ci_level: float = 0.95

    # Frozen Stage 4 claim criteria.
    min_scalar_spearman_lcb: float = 0.72
    max_scalar_mae_ucb: float = 0.045
    min_ordinal_accuracy_lcb: float = 0.75
    min_metric_spearman_lcb: float = 0.72
    max_metric_distortion_ucb: float = 0.65
    min_path_auc_lcb: float = 0.85

    # Direct equivalence to the frozen baseline estimator output.
    max_equiv_scalar_delta_ucb: float = 5e-4
    max_equiv_pair_delta_ucb: float = 5e-4
    max_inverse_reconstruction_error: float = 1e-10
    max_corrected_spotcheck_delta: float = 5e-4

    # Transformation design.
    equivalence_draws: int = 10
    random_loss_draws: int = 20
    anisotropic_conditions: tuple[float, ...] = (3.0, 8.0)
    signed_power_exponents: tuple[float, ...] = (1.5, 2.5)
    channel_fractions: tuple[float, ...] = (0.75, 0.50, 0.25)
    temporal_block_factors: tuple[int, ...] = (2, 4, 8)
    phase_scramble_fractions: tuple[float, ...] = (0.25, 0.50, 1.0)
    timing_jitter_samples: tuple[int, ...] = (1, 3, 6)
    time_warp_gammas: tuple[float, ...] = (1.15, 1.35)
    estimator_bins: tuple[int, ...] = (6, 20, 32)
    estimator_ridges: tuple[float, ...] = (1e-4, 1e-2, 1e-1)

    # Numerical checks.
    max_rms_explosion: float = 20.0
    max_condition_number: float = 1e4

    def validate(self) -> None:
        if self.n_adversarial_clones < 8:
            raise ValueError("At least eight held-out clones are required")
        if self.bootstrap_samples < 300:
            raise ValueError("At least 300 bootstrap samples are required")
        if self.equivalence_draws < 2 or self.random_loss_draws < 2:
            raise ValueError("Random transformations require repeated draws")
        if not all(0 < value < 1 for value in self.channel_fractions):
            raise ValueError("Channel fractions must lie in (0,1)")
        if sorted(self.channel_fractions, reverse=True) != list(self.channel_fractions):
            raise ValueError("Channel fractions must be ordered from weak to strong degradation")
        if sorted(self.temporal_block_factors) != list(self.temporal_block_factors):
            raise ValueError("Temporal factors must increase with degradation")
        if sorted(self.phase_scramble_fractions) != list(self.phase_scramble_fractions):
            raise ValueError("Phase scrambling must increase with degradation")
        if sorted(self.timing_jitter_samples) != list(self.timing_jitter_samples):
            raise ValueError("Timing jitter must increase with degradation")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
