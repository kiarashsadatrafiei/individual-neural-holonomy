from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray

from inh_stage4.observation import ObservationBatch

RealArray = NDArray[np.float64]


@dataclass(frozen=True)
class TransformSpec:
    family: str
    name: str
    label: str
    degradation_index: float
    value: float
    draw: int = 0
    invertible: bool = False
    equivalence: bool = False
    estimator_only: bool = False


def _batch(signals: RealArray, source: ObservationBatch) -> ObservationBatch:
    rms = np.sqrt(np.mean(signals * signals, axis=(1, 2, 3)))
    return ObservationBatch(
        signals=np.asarray(signals, dtype=np.float64),
        rms_by_regime=np.asarray(rms, dtype=np.float64),
        max_rms_mismatch=float(np.ptp(rms)),
        frame_trial_indices=source.frame_trial_indices,
        estimation_trial_indices=source.estimation_trial_indices,
    )


def transformation_seed(root_seed: int, clone_id: int, spec: TransformSpec) -> np.random.SeedSequence:
    token = sum((index + 1) * ord(char) for index, char in enumerate(f"{spec.family}:{spec.name}:{spec.value}"))
    return np.random.SeedSequence([root_seed, 510, clone_id, spec.draw, token])


def channel_permutation(n_channels: int, rng: np.random.Generator) -> NDArray[np.int64]:
    return rng.permutation(n_channels).astype(np.int64)


def orthogonal_matrix(n_channels: int, rng: np.random.Generator) -> RealArray:
    matrix = rng.normal(size=(n_channels, n_channels))
    q, r = np.linalg.qr(matrix)
    signs = np.sign(np.diag(r))
    signs[signs == 0] = 1.0
    return np.asarray(q * signs[None, :], dtype=np.float64)


def anisotropic_scales(n_channels: int, condition: float, rng: np.random.Generator) -> RealArray:
    half = 0.5 * np.log(float(condition))
    scales = np.exp(np.linspace(-half, half, n_channels))
    return scales[rng.permutation(n_channels)].astype(np.float64)


def _time_warp(signals: RealArray, gamma: float) -> RealArray:
    n = signals.shape[2]
    target = np.linspace(0.0, 1.0, n)
    source = target ** gamma
    flat = np.moveaxis(signals, 2, -1).reshape(-1, n)
    warped = np.empty_like(flat)
    for index, row in enumerate(flat):
        warped[index] = np.interp(source, target, row)
    return np.moveaxis(warped.reshape(signals.shape[0], signals.shape[1], signals.shape[3], n), -1, 2)


def _temporal_blocks(signals: RealArray, factor: int) -> RealArray:
    output = np.empty_like(signals)
    n = signals.shape[2]
    for start in range(0, n, factor):
        stop = min(n, start + factor)
        output[:, :, start:stop] = np.mean(signals[:, :, start:stop], axis=2, keepdims=True)
    return output


def _phase_scramble(signals: RealArray, fraction: float, rng: np.random.Generator) -> RealArray:
    spectrum = np.fft.rfft(signals, axis=2)
    phases = rng.uniform(-np.pi, np.pi, size=(1, signals.shape[1], spectrum.shape[2], signals.shape[3]))
    phases[:, :, 0, :] = 0.0
    if signals.shape[2] % 2 == 0:
        phases[:, :, -1, :] = 0.0
    spectrum *= np.exp(1j * float(fraction) * phases)
    return np.fft.irfft(spectrum, n=signals.shape[2], axis=2).astype(np.float64)


def _trial_jitter(signals: RealArray, max_shift: int, rng: np.random.Generator) -> RealArray:
    output = np.empty_like(signals)
    shifts = rng.integers(-max_shift, max_shift + 1, size=signals.shape[1])
    for trial, shift in enumerate(shifts):
        output[:, trial] = np.roll(signals[:, trial], int(shift), axis=1)
    return output


def apply_transform(
    batch: ObservationBatch,
    spec: TransformSpec,
    *,
    root_seed: int,
    clone_id: int,
) -> tuple[ObservationBatch, dict[str, RealArray | float | int]]:
    signals = np.asarray(batch.signals, dtype=np.float64)
    rng = np.random.default_rng(transformation_seed(root_seed, clone_id, spec))
    state: dict[str, RealArray | float | int] = {}
    if spec.name == "baseline":
        transformed = signals.copy()
    elif spec.name == "channel_permutation":
        permutation = channel_permutation(signals.shape[-1], rng)
        transformed = signals[..., permutation]
        state["permutation"] = permutation
    elif spec.name == "orthogonal_channel_mixing":
        matrix = orthogonal_matrix(signals.shape[-1], rng)
        transformed = np.einsum("...c,cd->...d", signals, matrix)
        state["matrix"] = matrix
    elif spec.name == "anisotropic_scaling":
        scales = anisotropic_scales(signals.shape[-1], spec.value, rng)
        transformed = signals * scales.reshape(1, 1, 1, -1)
        state["scales"] = scales
    elif spec.name == "signed_power":
        transformed = np.sign(signals) * np.abs(signals) ** spec.value
        state["exponent"] = float(spec.value)
    elif spec.name == "channel_projection":
        count = max(2, int(round(signals.shape[-1] * spec.value)))
        selected = np.sort(rng.choice(signals.shape[-1], size=count, replace=False))
        mask = np.zeros(signals.shape[-1], dtype=np.float64)
        mask[selected] = 1.0
        transformed = signals * mask.reshape(1, 1, 1, -1)
        state["mask"] = mask
    elif spec.name == "temporal_coarse_graining":
        transformed = _temporal_blocks(signals, int(round(spec.value)))
    elif spec.name == "phase_scrambling":
        transformed = _phase_scramble(signals, spec.value, rng)
    elif spec.name == "trial_timing_jitter":
        transformed = _trial_jitter(signals, int(round(spec.value)), rng)
    elif spec.name == "monotone_time_warp":
        transformed = _time_warp(signals, spec.value)
        state["gamma"] = float(spec.value)
    else:
        raise KeyError(spec.name)
    return _batch(transformed, batch), state


def invert_transform(
    batch: ObservationBatch,
    spec: TransformSpec,
    state: dict[str, RealArray | float | int],
) -> ObservationBatch:
    signals = np.asarray(batch.signals, dtype=np.float64)
    if spec.name == "anisotropic_scaling":
        scales = np.asarray(state["scales"], dtype=np.float64)
        restored = signals / scales.reshape(1, 1, 1, -1)
    elif spec.name == "signed_power":
        exponent = float(state["exponent"])
        restored = np.sign(signals) * np.abs(signals) ** (1.0 / exponent)
    elif spec.name == "channel_permutation":
        permutation = np.asarray(state["permutation"], dtype=np.int64)
        inverse = np.argsort(permutation)
        restored = signals[..., inverse]
    elif spec.name == "orthogonal_channel_mixing":
        matrix = np.asarray(state["matrix"], dtype=np.float64)
        restored = np.einsum("...c,dc->...d", signals, matrix)
    else:
        raise ValueError(f"No exact discrete inverse declared for {spec.name}")
    return _batch(restored, batch)
