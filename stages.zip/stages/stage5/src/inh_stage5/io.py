from __future__ import annotations

import csv
import hashlib
import json
import os
import platform
import sys
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np

from inh_stage4.lineage import sha256_file, sha256_tree
from . import __version__
from .experiment import Stage5Result


def _default(value: Any) -> Any:
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(type(value).__name__)


def _json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, default=_default) + "\n", encoding="utf-8")


def _scenario_csv(result: Stage5Result, path: Path) -> None:
    fields = [
        "family", "transformation", "label", "degradation_index", "value",
        "scalar_spearman", "scalar_spearman_lcb", "scalar_mae", "scalar_mae_ucb",
        "ordinal_accuracy", "ordinal_accuracy_lcb", "pairwise_spearman",
        "pairwise_spearman_lcb", "pairwise_distortion", "pairwise_distortion_ucb",
        "path_auc", "path_auc_lcb", "scalar_pass", "ordinal_pass", "metric_pass",
        "path_pass", "lattice_consistent", "inverse_reconstruction_error",
        "corrected_spotcheck_delta",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for item in result.scenarios:
            m = item.metrics
            c = item.claims
            writer.writerow({
                "family": item.spec.family,
                "transformation": item.spec.name,
                "label": item.spec.label,
                "degradation_index": item.spec.degradation_index,
                "value": item.spec.value,
                "scalar_spearman": m["scalar_spearman"]["value"],
                "scalar_spearman_lcb": m["scalar_spearman"]["lower"],
                "scalar_mae": m["scalar_mae"]["value"],
                "scalar_mae_ucb": m["scalar_mae"]["upper"],
                "ordinal_accuracy": m["ordinal_accuracy"]["value"],
                "ordinal_accuracy_lcb": m["ordinal_accuracy"]["lower"],
                "pairwise_spearman": m["pairwise_spearman"]["value"],
                "pairwise_spearman_lcb": m["pairwise_spearman"]["lower"],
                "pairwise_distortion": m["pairwise_relative_distortion"]["value"],
                "pairwise_distortion_ucb": m["pairwise_relative_distortion"]["upper"],
                "path_auc": m["path_auc"]["value"],
                "path_auc_lcb": m["path_auc"]["lower"],
                "scalar_pass": c["scalar_value"],
                "ordinal_pass": c["ordinal_structure"],
                "metric_pass": c["metric_geometry"],
                "path_pass": c["nontrivial_path_dependence"],
                "lattice_consistent": c["lattice_consistent"],
                "inverse_reconstruction_error": item.inverse_reconstruction_error,
                "corrected_spotcheck_delta": item.corrected_spotcheck_delta,
            })


def _boundary_csv(result: Stage5Result, path: Path) -> None:
    rows = result.summary["failure_boundaries"]
    fields = ["transformation", "claim", "first_failed_degradation_index", "first_failed_value", "all_tested_preserved"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _plot_claim_matrix(result: Stage5Result, path: Path) -> None:
    claims = ["scalar_value", "ordinal_structure", "metric_geometry", "nontrivial_path_dependence"]
    scenarios = result.scenarios
    matrix = np.asarray([[int(item.claims[key]) for key in claims] for item in scenarios], dtype=float)
    fig, axis = plt.subplots(figsize=(8.5, max(6.0, 0.32 * len(scenarios))))
    image = axis.imshow(matrix, aspect="auto", vmin=0, vmax=1)
    axis.set_xticks(range(len(claims)), ["Scalar", "Ordinal", "Metric", "Path"])
    axis.set_yticks(range(len(scenarios)), [item.spec.label for item in scenarios])
    axis.set_title("Claim-specific preservation under transformations")
    for row in range(matrix.shape[0]):
        for col in range(matrix.shape[1]):
            axis.text(col, row, "PASS" if matrix[row, col] else "FAIL", ha="center", va="center", fontsize=7)
    fig.colorbar(image, ax=axis, label="Preserved")
    fig.tight_layout()
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def _plot_boundaries(result: Stage5Result, path: Path) -> None:
    names = [
        ("channel_projection", "Information loss: channel projection"),
        ("temporal_coarse_graining", "Information loss: temporal coarse-graining"),
        ("phase_scrambling", "Information loss: phase scrambling"),
        ("trial_timing_jitter", "Temporal-alignment nuisance (not information loss)"),
    ]
    fig, axes = plt.subplots(2, 2, figsize=(11, 8))
    for axis, (name, title) in zip(axes.ravel(), names, strict=True):
        items = sorted((item for item in result.scenarios if item.spec.name == name), key=lambda item: item.spec.degradation_index)
        x = np.asarray([item.spec.degradation_index for item in items])
        for metric, marker, label in (
            ("scalar_spearman", "o", "Scalar Spearman"),
            ("pairwise_spearman", "s", "Pairwise Spearman"),
            ("path_auc", "^", "Path AUC"),
        ):
            value=np.asarray([item.metrics[metric]["value"] for item in items])
            lower=np.asarray([item.metrics[metric]["lower"] for item in items])
            upper=np.asarray([item.metrics[metric]["upper"] for item in items])
            axis.plot(x,value,marker=marker,label=label)
            axis.fill_between(x,lower,upper,alpha=.12)
        axis.set_ylim(-0.05, 1.05)
        axis.set_xlabel("Degradation index")
        axis.set_title(title)
        axis.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def _plot_invertible(result: Stage5Result, path: Path) -> None:
    items = [item for item in result.scenarios if item.spec.family in {"equivalence", "known_invertible"}]
    labels = [item.spec.label for item in items]
    fixed = [item.metrics["scalar_spearman"]["value"] for item in items]
    corrected = [result.scenarios[0].metrics["scalar_spearman"]["value"] if item.inverse_reconstruction_error is not None else np.nan for item in items]
    x = np.arange(len(items))
    fig, axis = plt.subplots(figsize=(10, 4.5))
    width = 0.38
    axis.bar(x - width / 2, fixed, width, label="Frozen estimator")
    axis.bar(x + width / 2, corrected, width, label="After known inverse")
    axis.set_xticks(x, labels, rotation=30, ha="right")
    axis.set_ylabel("Scalar Spearman")
    axis.set_ylim(0, 1.05)
    axis.set_title("Invertibility versus frozen-estimator robustness")
    axis.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def _report(result: Stage5Result) -> str:
    s = result.summary
    c = s["criteria"]
    b = s["baseline"]["metrics"]
    lines = [
        "# Stage 5 validation report", "", "## Scope", "",
        s["model_scope"]["primary_claim"], "",
        s["model_scope"]["identifiability_distinction"], "",
        "## Frozen lineage", "",
        f"- Stage 4 version: `{s['lineage']['stage4_version']}`",
        f"- Stage 4 source SHA256: `{s['lineage']['stage4_source_tree_sha256']}`",
        f"- Stage 3 cohort export SHA256: `{s['lineage']['stage3_cohort_export_sha256']}`",
        f"- Adversarial clone count: `{len(s['design']['clone_ids'])}`",
        "- Positive and dynamic-zero-holonomy observations received the same transformation realization.", "",
        "## Single-repeat baseline", "",
        f"- Exact reproduction of frozen Stage 4 repeat {s['design']['observation_repeat']}: {c['baseline_exact_reproduction_pass']} (maximum absolute delta {s['design']['baseline_exact_reproduction_max_delta']:.3e})",
        f"- All single-repeat scientific claim cutoffs passed: {c['single_repeat_baseline_claim_pass']}",
        f"- Scalar Spearman: {b['scalar_spearman']['value']:.4f} [{b['scalar_spearman']['lower']:.4f}, {b['scalar_spearman']['upper']:.4f}]",
        f"- Scalar MAE: {b['scalar_mae']['value']:.6f} [{b['scalar_mae']['lower']:.6f}, {b['scalar_mae']['upper']:.6f}]",
        f"- Ordinal accuracy: {b['ordinal_accuracy']['value']:.4f} [{b['ordinal_accuracy']['lower']:.4f}, {b['ordinal_accuracy']['upper']:.4f}]",
        f"- Pairwise Spearman: {b['pairwise_spearman']['value']:.4f} [{b['pairwise_spearman']['lower']:.4f}, {b['pairwise_spearman']['upper']:.4f}]",
        f"- Path AUC: {b['path_auc']['value']:.4f} [{b['path_auc']['lower']:.4f}, {b['path_auc']['upper']:.4f}]", "",
        "## Equivalence and known-invertible controls", "",
    ]
    for name, item in s["equivalence"].items():
        lines.append(f"- {name}: pass={item['pass']}; scalar Δ UCB={item['scalar_delta']['upper']:.3e}; pairwise Δ UCB={item['pairwise_delta']['upper']:.3e}")
    for label, item in s["known_invertible_controls"].items():
        lines.append(f"- {label}: information_preserved={item['information_preserved']}; raw inverse error={item['raw_reconstruction_error']:.3e}; corrected spot-check Δ={item['corrected_recovery_spotcheck_delta']:.3e}")
    lines += ["", "## Information-loss diagnostics", ""]
    for name, item in s["information_loss_diagnostics"].items():
        if isinstance(item, dict):
            lines.append(f"- {name}: {item}")
    lines += ["", "## Decision", "", f"`overall_pass = {c['overall_pass']}`", "", "## Criteria", ""]
    for key, value in c.items():
        lines.append(f"- `{key}`: {value}")
    lines += ["", "## Interpretation limits", ""]
    lines.extend(f"- {item}" for item in s["interpretation_limits"])
    return "\n".join(lines) + "\n"


def _sha(directory: Path) -> None:
    rows = []
    for file in sorted(directory.iterdir()):
        if file.is_file() and file.name != "SHA256SUMS.txt":
            rows.append(f"{sha256_file(file)}  {file.name}")
    (directory / "SHA256SUMS.txt").write_text("\n".join(rows) + "\n", encoding="utf-8")


def save_result(result: Stage5Result, output: str | Path, *, package_root: str | Path | None = None) -> Path:
    destination = Path(output)
    destination.mkdir(parents=True, exist_ok=True)
    root = Path(package_root) if package_root is not None else Path(__file__).resolve().parents[2]
    _json(destination / "config.json", result.config.to_dict())
    _json(destination / "summary.json", result.summary)
    _scenario_csv(result, destination / "transformation_results.csv")
    _boundary_csv(result, destination / "claim_boundaries.csv")
    np.savez_compressed(destination / "stage5_arrays.npz", **result.arrays)
    (destination / "VALIDATION_REPORT.md").write_text(_report(result), encoding="utf-8")
    _plot_claim_matrix(result, destination / "INH_Stage5_Claim_Matrix.png")
    _plot_boundaries(result, destination / "INH_Stage5_Information_Boundaries.png")
    _plot_invertible(result, destination / "INH_Stage5_Invertibility.png")
    config_bytes = json.dumps(result.config.to_dict(), sort_keys=True).encode()
    manifest = {
        "version": __version__,
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "config_sha256": hashlib.sha256(config_bytes).hexdigest(),
        "source_tree_sha256": sha256_tree(root / "src" / "inh_stage5"),
        "stage4_source_tree_sha256": result.summary["lineage"]["stage4_source_tree_sha256"],
        "stage4_summary_sha256": result.summary["lineage"]["stage4_summary_sha256"],
        "stage4_manifest_sha256": result.summary["lineage"]["stage4_manifest_sha256"],
        "stage3_cohort_export_sha256": result.summary["lineage"]["stage3_cohort_export_sha256"],
        "criteria": result.summary["criteria"],
        "blas_threads": {key: os.environ.get(key) for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS")},
    }
    _json(destination / "manifest.json", manifest)
    _sha(destination)
    return destination
