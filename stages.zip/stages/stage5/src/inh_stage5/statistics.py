from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from numpy.typing import NDArray

from inh_stage4.statistics import relative_distortion, roc_auc, safe_spearman

RealArray = NDArray[np.float64]


@dataclass(frozen=True)
class Estimate:
    value: float
    lower: float
    upper: float

    def to_dict(self) -> dict[str, float]:
        return {"value": float(self.value), "lower": float(self.lower), "upper": float(self.upper)}


def _interval(values: RealArray, ci_level: float) -> tuple[float, float]:
    alpha = 0.5 * (1.0 - ci_level)
    return tuple(float(x) for x in np.quantile(values, [alpha, 1.0 - alpha]))


def ordinal_accuracy(truth: RealArray, estimate: RealArray) -> float:
    truth = np.asarray(truth, dtype=np.float64)
    estimate = np.asarray(estimate, dtype=np.float64)
    correct = total = 0
    for clone in range(truth.shape[0]):
        for left in range(truth.shape[1]):
            for right in range(left + 1, truth.shape[1]):
                sign = np.sign(truth[clone, left] - truth[clone, right])
                if sign == 0:
                    continue
                correct += int(np.sign(estimate[clone, left] - estimate[clone, right]) == sign)
                total += 1
    return float(correct / max(total, 1))


def hierarchical_metric(
    truth: RealArray,
    estimates: RealArray,
    metric: Callable[[RealArray, RealArray], float],
    *,
    samples: int,
    ci_level: float,
    rng: np.random.Generator,
) -> Estimate:
    """Bootstrap clones and transformation draws.

    estimates has shape clone, draw, ...; truth has shape clone, ... .
    """
    truth = np.asarray(truth, dtype=np.float64)
    estimates = np.asarray(estimates, dtype=np.float64)
    mean_estimate = np.mean(estimates, axis=1)
    observed = metric(truth, mean_estimate)
    boot = np.empty(samples, dtype=np.float64)
    n_clone, n_draw = estimates.shape[:2]
    for index in range(samples):
        clones = rng.integers(0, n_clone, size=n_clone)
        sampled = np.empty_like(mean_estimate)
        for local, clone in enumerate(clones):
            draws = rng.integers(0, n_draw, size=n_draw)
            sampled[local] = np.mean(estimates[clone, draws], axis=0)
        boot[index] = metric(truth[clones], sampled)
    lower, upper = _interval(boot, ci_level)
    return Estimate(float(observed), lower, upper)


def hierarchical_auc(
    positive: RealArray,
    negative: RealArray,
    *,
    samples: int,
    ci_level: float,
    rng: np.random.Generator,
) -> Estimate:
    positive = np.asarray(positive, dtype=np.float64)
    negative = np.asarray(negative, dtype=np.float64)
    observed = roc_auc(positive, negative)
    boot = np.empty(samples, dtype=np.float64)
    n_clone, n_draw = positive.shape[:2]
    for index in range(samples):
        clones = rng.integers(0, n_clone, size=n_clone)
        pos = []
        neg = []
        for clone in clones:
            draws = rng.integers(0, n_draw, size=n_draw)
            pos.append(positive[clone, draws].ravel())
            neg.append(negative[clone, draws].ravel())
        boot[index] = roc_auc(np.concatenate(pos), np.concatenate(neg))
    lower, upper = _interval(boot, ci_level)
    return Estimate(float(observed), lower, upper)


def hierarchical_delta(
    transformed: RealArray,
    baseline: RealArray,
    *,
    samples: int,
    ci_level: float,
    rng: np.random.Generator,
) -> Estimate:
    transformed = np.asarray(transformed, dtype=np.float64)
    baseline = np.asarray(baseline, dtype=np.float64)
    baseline_mean = np.mean(baseline, axis=1)
    transformed_mean = np.mean(transformed, axis=1)
    per_clone = np.mean(np.abs(transformed_mean - baseline_mean), axis=tuple(range(1, transformed_mean.ndim)))
    observed = float(np.mean(per_clone))
    boot = np.empty(samples, dtype=np.float64)
    for index in range(samples):
        selected = rng.integers(0, per_clone.size, size=per_clone.size)
        boot[index] = float(np.mean(per_clone[selected]))
    lower, upper = _interval(boot, ci_level)
    return Estimate(observed, lower, upper)


def hierarchical_metric_contrast(
    truth: RealArray,
    weak: RealArray,
    strong: RealArray,
    metric: Callable[[RealArray, RealArray], float],
    *,
    strong_minus_weak: bool,
    samples: int,
    ci_level: float,
    rng: np.random.Generator,
) -> Estimate:
    """Paired hierarchical contrast between weak and strong degradation.

    Clones are resampled jointly across conditions, while transformation draws
    are resampled within condition.  For error metrics use ``strong_minus_weak``;
    for performance metrics use the opposite direction so positive values
    always mean degradation.
    """
    truth = np.asarray(truth, dtype=np.float64)
    weak = np.asarray(weak, dtype=np.float64)
    strong = np.asarray(strong, dtype=np.float64)
    weak_mean = np.mean(weak, axis=1)
    strong_mean = np.mean(strong, axis=1)
    weak_value = metric(truth, weak_mean)
    strong_value = metric(truth, strong_mean)
    observed = strong_value - weak_value if strong_minus_weak else weak_value - strong_value
    boot = np.empty(samples, dtype=np.float64)
    n_clone = truth.shape[0]
    for index in range(samples):
        clones = rng.integers(0, n_clone, size=n_clone)
        weak_sample = np.empty_like(weak_mean)
        strong_sample = np.empty_like(strong_mean)
        for local, clone in enumerate(clones):
            weak_draws = rng.integers(0, weak.shape[1], size=weak.shape[1])
            strong_draws = rng.integers(0, strong.shape[1], size=strong.shape[1])
            weak_sample[local] = np.mean(weak[clone, weak_draws], axis=0)
            strong_sample[local] = np.mean(strong[clone, strong_draws], axis=0)
        weak_boot = metric(truth[clones], weak_sample)
        strong_boot = metric(truth[clones], strong_sample)
        boot[index] = strong_boot - weak_boot if strong_minus_weak else weak_boot - strong_boot
    lower, upper = _interval(boot, ci_level)
    return Estimate(float(observed), lower, upper)


def metric_bundle(
    truth_scalar: RealArray,
    truth_pairwise: RealArray,
    scalar: RealArray,
    pairwise: RealArray,
    positive_angles: RealArray,
    null_angles: RealArray,
    *,
    samples: int,
    ci_level: float,
    rng: np.random.Generator,
) -> dict[str, dict[str, float]]:
    return {
        "scalar_spearman": hierarchical_metric(truth_scalar, scalar, safe_spearman, samples=samples, ci_level=ci_level, rng=rng).to_dict(),
        "scalar_mae": hierarchical_metric(truth_scalar, scalar, lambda a, b: float(np.mean(np.abs(a-b))), samples=samples, ci_level=ci_level, rng=rng).to_dict(),
        "ordinal_accuracy": hierarchical_metric(truth_scalar, scalar, ordinal_accuracy, samples=samples, ci_level=ci_level, rng=rng).to_dict(),
        "pairwise_spearman": hierarchical_metric(truth_pairwise, pairwise, safe_spearman, samples=samples, ci_level=ci_level, rng=rng).to_dict(),
        "pairwise_relative_distortion": hierarchical_metric(truth_pairwise, pairwise, relative_distortion, samples=samples, ci_level=ci_level, rng=rng).to_dict(),
        "path_auc": hierarchical_auc(positive_angles, null_angles, samples=samples, ci_level=ci_level, rng=rng).to_dict(),
    }
