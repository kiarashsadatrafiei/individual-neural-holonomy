from __future__ import annotations

import argparse
from pathlib import Path

from .config import Stage5Config
from .experiment import run_stage5
from .io import save_result


def main() -> None:
    parser = argparse.ArgumentParser(description="Run corrected Stage 5 claim-preservation analysis")
    parser.add_argument("--output", type=Path, default=Path("results/stage5_confirmatory"))
    parser.add_argument("--clones", type=int, default=16)
    parser.add_argument("--bootstrap", type=int, default=500)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    config = Stage5Config(n_adversarial_clones=args.clones, bootstrap_samples=args.bootstrap)
    result = run_stage5(config)
    destination = save_result(result, args.output)
    print(destination)
    print(result.summary["criteria"])
    if args.strict and not result.summary["criteria"]["overall_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
