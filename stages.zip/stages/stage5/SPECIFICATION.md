# Stage 5 locked specification

## Frozen inputs

Stage 5 imports the Stage 4 v0.5.0 source, Stage 3-derived cohort export, selected recovery candidate, affine calibrations, and confirmatory lineage hashes. No Stage 3 or Stage 4 scientific parameter is re-estimated.

## Paired transformations

For each clone, transformation, severity, and draw, the identical transformation realization is applied to the nontrivial paths and the dynamic zero-holonomy null. Transformation RNG never depends on whether the signal is positive or null.

## Claim lattice

The scalar-value claim entails ordinal preservation. A scenario with scalar pass and ordinal failure is marked lattice-inconsistent rather than interpreted selectively.

## Transformation classes

- Equivalence: channel permutation; orthogonal channel mixing.
- Known invertible: anisotropic scaling; signed power.
- Information loss: channel projection; temporal block averaging; phase scrambling; trial timing jitter.
- Temporal-model sensitivity: uncorrected monotone time warp.
- Estimator dependence: bin-count and ridge perturbations measured by degradation from the frozen Stage 4 candidate.

Known invertible transformations are evaluated twice conceptually: with the frozen estimator and after exact inverse correction. A frozen-estimator failure under an invertible transform is not evidence of information-theoretic non-identifiability.

## Boundary direction

Every information-loss family uses a degradation index increasing from weak to strong destruction. Raw parameters such as retained-channel fraction are never sorted as if their numerical direction were universal.
