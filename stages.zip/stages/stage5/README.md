# Individual Neural Holonomy — Stage 5 v0.6.0

Stage 5 performs a claim-specific adversarial analysis of the **frozen Stage 4 v0.5.0 recovery pipeline**.

It separates four questions that must not be conflated:

1. **Equivalence preservation** — transformations that should leave the estimator output unchanged, such as channel permutations and orthogonal sensor mixing.
2. **Known-invertible information preservation** — transformations that may break the frozen estimator but do not destroy information because an exact inverse exists.
3. **Frozen-estimator robustness** — performance without adapting or correcting the Stage 4 estimator.
4. **Information-loss boundaries** — degradation under noninvertible channel, temporal, phase, and timing transformations.

The primary claims remain limited to:

- reference-anchored scalar conjugacy-angle change;
- branch-level ordinal structure;
- calibrated within-clone pairwise transport geometry;
- discrimination from a dynamic zero-holonomy null.

Stage 5 does not claim full-connection identifiability, real-ECoG validity, or phenomenal differentiation.

## Reproduce

```bash
python -m pip install -e .[test]
pytest -q
inh-stage5 --strict --output results/stage5_confirmatory
```
