from __future__ import annotations

from dataclasses import dataclass
import numpy as np
from numpy.typing import NDArray

from .algebra import unit_vector
from .config import Stage3Config

RealArray = NDArray[np.float64]


@dataclass(frozen=True)
class RemodelingSignals:
    confirmation: float
    correction: float
    rigidification: float
    diffuseness: float
    noise_scale: float


@dataclass(frozen=True)
class RemodelingStep:
    xi_next: RealArray
    theta_before: RealArray
    theta_after: RealArray
    delta_theta_deterministic: RealArray
    delta_theta_stochastic: RealArray
    delta_theta_total: RealArray
    active_alignment: float
    corrective_alignment: float
    signals: RemodelingSignals


def theta_from_xi(xi: RealArray, config: Stage3Config) -> RealArray:
    return config.theta_max * np.tanh(np.asarray(xi, dtype=np.float64))


def xi_from_theta(theta: RealArray, config: Stage3Config) -> RealArray:
    scaled = np.clip(np.asarray(theta, dtype=np.float64) / config.theta_max, -1.0 + 1e-12, 1.0 - 1e-12)
    return np.arctanh(scaled)


def remodeling_signals(kappa: float, mismatch: float, coherence: float, config: Stage3Config, *, slow_kappa: bool = True) -> RemodelingSignals:
    kappa_used = float(kappa) if slow_kappa else 0.0
    mismatch = max(0.0, float(mismatch))
    coherence = float(np.clip(coherence, 0.0, 1.0))
    positive = max(0.0, kappa_used)
    criticality = float(np.exp(-0.5 * (kappa_used / config.criticality_width) ** 2))
    low_mismatch = float(np.exp(-0.5 * (mismatch / config.low_mismatch_width) ** 2))
    confirmation = positive * low_mismatch
    correction = mismatch * coherence * criticality
    rigidification = positive * mismatch * (1.0 - criticality)
    negative_gate = 1.0 / (1.0 + np.exp(np.clip(3.0 * kappa_used, -60.0, 60.0)))
    diffuseness = mismatch * (1.0 - coherence) * negative_gate
    return RemodelingSignals(confirmation, correction, rigidification, diffuseness, config.base_noise + config.diffuse_noise_gain * diffuseness)


def corrective_direction(delta_pred: RealArray, delta_prot: RealArray, active_direction: RealArray, mapping: RealArray) -> RealArray:
    discrepancy = np.concatenate([np.asarray(delta_pred, dtype=np.float64), np.asarray(delta_prot, dtype=np.float64)])
    raw = np.asarray(mapping, dtype=np.float64) @ discrepancy
    active = unit_vector(np.asarray(active_direction, dtype=np.float64).reshape(-1))
    orthogonal = raw - float(np.dot(raw, active)) * active
    if np.linalg.norm(orthogonal) <= 1e-12:
        fallback = np.zeros_like(active)
        fallback[int(np.argmin(np.abs(active)))] = 1.0
        orthogonal = fallback - float(np.dot(fallback, active)) * active
    return unit_vector(orthogonal).reshape(2, 3)


def remodeling_update(xi: RealArray, active_direction: RealArray, corrective: RealArray, noise: RealArray, *, kappa: float, mismatch: float, coherence: float, config: Stage3Config, remodeling_enabled: bool = True, slow_kappa: bool = True) -> RemodelingStep:
    xi = np.asarray(xi, dtype=np.float64)
    theta_before = theta_from_xi(xi, config)
    active = unit_vector(np.asarray(active_direction, dtype=np.float64).reshape(-1)).reshape(2, 3)
    corrective = unit_vector(np.asarray(corrective, dtype=np.float64).reshape(-1)).reshape(2, 3)
    signals = remodeling_signals(kappa, mismatch, coherence, config, slow_kappa=slow_kappa)
    if not remodeling_enabled:
        zeros = np.zeros_like(theta_before)
        return RemodelingStep(xi.copy(), theta_before, theta_before.copy(), zeros, zeros, zeros, 0.0, 0.0, signals)

    desired_field = (
        config.confirmation_gain * signals.confirmation * (0.70 * config.theta_max * active - theta_before)
        + config.correction_gain * signals.correction * (0.78 * config.theta_max * corrective - theta_before)
        + config.rigid_gain * signals.rigidification * active
        - config.homeostatic_gain * theta_before
    )
    delta_theta_det = config.epsilon * desired_field
    delta_theta_stoch = np.sqrt(config.epsilon) * signals.noise_scale * np.asarray(noise, dtype=np.float64)
    target_theta = np.clip(theta_before + delta_theta_det + delta_theta_stoch, -0.999 * config.theta_max, 0.999 * config.theta_max)
    xi_next = xi_from_theta(target_theta, config)
    theta_after = theta_from_xi(xi_next, config)
    delta_total = theta_after - theta_before
    norm = float(np.linalg.norm(delta_total))
    if norm <= 1e-14:
        a_align = c_align = 0.0
    else:
        normalized = delta_total.reshape(-1) / norm
        a_align = float(np.dot(normalized, active.reshape(-1)))
        c_align = float(np.dot(normalized, corrective.reshape(-1)))
    return RemodelingStep(xi_next, theta_before, theta_after, delta_theta_det, delta_theta_stoch, delta_total, a_align, c_align, signals)
