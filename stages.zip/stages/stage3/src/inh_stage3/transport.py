from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from numpy.typing import NDArray
from scipy.integrate import solve_ivp

from .algebra import I2, P0, Q0, V0, antihermitian_error, bloch_vector, matrix_from_coefficients, special_unitary_error, su2_expm, traceless_error, unitarity_error
from .config import Stage3Config
from .states import TemporalState, anticipated_occupancy, neural_path, neural_velocity, protention_distribution

RealArray = NDArray[np.float64]
ComplexArray = NDArray[np.complex128]
KappaFunction = Callable[[RealArray], RealArray]


@dataclass(frozen=True)
class TransportResult:
    holonomy: ComplexArray
    plasticity_trace: RealArray
    max_unitarity_error: float
    max_special_unitary_error: float
    max_generator_antihermitian_error: float
    max_generator_traceless_error: float


def retention_scalar(state: TemporalState) -> float:
    return float(np.tanh(state.retention[0] - 0.35 * state.retention[1]))


def protention_scalar(times: RealArray, state: TemporalState, config: Stage3Config) -> RealArray:
    q = anticipated_occupancy(times, state, config)
    p = protention_distribution(times, state, config)
    contrast = np.array([-1.0, -0.25, 0.35, 1.0], dtype=np.float64)
    return (p - q) @ contrast


def pullback_coefficients(times: RealArray, theta: RealArray, state: TemporalState, *, base_scale: float, temporal_scale: float, kappa_function: KappaFunction, config: Stage3Config, constant_gate: bool = False) -> RealArray:
    times = np.asarray(times, dtype=np.float64)
    theta = np.asarray(theta, dtype=np.float64)
    x = neural_path(times)
    dx = neural_velocity(times)
    retention = temporal_scale * retention_scalar(state)
    protention = temporal_scale * protention_scalar(times, state, config)

    a1 = np.zeros((times.size, 3), dtype=np.float64)
    a2 = np.zeros((times.size, 3), dtype=np.float64)
    a1[:, 0] = config.connection_base * base_scale * x[:, 1]
    a1[:, 1] = config.connection_retention * retention
    a1[:, 2] = config.connection_protention * protention
    a2[:, 0] = config.connection_protention * protention
    a2[:, 1] = -config.connection_base * base_scale * x[:, 0]
    a2[:, 2] = config.connection_retention * retention
    a1 += theta[0][None, :]
    a2 += theta[1][None, :]

    kappa = np.asarray(kappa_function(times), dtype=np.float64)
    chi = np.full_like(kappa, 0.5) if constant_gate else 1.0 / (1.0 + np.exp(np.clip(config.chi_slope * kappa, -60.0, 60.0)))
    a1[:, :2] *= chi[:, None]
    a2[:, :2] *= chi[:, None]
    return a1 * dx[:, 0, None] + a2 * dx[:, 1, None]


def integrate_transport(theta: RealArray, state: TemporalState, *, base_scale: float, temporal_scale: float, kappa_function: KappaFunction, n_steps: int, config: Stage3Config, constant_gate: bool = False) -> TransportResult:
    dt = 1.0 / n_steps
    sqrt3 = np.sqrt(3.0)
    c1, c2 = 0.5 - sqrt3 / 6.0, 0.5 + sqrt3 / 6.0
    b1, b2 = (3.0 - 2.0 * sqrt3) / 12.0, (3.0 + 2.0 * sqrt3) / 12.0
    starts = np.arange(n_steps, dtype=np.float64) * dt
    t1, t2 = starts + c1 * dt, starts + c2 * dt
    midpoint = starts + 0.5 * dt
    g1 = pullback_coefficients(t1, theta, state, base_scale=base_scale, temporal_scale=temporal_scale, kappa_function=kappa_function, config=config, constant_gate=constant_gate)
    g2 = pullback_coefficients(t2, theta, state, base_scale=base_scale, temporal_scale=temporal_scale, kappa_function=kappa_function, config=config, constant_gate=constant_gate)
    velocity = neural_velocity(midpoint)
    transport = I2.copy()
    fiber = V0.copy()
    trace = np.zeros((2, 3), dtype=np.float64)
    max_u = max_su = max_ah = max_tr = 0.0
    for i in range(n_steps):
        left = matrix_from_coefficients(-dt * (b1 * g1[i] + b2 * g2[i]))
        right = matrix_from_coefficients(-dt * (b2 * g1[i] + b1 * g2[i]))
        max_ah = max(max_ah, antihermitian_error(left), antihermitian_error(right))
        max_tr = max(max_tr, traceless_error(left), traceless_error(right))
        step = su2_expm(left) @ su2_expm(right)
        transport = step @ transport
        fiber = step @ fiber
        fiber /= np.linalg.norm(fiber)
        trace += dt * np.outer(velocity[i], bloch_vector(fiber))
        max_u = max(max_u, unitarity_error(transport))
        max_su = max(max_su, special_unitary_error(transport))
    norm = float(np.linalg.norm(trace))
    trace = trace / norm if norm > 1e-14 else np.array([[1.0, 0.0, 0.0], [0.0, 0.0, 0.0]], dtype=np.float64)
    return TransportResult(transport.astype(np.complex128), trace, max_u, max_su, max_ah, max_tr)


def integrate_reference(theta: RealArray, state: TemporalState, *, base_scale: float, temporal_scale: float, kappa_function: KappaFunction, config: Stage3Config, constant_gate: bool = False) -> ComplexArray:
    def generator(t: float) -> ComplexArray:
        coeff = pullback_coefficients(np.array([t]), theta, state, base_scale=base_scale, temporal_scale=temporal_scale, kappa_function=kappa_function, config=config, constant_gate=constant_gate)[0]
        return matrix_from_coefficients(coeff)
    def rhs(t: float, y: NDArray[np.complex128]) -> NDArray[np.complex128]:
        u = y.reshape(2, 2)
        return (-generator(t) @ u).reshape(-1)
    sol = solve_ivp(rhs, (0.0, 1.0), I2.reshape(-1), method="DOP853", rtol=1e-11, atol=1e-13)
    if not sol.success:
        raise RuntimeError(sol.message)
    return sol.y[:, -1].reshape(2, 2).astype(np.complex128)


def integrate_generator(generator, n_steps: int) -> ComplexArray:
    dt=1.0/n_steps; sqrt3=np.sqrt(3.0); c1=0.5-sqrt3/6.0; c2=0.5+sqrt3/6.0; b1=(3.0-2.0*sqrt3)/12.0; b2=(3.0+2.0*sqrt3)/12.0
    u=I2.copy()
    for i in range(n_steps):
        t0=i*dt; g1=generator(t0+c1*dt); g2=generator(t0+c2*dt)
        u=su2_expm(-dt*(b1*g1+b2*g2)) @ su2_expm(-dt*(b2*g1+b1*g2)) @ u
    return u


def gauge_matrix_and_derivative(t: float, amplitude: float):
    from .algebra import T1,T3
    x=amplitude*(np.sin(2*np.pi*t)*T1+np.cos(2*np.pi*t)*T3)
    xdot=amplitude*2*np.pi*(np.cos(2*np.pi*t)*T1-np.sin(2*np.pi*t)*T3)
    half=amplitude/2.0; factor=1.0 if abs(amplitude)<1e-12 else 2*np.sin(half)/amplitude
    return (np.cos(half)*I2+factor*x).astype(np.complex128),(factor*xdot).astype(np.complex128)


def gauge_transform_generator(generator, amplitude: float):
    def transformed(t: float):
        g,gdot=gauge_matrix_and_derivative(t,amplitude); gi=g.conj().T
        return (gi@generator(t)@g+gi@gdot).astype(np.complex128)
    return transformed


def generic_numerical_qc(generator, n_steps: int, gauge_amplitude: float=0.55) -> dict[str,float|str|None]:
    from .algebra import group_distance,su2_angle
    original=integrate_generator(generator,n_steps)
    transformed=integrate_generator(gauge_transform_generator(generator,gauge_amplitude),n_steps)
    g0,_=gauge_matrix_and_derivative(0.0,gauge_amplitude); g1,_=gauge_matrix_and_derivative(1.0,gauge_amplitude)
    expected=g1.conj().T@original@g0
    reverse=integrate_generator(lambda t:-generator(1.0-t),n_steps)
    n1=max(12,n_steps//4); n2=max(24,n_steps//2); n3=n_steps
    h1=integrate_generator(generator,n1); h2=integrate_generator(generator,n2); h3=integrate_generator(generator,n3)
    e12=group_distance(h1,h2); e23=group_distance(h2,h3)
    order=None if min(e12,e23)<5e-13 else float(np.log(e12/e23)/np.log(n2/n1))
    return {"gauge_covariance_error":float(np.linalg.norm(transformed-expected,ord="fro")),"gauge_descriptor_error":float(abs(su2_angle(original)-su2_angle(transformed))),"reverse_path_error":float(np.linalg.norm(reverse@original-I2,ord="fro")),"convergence_distance_coarse_medium":e12,"convergence_distance_medium_fine":e23,"convergence_order":order,"convergence_status":"roundoff_limited" if order is None else "resolved"}
