from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray

from .config import Regime, Stage3Config

RealArray = NDArray[np.float64]
TARGET_FEATURES: RealArray = np.array(
    [[1.0, 0.0], [0.0, 1.0], [-1.0, 0.0], [0.0, -1.0]], dtype=np.float64
)
TARGET_PHASES: RealArray = 2.0 * np.pi * np.arange(4, dtype=np.float64) / 4.0
BASE_CONTEXT: RealArray = np.array([1.0, 0.0], dtype=np.float64)
ALT_CONTEXT: RealArray = np.array([0.0, 1.0], dtype=np.float64)


@dataclass
class TemporalState:
    retention: RealArray
    occupancy_logits: RealArray
    relevance_logits: RealArray

    def copy(self) -> "TemporalState":
        return TemporalState(self.retention.copy(), self.occupancy_logits.copy(), self.relevance_logits.copy())


@dataclass(frozen=True)
class EpisodeInput:
    context: RealArray
    realized_feature: RealArray
    relevance_signal: RealArray


def softmax(logits: RealArray) -> RealArray:
    logits = np.asarray(logits, dtype=np.float64)
    shifted = logits - np.max(logits, axis=-1, keepdims=True)
    exp_values = np.exp(shifted)
    return exp_values / np.sum(exp_values, axis=-1, keepdims=True)


def neural_path(t: float | RealArray) -> RealArray:
    arr = np.asarray(t, dtype=np.float64)
    return np.stack((np.cos(2.0 * np.pi * arr), np.sin(2.0 * np.pi * arr)), axis=-1)


def neural_velocity(t: float | RealArray) -> RealArray:
    arr = np.asarray(t, dtype=np.float64)
    return 2.0 * np.pi * np.stack((-np.sin(2.0 * np.pi * arr), np.cos(2.0 * np.pi * arr)), axis=-1)


def initial_temporal_state() -> TemporalState:
    return TemporalState(
        retention=np.zeros(2, dtype=np.float64),
        occupancy_logits=np.array([1.0, 0.2, -0.5, 0.2], dtype=np.float64),
        relevance_logits=np.zeros(4, dtype=np.float64),
    )


def anticipated_occupancy(t: float | RealArray, state: TemporalState, config: Stage3Config) -> RealArray:
    t_arr = np.asarray(t, dtype=np.float64)
    phase = 2.0 * np.pi * (t_arr[..., None] + config.tau_p)
    path_logits = config.beta_q * np.cos(TARGET_PHASES - phase)
    return softmax(path_logits + state.occupancy_logits)


def protention_distribution(t: float | RealArray, state: TemporalState, config: Stage3Config) -> RealArray:
    q = anticipated_occupancy(t, state, config)
    log_q = np.log(np.clip(q, 1e-300, None))
    return softmax(log_q + config.beta_w * state.relevance_logits)


def predicted_feature(state: TemporalState) -> RealArray:
    return softmax(state.occupancy_logits) @ TARGET_FEATURES


def protentional_feature(state: TemporalState, config: Stage3Config) -> RealArray:
    q = softmax(state.occupancy_logits)
    p = softmax(np.log(np.clip(q, 1e-300, None)) + config.beta_w * state.relevance_logits)
    return p @ TARGET_FEATURES


def temporal_descriptors(state: TemporalState, episode: EpisodeInput, config: Stage3Config) -> dict[str, RealArray | float]:
    pred = predicted_feature(state)
    prot = protentional_feature(state, config)
    delta_pred = episode.realized_feature - pred
    delta_prot = episode.realized_feature - prot
    mismatch = 0.5 * (float(np.linalg.norm(delta_pred)) + float(np.linalg.norm(delta_prot)))
    denom = float(np.linalg.norm(delta_pred) + np.linalg.norm(delta_prot))
    coherence = 0.0 if denom <= 1e-12 else float(np.linalg.norm(delta_pred + delta_prot) / denom)
    occupancy = softmax(state.occupancy_logits)
    entropy = float(-np.sum(occupancy * np.log(np.clip(occupancy, 1e-300, None))) / np.log(4.0))
    weighted = softmax(np.log(np.clip(occupancy, 1e-300, None)) + config.beta_w * state.relevance_logits)
    weighted_entropy = float(-np.sum(weighted * np.log(np.clip(weighted, 1e-300, None))) / np.log(4.0))
    retention_alignment = float(np.dot(state.retention, episode.context) / (1.0 + np.linalg.norm(state.retention)))
    protention_consistency = float(np.exp(-np.linalg.norm(delta_prot)))
    retention_norm = float(np.linalg.norm(state.retention))
    prot_norm = float(np.linalg.norm(prot))
    self_consistency = 0.0 if retention_norm <= 1e-12 or prot_norm <= 1e-12 else float(np.dot(state.retention / retention_norm, prot / prot_norm))
    recurrence = (
        config.recurrence_base
        + config.recurrence_retention_gain * retention_alignment
        + config.recurrence_protention_gain * protention_consistency
        + config.recurrence_self_consistency_gain * max(0.0, self_consistency)
        + config.recurrence_concentration_gain * (1.0 - weighted_entropy)
    )
    dispersion = config.dispersion_entropy_gain * entropy + config.dispersion_mismatch_gain * mismatch
    raw_ric = config.ric_alpha * recurrence - config.ric_beta * dispersion
    return {
        "predicted_feature": pred,
        "protentional_feature": prot,
        "delta_pred": delta_pred,
        "delta_prot": delta_prot,
        "mismatch": mismatch,
        "coherence": coherence,
        "combined_mismatch": delta_pred + delta_prot,
        "entropy": entropy,
        "recurrence": recurrence,
        "dispersion": dispersion,
        "raw_ric": raw_ric,
    }


def update_temporal_state(state: TemporalState, episode: EpisodeInput, config: Stage3Config, *, temporal_gain: float = 1.0) -> TemporalState:
    retention = (1.0 - config.retention_decay) * state.retention + temporal_gain * config.gamma_r * (episode.context - state.retention)
    target_similarity = TARGET_FEATURES @ episode.realized_feature
    occupancy_logits = (1.0 - config.retention_decay) * state.occupancy_logits + temporal_gain * config.gamma_q * target_similarity
    relevance_logits = (1.0 - config.relevance_decay) * state.relevance_logits + temporal_gain * config.gamma_w * episode.relevance_signal
    occupancy_logits -= np.mean(occupancy_logits)
    relevance_logits -= np.mean(relevance_logits)
    return TemporalState(retention.astype(np.float64), occupancy_logits.astype(np.float64), relevance_logits.astype(np.float64))


def episode_input(regime: Regime, episode: int, rng: np.random.Generator, config: Stage3Config) -> EpisodeInput:
    switch = max(3, config.n_learning_episodes // 3)
    if regime is Regime.STABLE:
        context = BASE_CONTEXT
        feature = TARGET_FEATURES[0]
        relevance = np.array([0.35, 0.0, -0.1, 0.0], dtype=np.float64)
    elif regime is Regime.CORRECTIVE:
        before = episode < switch
        context = BASE_CONTEXT if before else ALT_CONTEXT
        feature = TARGET_FEATURES[0] if before else TARGET_FEATURES[1]
        relevance = np.array([0.15, 0.0, -0.05, 0.0], dtype=np.float64) if before else np.array([-0.1, 0.45, -0.05, 0.0], dtype=np.float64)
    elif regime is Regime.RIGID:
        context = BASE_CONTEXT
        feature = TARGET_FEATURES[0] if episode < switch else TARGET_FEATURES[1]
        # Persistent relevance assigned to the old successor despite contradictory outcomes.
        relevance = np.array([0.65, -0.20, -0.05, -0.05], dtype=np.float64)
    else:
        index = int(rng.integers(0, 4))
        feature = TARGET_FEATURES[index]
        context = BASE_CONTEXT if bool(rng.integers(0, 2)) else ALT_CONTEXT
        relevance = rng.normal(0.0, 0.32, size=4)
        relevance -= np.mean(relevance)
    context = np.asarray(context, dtype=np.float64) + rng.normal(0.0, config.context_noise_sd, size=2)
    context /= max(np.linalg.norm(context), 1e-12)
    feature = np.asarray(feature, dtype=np.float64) + rng.normal(0.0, config.outcome_noise_sd, size=2)
    feature /= max(np.linalg.norm(feature), 1e-12)
    return EpisodeInput(context=context, realized_feature=feature, relevance_signal=np.asarray(relevance, dtype=np.float64))
