from __future__ import annotations

from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any


class Regime(str, Enum):
    STABLE = "adaptive_consolidation"
    CORRECTIVE = "corrective_reopening"
    RIGID = "rigid_closure"
    DIFFUSE = "dispersive_instability"


REGIME_ORDER = (Regime.STABLE, Regime.CORRECTIVE, Regime.RIGID, Regime.DIFFUSE)


@dataclass(frozen=True)
class Stage3Config:
    """Locked confirmatory Stage 3 design.

    Regime labels select only environmental history schedules. Closure margin,
    mismatch, coherence, corrective direction, retention, protention, and slow
    remodeling are computed endogenously.
    """

    root_seed: int = 20260723
    # Pilot clones are used only to calibrate the neutral RIC reference.  The
    # confirmatory cohort is never used for calibration or model selection.
    n_pilot_clones: int = 8
    n_validation_clones: int = 32
    n_repeats: int = 4
    n_pretrain_episodes: int = 4
    n_learning_episodes: int = 12
    n_steps_learning: int = 32
    n_steps_probe: int = 40

    # Frozen Stage 2 transport coefficients
    connection_base: float = 0.40
    connection_retention: float = 0.30
    connection_protention: float = 0.30
    chi_slope: float = 2.00

    # Endogenous temporal-state updates
    gamma_r: float = 0.22
    gamma_q: float = 0.20
    gamma_w: float = 0.18
    retention_decay: float = 0.025
    relevance_decay: float = 0.035
    beta_q: float = 2.6
    beta_w: float = 1.4
    tau_p: float = 0.22

    # RIC construction and independent neutral calibration
    ric_alpha: float = 1.0
    ric_beta: float = 0.72
    recurrence_base: float = 0.74
    recurrence_retention_gain: float = 0.34
    recurrence_protention_gain: float = 0.22
    recurrence_self_consistency_gain: float = 0.52
    recurrence_concentration_gain: float = 0.18
    dispersion_entropy_gain: float = 0.44
    dispersion_mismatch_gain: float = 0.56
    ric_scale_floor: float = 0.15

    # Slow remodeling in theta-space, implemented through the bounded xi chart
    theta_max: float = 0.32
    epsilon: float = 0.045
    criticality_width: float = 0.55
    low_mismatch_width: float = 0.30
    confirmation_gain: float = 0.56
    correction_gain: float = 0.78
    rigid_gain: float = 0.16
    homeostatic_gain: float = 0.028
    base_noise: float = 0.004
    diffuse_noise_gain: float = 0.038
    chart_jacobian_floor: float = 0.12

    # Shared clone heterogeneity; identical across branch copies before history
    subject_base_sd: float = 0.055
    subject_temporal_sd: float = 0.06
    subject_mapping_sd: float = 0.05
    initial_xi_sd: float = 0.025

    # Episode-level environmental and measurement perturbations
    context_noise_sd: float = 0.025
    outcome_noise_sd: float = 0.025
    descriptor_noise_sd: float = 0.018

    # Inference
    bootstrap_samples: int = 20_000
    ci_level: float = 0.95
    null_quantile: float = 0.95
    practical_margin: float = 0.001

    # Numerical QC
    tol_unitarity: float = 1e-9
    tol_special_unitary: float = 1e-9
    tol_projector: float = 1e-12
    tol_initial_match: float = 1e-10
    tol_no_remodeling: float = 1e-9
    tol_gauge_covariance: float = 1e-8
    tol_reference_integrator: float = 5e-6

    def validate(self) -> None:
        if self.n_pilot_clones < 4 or self.n_validation_clones < 8:
            raise ValueError("Pilot requires >=4 and validation requires >=8 clone sets")
        if self.n_repeats < 2:
            raise ValueError("At least two stochastic repeats are required")
        if self.n_learning_episodes < 6:
            raise ValueError("At least six learning episodes are required")
        if min(self.n_steps_learning, self.n_steps_probe) < 12:
            raise ValueError("Integration resolution is too low")
        if self.bootstrap_samples < 50:
            raise ValueError("At least 50 bootstrap samples are required")
        if not (0.0 < self.epsilon < 1.0):
            raise ValueError("epsilon must be in (0,1)")
        if self.theta_max <= 0.0:
            raise ValueError("theta_max must be positive")

    @property
    def total_clones(self) -> int:
        return self.n_pilot_clones + self.n_validation_clones

    def to_dict(self) -> dict[str, Any]:
        output = asdict(self)
        output["regimes"] = [r.value for r in REGIME_ORDER]
        return output
