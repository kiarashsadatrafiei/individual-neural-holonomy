from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

RealArray = NDArray[np.float64]


def bootstrap_mean(values: RealArray, rng: np.random.Generator, samples: int, ci_level: float) -> dict[str, float]:
    values = np.asarray(values, dtype=np.float64)
    n = values.size
    indices = rng.integers(0, n, size=(samples, n))
    means = np.mean(values[indices], axis=1)
    alpha = 1.0 - ci_level
    return {"mean": float(np.mean(values)), "lower": float(np.quantile(means, alpha / 2.0)), "upper": float(np.quantile(means, 1.0 - alpha / 2.0))}


def directional_coherence(vectors: RealArray) -> float:
    vectors = np.asarray(vectors, dtype=np.float64)
    norms = np.linalg.norm(vectors, axis=-1)
    valid = norms > 1e-12
    if not np.any(valid):
        return 0.0
    units = vectors[valid] / norms[valid, None]
    return float(np.linalg.norm(np.mean(units, axis=0)))
