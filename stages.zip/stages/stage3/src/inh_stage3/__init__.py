"""Individual Neural Holonomy — Stage 3 endogenous remodeling model."""

__version__ = "0.4.0"
