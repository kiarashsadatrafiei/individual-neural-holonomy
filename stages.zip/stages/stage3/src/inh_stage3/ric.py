from __future__ import annotations

from dataclasses import dataclass
import numpy as np
from numpy.typing import NDArray

from .config import Stage3Config

RealArray = NDArray[np.float64]


@dataclass(frozen=True)
class RICReference:
    center: float
    scale: float


def calibrate_reference(raw_values: RealArray, config: Stage3Config) -> RICReference:
    values = np.asarray(raw_values, dtype=np.float64)
    center = float(np.median(values))
    mad = float(1.4826 * np.median(np.abs(values - center)))
    return RICReference(center=center, scale=max(mad, config.ric_scale_floor))


def standardized_kappa(raw_ric: float | RealArray, reference: RICReference) -> float | RealArray:
    return (np.asarray(raw_ric, dtype=np.float64) - reference.center) / reference.scale
