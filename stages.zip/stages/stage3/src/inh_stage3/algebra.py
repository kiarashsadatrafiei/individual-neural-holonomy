from __future__ import annotations

import numpy as np
from numpy.typing import NDArray
from scipy.linalg import expm

ComplexMatrix = NDArray[np.complex128]
RealArray = NDArray[np.float64]

I2: ComplexMatrix = np.eye(2, dtype=np.complex128)
SIGMA_1 = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128)
SIGMA_2 = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=np.complex128)
SIGMA_3 = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=np.complex128)
T1: ComplexMatrix = 0.5j * SIGMA_1
T2: ComplexMatrix = 0.5j * SIGMA_2
T3: ComplexMatrix = 0.5j * SIGMA_3
GENERATORS = (T1, T2, T3)
P0: ComplexMatrix = np.array([[1.0, 0.0], [0.0, 0.0]], dtype=np.complex128)
Q0: ComplexMatrix = I2 - P0
V0: NDArray[np.complex128] = np.array([1.0, 0.0], dtype=np.complex128)


def frobenius_norm(matrix: ComplexMatrix) -> float:
    return float(np.linalg.norm(matrix, ord="fro"))


def antihermitian_error(matrix: ComplexMatrix) -> float:
    return frobenius_norm(matrix + matrix.conj().T)


def traceless_error(matrix: ComplexMatrix) -> float:
    return float(abs(np.trace(matrix)))


def unitarity_error(matrix: ComplexMatrix) -> float:
    return frobenius_norm(matrix.conj().T @ matrix - I2)


def special_unitary_error(matrix: ComplexMatrix) -> float:
    return float(abs(np.linalg.det(matrix) - 1.0))


def projector_idempotence_error(projector: ComplexMatrix = P0) -> float:
    return frobenius_norm(projector @ projector - projector)


def projector_hermiticity_error(projector: ComplexMatrix = P0) -> float:
    return frobenius_norm(projector - projector.conj().T)


def su2_angle(matrix: ComplexMatrix) -> float:
    cosine = float(np.real(np.trace(matrix)) / 2.0)
    sine = float(np.linalg.norm(matrix - matrix.conj().T, ord="fro") / (2.0 * np.sqrt(2.0)))
    return float(np.arctan2(max(0.0, sine), np.clip(cosine, -1.0, 1.0)))


def group_distance(left: ComplexMatrix, right: ComplexMatrix) -> float:
    """Bi-invariant distance in an explicitly shared counterfactual fiber frame."""
    return su2_angle(left.conj().T @ right)


def conjugacy_distance(left: ComplexMatrix, right: ComplexMatrix) -> float:
    """Gauge-invariant distance between SU(2) conjugacy classes."""
    return float(abs(su2_angle(left) - su2_angle(right)))


def su2_expm(matrix: ComplexMatrix) -> ComplexMatrix:
    if antihermitian_error(matrix) > 1e-10:
        raise ValueError("Matrix is not anti-Hermitian")
    if traceless_error(matrix) > 1e-10:
        return expm(matrix).astype(np.complex128)
    theta_sq = max(0.0, float(np.real(-0.5 * np.trace(matrix @ matrix))))
    theta = float(np.sqrt(theta_sq))
    factor = 1.0 - theta_sq / 6.0 + theta_sq * theta_sq / 120.0 if theta < 1e-8 else float(np.sin(theta) / theta)
    return (np.cos(theta) * I2 + factor * matrix).astype(np.complex128)


def matrix_from_coefficients(coefficients: RealArray) -> ComplexMatrix:
    coefficients = np.asarray(coefficients, dtype=np.float64)
    if coefficients.shape != (3,):
        raise ValueError("coefficients must have shape (3,)")
    return sum(float(c) * g for c, g in zip(coefficients, GENERATORS, strict=True)).astype(np.complex128)


def coefficients_from_matrix(matrix: ComplexMatrix) -> RealArray:
    return np.array([-2.0 * np.real(np.trace(matrix @ g)) for g in GENERATORS], dtype=np.float64)


def bloch_vector(state: NDArray[np.complex128]) -> RealArray:
    state = np.asarray(state, dtype=np.complex128)
    state = state / np.linalg.norm(state)
    return np.array([np.real(np.vdot(state, s @ state)) for s in (SIGMA_1, SIGMA_2, SIGMA_3)], dtype=np.float64)


def unit_vector(vector: RealArray, *, fallback_index: int = 0) -> RealArray:
    vector = np.asarray(vector, dtype=np.float64)
    norm = float(np.linalg.norm(vector))
    if norm <= 1e-14:
        output = np.zeros_like(vector)
        output.reshape(-1)[fallback_index] = 1.0
        return output
    return vector / norm
