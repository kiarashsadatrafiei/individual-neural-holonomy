from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Any

import numpy as np
from numpy.typing import NDArray

from .algebra import P0, conjugacy_distance, group_distance, projector_hermiticity_error, projector_idempotence_error, special_unitary_error, unit_vector
from .config import REGIME_ORDER, Regime, Stage3Config
from .remodeling import corrective_direction, remodeling_update, theta_from_xi
from .ric import RICReference, calibrate_reference, standardized_kappa
from .states import EpisodeInput, TemporalState, episode_input, initial_temporal_state, temporal_descriptors, update_temporal_state
from .statistics import bootstrap_mean, directional_coherence
from .transport import generic_numerical_qc, integrate_reference, integrate_transport, pullback_coefficients

RealArray = NDArray[np.float64]
ComplexArray = NDArray[np.complex128]


@dataclass(frozen=True)
class CloneParameters:
    clone_id: int
    base_scale: float
    temporal_scale: float
    initial_xi: RealArray
    discrepancy_mapping: RealArray


@dataclass(frozen=True)
class Stage3Result:
    config: Stage3Config
    arrays: dict[str, Any]
    summary: dict[str, Any]


def _lognormal_unit(rng: np.random.Generator, sd: float) -> float:
    return float(np.exp(rng.normal(-0.5 * sd * sd, sd)))


def make_clones(config: Stage3Config, rng: np.random.Generator) -> list[CloneParameters]:
    base_mapping = np.array(
        [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1],[0.7,-0.3,0.5,0.1],[-0.2,0.6,-0.1,0.7]], dtype=np.float64
    )
    clones = []
    for clone_id in range(config.total_clones):
        # Per-clone streams make the cohort invariant to later changes in cohort
        # size and prevent pilot/validation generation from sharing RNG state.
        clone_rng = np.random.default_rng(
            np.random.SeedSequence([config.root_seed, 301, clone_id])
        )
        mapping = base_mapping + clone_rng.normal(0.0, config.subject_mapping_sd, size=(6,4))
        clones.append(CloneParameters(clone_id, _lognormal_unit(clone_rng, config.subject_base_sd), _lognormal_unit(clone_rng, config.subject_temporal_sd), clone_rng.normal(0.0, config.initial_xi_sd, size=(2,3)), mapping))
    return clones


def _constant_kappa(value: float):
    return lambda times: np.full(np.asarray(times).shape, value, dtype=np.float64)


def _pretrain_state(config: Stage3Config, clone: CloneParameters, rng: np.random.Generator) -> tuple[TemporalState, list[float]]:
    state = initial_temporal_state()
    raw = []
    for episode in range(config.n_pretrain_episodes):
        inp = episode_input(Regime.STABLE, episode, rng, config)
        desc = temporal_descriptors(state, inp, config)
        raw.append(float(desc["raw_ric"]))
        state = update_temporal_state(state, inp, config, temporal_gain=clone.temporal_scale)
    return state, raw


def _simulate_branch(clone: CloneParameters, regime: Regime, repeat: int, state0: TemporalState, xi0: RealArray, reference: RICReference, config: Stage3Config, *, remodeling_enabled: bool = True, retention_enabled: bool = True, protention_enabled: bool = True, constant_gate: bool = False, slow_kappa: bool = True) -> dict[str, Any]:
    # Every intervention reuses the same exogenous episode/noise stream.  The
    # condition flags must not enter the seed, otherwise an "ablation effect"
    # is confounded with a different stochastic realization.
    seed = np.random.SeedSequence(
        [config.root_seed, 401, clone.clone_id, repeat, list(REGIME_ORDER).index(regime)]
    )
    rng = np.random.default_rng(seed)
    state = state0.copy()
    xi = xi0.copy()
    episodes = config.n_learning_episodes
    theta_path = np.empty((episodes + 1, 2, 3), dtype=np.float64)
    xi_path = np.empty_like(theta_path)
    kappa_path = np.empty(episodes, dtype=np.float64)
    mismatch_path = np.empty(episodes, dtype=np.float64)
    coherence_path = np.empty(episodes, dtype=np.float64)
    retention_path = np.empty((episodes + 1, 2), dtype=np.float64)
    occupancy_path = np.empty((episodes + 1, 4), dtype=np.float64)
    relevance_path = np.empty((episodes + 1, 4), dtype=np.float64)
    updates = np.empty((episodes, 2, 3), dtype=np.float64)
    det_updates = np.empty_like(updates)
    stoch_updates = np.empty_like(updates)
    active_alignment = np.empty(episodes, dtype=np.float64)
    corrective_alignment = np.empty(episodes, dtype=np.float64)
    probe_h = np.empty((episodes + 1, 2, 2), dtype=np.complex128)
    max_u = max_su = max_ah = max_tr = 0.0
    mismatch_history: list[np.ndarray] = []

    theta_path[0] = theta_from_xi(xi, config)
    xi_path[0] = xi
    retention_path[0] = state.retention
    occupancy_path[0] = state.occupancy_logits
    relevance_path[0] = state.relevance_logits
    neutral_probe_state = state0.copy()
    probe0 = integrate_transport(theta_path[0], neutral_probe_state, base_scale=clone.base_scale, temporal_scale=clone.temporal_scale, kappa_function=_constant_kappa(0.0), n_steps=config.n_steps_probe, config=config)
    probe_h[0] = probe0.holonomy

    for ep in range(episodes):
        inp = episode_input(regime, ep, rng, config)
        state_for_desc = state.copy()
        if not retention_enabled:
            state_for_desc.retention[:] = 0.0
        if not protention_enabled:
            state_for_desc.relevance_logits[:] = 0.0
        desc = temporal_descriptors(state_for_desc, inp, config)
        kappa = float(standardized_kappa(float(desc["raw_ric"]), reference)) + float(rng.normal(0.0, config.descriptor_noise_sd))
        mismatch = max(0.0, float(desc["mismatch"]) + float(rng.normal(0.0, config.descriptor_noise_sd)))
        mismatch_history.append(np.asarray(desc["combined_mismatch"], dtype=np.float64))
        recent = mismatch_history[-4:]
        denom = float(sum(np.linalg.norm(vector) for vector in recent))
        temporal_coherence = 0.0 if denom <= 1e-12 else float(np.linalg.norm(np.sum(recent, axis=0)) / denom)
        coherence = float(np.clip(temporal_coherence + rng.normal(0.0, config.descriptor_noise_sd), 0.0, 1.0))
        theta = theta_from_xi(xi, config)
        learning = integrate_transport(theta, state_for_desc, base_scale=clone.base_scale, temporal_scale=clone.temporal_scale, kappa_function=_constant_kappa(kappa), n_steps=config.n_steps_learning, config=config, constant_gate=constant_gate)
        corr = corrective_direction(np.asarray(desc["delta_pred"]), np.asarray(desc["delta_prot"]), learning.plasticity_trace, clone.discrepancy_mapping)
        step = remodeling_update(xi, learning.plasticity_trace, corr, rng.normal(0.0, 1.0, size=(2,3)), kappa=kappa, mismatch=mismatch, coherence=coherence, config=config, remodeling_enabled=remodeling_enabled, slow_kappa=slow_kappa)
        xi = step.xi_next
        if retention_enabled or protention_enabled:
            new_state = update_temporal_state(state, inp, config, temporal_gain=clone.temporal_scale)
            if not retention_enabled:
                new_state.retention = state.retention.copy()
            if not protention_enabled:
                new_state.relevance_logits = state.relevance_logits.copy()
            state = new_state
        probe = integrate_transport(step.theta_after, neutral_probe_state, base_scale=clone.base_scale, temporal_scale=clone.temporal_scale, kappa_function=_constant_kappa(0.0), n_steps=config.n_steps_probe, config=config)
        probe_h[ep+1] = probe.holonomy
        theta_path[ep+1], xi_path[ep+1] = step.theta_after, xi
        retention_path[ep+1], occupancy_path[ep+1], relevance_path[ep+1] = state.retention, state.occupancy_logits, state.relevance_logits
        kappa_path[ep], mismatch_path[ep], coherence_path[ep] = kappa, mismatch, coherence
        updates[ep], det_updates[ep], stoch_updates[ep] = step.delta_theta_total, step.delta_theta_deterministic, step.delta_theta_stochastic
        active_alignment[ep], corrective_alignment[ep] = step.active_alignment, step.corrective_alignment
        for result in (learning, probe):
            max_u = max(max_u, result.max_unitarity_error)
            max_su = max(max_su, result.max_special_unitary_error)
            max_ah = max(max_ah, result.max_generator_antihermitian_error)
            max_tr = max(max_tr, result.max_generator_traceless_error)
    return {"theta":theta_path,"xi":xi_path,"kappa":kappa_path,"mismatch":mismatch_path,"coherence":coherence_path,"retention":retention_path,"occupancy":occupancy_path,"relevance":relevance_path,"updates":updates,"det_updates":det_updates,"stoch_updates":stoch_updates,"active_alignment":active_alignment,"corrective_alignment":corrective_alignment,"holonomies":probe_h,"max_u":max_u,"max_su":max_su,"max_ah":max_ah,"max_tr":max_tr}


def _run_condition(clones: list[CloneParameters], pretrain_states: list[TemporalState], reference: RICReference, config: Stage3Config, **kwargs: bool) -> dict[str, Any]:
    c, r, q, e = len(clones), len(REGIME_ORDER), config.n_repeats, config.n_learning_episodes
    hol = np.empty((c,r,q,e+1,2,2), dtype=np.complex128)
    theta = np.empty((c,r,q,e+1,2,3), dtype=np.float64)
    kappa = np.empty((c,r,q,e), dtype=np.float64)
    mismatch = np.empty_like(kappa); coherence = np.empty_like(kappa)
    updates = np.empty((c,r,q,e,2,3), dtype=np.float64); det_updates=np.empty_like(updates); stoch_updates=np.empty_like(updates)
    active=np.empty((c,r,q,e)); corrective=np.empty_like(active)
    max_u=max_su=max_ah=max_tr=0.0
    for ci, clone in enumerate(clones):
        for ri, regime in enumerate(REGIME_ORDER):
            for qi in range(q):
                out = _simulate_branch(clone, regime, qi, pretrain_states[ci], clone.initial_xi, reference, config, **kwargs)
                hol[ci,ri,qi]=out["holonomies"]; theta[ci,ri,qi]=out["theta"]; kappa[ci,ri,qi]=out["kappa"]; mismatch[ci,ri,qi]=out["mismatch"]; coherence[ci,ri,qi]=out["coherence"]
                updates[ci,ri,qi]=out["updates"]; det_updates[ci,ri,qi]=out["det_updates"]; stoch_updates[ci,ri,qi]=out["stoch_updates"]; active[ci,ri,qi]=out["active_alignment"]; corrective[ci,ri,qi]=out["corrective_alignment"]
                max_u=max(max_u,out["max_u"]); max_su=max(max_su,out["max_su"]); max_ah=max(max_ah,out["max_ah"]); max_tr=max(max_tr,out["max_tr"])
    return {"holonomies":hol,"theta":theta,"kappa":kappa,"mismatch":mismatch,"coherence":coherence,"updates":updates,"det_updates":det_updates,"stoch_updates":stoch_updates,"active_alignment":active,"corrective_alignment":corrective,"max_u":max_u,"max_su":max_su,"max_ah":max_ah,"max_tr":max_tr}


def _pair_metrics(hol: ComplexArray) -> dict[str, RealArray]:
    # average repeats within clone before cross-regime comparison, using distances averaged over all repeat pairs
    metrics: dict[str, RealArray] = {}
    for i,j in combinations(range(len(REGIME_ORDER)),2):
        common=[]; conj=[]
        for c in range(hol.shape[0]):
            cd=[]; jd=[]
            for a in range(hol.shape[2]):
                for b in range(hol.shape[2]):
                    cd.append(group_distance(hol[c,i,a,-1],hol[c,j,b,-1])); jd.append(conjugacy_distance(hol[c,i,a,-1],hol[c,j,b,-1]))
            common.append(np.mean(cd)); conj.append(np.mean(jd))
        key=f"{REGIME_ORDER[i].value}__{REGIME_ORDER[j].value}"
        metrics[key]=np.column_stack([common,conj])
    return metrics


def _paired_bootstrap(
    values: RealArray,
    rng: np.random.Generator,
    samples: int,
    ci_level: float,
) -> dict[str, float]:
    """Cluster bootstrap a clone-level paired contrast."""
    values = np.asarray(values, dtype=np.float64)
    indices = rng.integers(0, values.size, size=(samples, values.size))
    boot = np.mean(values[indices], axis=1)
    alpha = 0.5 * (1.0 - ci_level)
    return {
        "mean": float(np.mean(values)),
        "lower": float(np.quantile(boot, alpha)),
        "upper": float(np.quantile(boot, 1.0 - alpha)),
    }


def _simultaneous_lower_bounds(
    matrix: RealArray,
    rng: np.random.Generator,
    samples: int,
    ci_level: float,
) -> RealArray:
    """One-sided familywise lower bounds for several clone-level estimands.

    Rows are independent clones and columns are the jointly protected effects.
    The bootstrap critical value is the quantile of the maximum downward
    deviation across columns, so the returned bounds control the whole family.
    """
    matrix = np.asarray(matrix, dtype=np.float64)
    observed = np.mean(matrix, axis=0)
    indices = rng.integers(0, matrix.shape[0], size=(samples, matrix.shape[0]))
    boot = np.mean(matrix[indices], axis=1)
    max_downward = np.max(observed[None, :] - boot, axis=1)
    critical = float(np.quantile(max_downward, ci_level))
    return observed - critical


def _condition_clone_means(condition: dict[str, Any]) -> tuple[RealArray, RealArray]:
    pair_metrics = _pair_metrics(condition["holonomies"])
    common = np.column_stack([value[:, 0] for value in pair_metrics.values()])
    conjugacy = np.column_stack([value[:, 1] for value in pair_metrics.values()])
    return np.mean(common, axis=1), np.mean(conjugacy, axis=1)


def run_stage3(config: Stage3Config) -> Stage3Result:
    config.validate()
    rng=np.random.default_rng(config.root_seed)
    clones=make_clones(config,rng)
    pretrain=[]; raw_by_clone=[]
    for clone in clones:
        pretrain_rng = np.random.default_rng(
            np.random.SeedSequence([config.root_seed, 302, clone.clone_id])
        )
        state, values=_pretrain_state(config,clone,pretrain_rng)
        pretrain.append(state)
        raw_by_clone.append(values)
    # Strict pilot-only calibration: no validation descriptor contributes to
    # the RIC center or scale.
    pilot_raw = np.asarray(raw_by_clone[:config.n_pilot_clones], dtype=np.float64).ravel()
    reference=calibrate_reference(pilot_raw,config)
    main=_run_condition(clones,pretrain,reference,config)
    # All mechanistic interventions are evaluated on the same held-out clones
    # and paired exogenous streams as the main condition.
    no_remodel=_run_condition(clones,pretrain,reference,config,remodeling_enabled=False)
    no_ret=_run_condition(clones,pretrain,reference,config,retention_enabled=False)
    no_prot=_run_condition(clones,pretrain,reference,config,protention_enabled=False)
    constant_gate=_run_condition(clones,pretrain,reference,config,constant_gate=True)
    no_slow_kappa=_run_condition(clones,pretrain,reference,config,slow_kappa=False)

    pilot=slice(0,config.n_pilot_clones); validation=slice(config.n_pilot_clones,None)
    pairs=_pair_metrics(main["holonomies"])
    null_pairs=_pair_metrics(no_remodel["holonomies"])
    null_common=np.concatenate([v[pilot,0] for v in null_pairs.values()])
    null_conjugacy=np.concatenate([v[pilot,1] for v in null_pairs.values()])
    brng=np.random.default_rng(config.root_seed+991)
    pair_summary={}
    for key,vals in pairs.items():
        val=vals[validation]
        common=bootstrap_mean(val[:,0],brng,config.bootstrap_samples,config.ci_level)
        conj=bootstrap_mean(val[:,1],brng,config.bootstrap_samples,config.ci_level)
        pair_summary[key]={"common_frame":common,"conjugacy":conj}
    # Initial equality and within-regime repeat reliability
    initial=[]; within=[]
    h=main["holonomies"][validation]
    for c in range(h.shape[0]):
        for i,j in combinations(range(len(REGIME_ORDER)),2):
            initial.append(group_distance(h[c,i,0,0],h[c,j,0,0]))
        for r in range(len(REGIME_ORDER)):
            for a,b in combinations(range(config.n_repeats),2):
                within.append(group_distance(h[c,r,a,-1],h[c,r,b,-1]))
    between=np.concatenate([v[validation,0] for v in pairs.values()])
    reliability_ratio=float(np.mean(between)/(np.mean(within)+1e-15))

    # A stochastic null compares independent repeat realizations of the same
    # clone/regime/history.  This is more conservative than the numerical
    # no-remodeling floor alone.
    within_common=np.asarray(within,dtype=np.float64)
    within_conjugacy=[]
    for c in range(h.shape[0]):
        for r in range(len(REGIME_ORDER)):
            for a,b in combinations(range(config.n_repeats),2):
                within_conjugacy.append(conjugacy_distance(h[c,r,a,-1],h[c,r,b,-1]))
    within_conjugacy=np.asarray(within_conjugacy,dtype=np.float64)
    common_threshold=max(
        float(np.quantile(null_common,config.null_quantile)),
        float(np.quantile(within_common,config.null_quantile)),
    )+config.practical_margin
    conjugacy_threshold=max(
        float(np.quantile(null_conjugacy,config.null_quantile)),
        float(np.quantile(within_conjugacy,config.null_quantile)),
    )+config.practical_margin

    pair_keys=list(pairs)
    common_matrix=np.column_stack([pairs[key][validation,0] for key in pair_keys])
    conjugacy_matrix=np.column_stack([pairs[key][validation,1] for key in pair_keys])
    family_rng=np.random.default_rng(config.root_seed+992)
    common_lcb=_simultaneous_lower_bounds(common_matrix,family_rng,config.bootstrap_samples,config.ci_level)
    primary_indices=[0,1,2]  # stable versus corrective, rigid, diffuse
    primary_conjugacy_lcb=_simultaneous_lower_bounds(
        conjugacy_matrix[:,primary_indices],family_rng,config.bootstrap_samples,config.ci_level
    )
    all_conjugacy_lcb=_simultaneous_lower_bounds(
        conjugacy_matrix,family_rng,config.bootstrap_samples,config.ci_level
    )
    for index,key in enumerate(pair_keys):
        pair_summary[key]["common_frame"]["simultaneous_lower"] = float(common_lcb[index])
        pair_summary[key]["conjugacy"]["simultaneous_lower"] = float(all_conjugacy_lcb[index])

    main_common,main_conjugacy=_condition_clone_means(main)
    ablation_conditions={"no_remodeling":no_remodel,"no_retention":no_ret,"no_protention":no_prot,"constant_fast_gate":constant_gate,"no_slow_kappa":no_slow_kappa}
    ablations={}
    ablation_rng=np.random.default_rng(config.root_seed+993)
    for name,condition in ablation_conditions.items():
        ab_common,ab_conjugacy=_condition_clone_means(condition)
        common_effect=_paired_bootstrap(
            main_common[validation]-ab_common[validation],ablation_rng,
            config.bootstrap_samples,config.ci_level,
        )
        conjugacy_effect=_paired_bootstrap(
            main_conjugacy[validation]-ab_conjugacy[validation],ablation_rng,
            config.bootstrap_samples,config.ci_level,
        )
        ablations[name]={
            "ablation_common_mean":float(np.mean(ab_common[validation])),
            "ablation_conjugacy_mean":float(np.mean(ab_conjugacy[validation])),
            "paired_reduction_common":common_effect,
            "paired_reduction_conjugacy":conjugacy_effect,
        }

    # Construct checks are reported but excluded from the primary claim.
    construct={}
    for ri,regime in enumerate(REGIME_ORDER):
        upd=main["updates"][validation,ri].reshape(-1,6)
        construct[regime.value]={"mean_kappa":float(np.mean(main["kappa"][validation,ri])),"mean_mismatch":float(np.mean(main["mismatch"][validation,ri])),"mean_coherence":float(np.mean(main["coherence"][validation,ri])),"update_directional_coherence":directional_coherence(upd),"mean_active_alignment":float(np.mean(main["active_alignment"][validation,ri])),"mean_corrective_alignment":float(np.mean(main["corrective_alignment"][validation,ri])),"nominal_stochastic_magnitude_fraction":float(np.sum(np.linalg.norm(main["stoch_updates"][validation,ri],axis=(-2,-1)))/(np.sum(np.linalg.norm(main["det_updates"][validation,ri],axis=(-2,-1)))+np.sum(np.linalg.norm(main["stoch_updates"][validation,ri],axis=(-2,-1)))+1e-15))}

    numerical={"max_unitarity_error":float(main["max_u"]),"max_special_unitary_error":float(main["max_su"]),"max_generator_antihermitian_error":float(main["max_ah"]),"max_generator_traceless_error":float(main["max_tr"]),"projector_idempotence_error":projector_idempotence_error(P0),"projector_hermiticity_error":projector_hermiticity_error(P0)}
    # One reference-integrator cross-check on a held-out clone and the matched probe.
    clone=clones[config.n_pilot_clones]; state=pretrain[config.n_pilot_clones]; theta=theta_from_xi(clone.initial_xi,config)
    cf=integrate_transport(theta,state,base_scale=clone.base_scale,temporal_scale=clone.temporal_scale,kappa_function=_constant_kappa(0.0),n_steps=config.n_steps_probe,config=config).holonomy
    ref=integrate_reference(theta,state,base_scale=clone.base_scale,temporal_scale=clone.temporal_scale,kappa_function=_constant_kappa(0.0),config=config)
    numerical["reference_integrator_error"]=group_distance(cf,ref)
    def probe_generator(t: float):
        coeff=pullback_coefficients(np.array([t]),theta,state,base_scale=clone.base_scale,temporal_scale=clone.temporal_scale,kappa_function=_constant_kappa(0.0),config=config)[0]
        from .algebra import matrix_from_coefficients
        return matrix_from_coefficients(coeff)
    numerical.update(generic_numerical_qc(probe_generator,max(160,config.n_steps_probe)))
    numerical_pass=(numerical["max_unitarity_error"]<config.tol_unitarity and numerical["max_special_unitary_error"]<config.tol_special_unitary and numerical["projector_idempotence_error"]<config.tol_projector and numerical["reference_integrator_error"]<config.tol_reference_integrator and numerical["gauge_covariance_error"]<config.tol_gauge_covariance and numerical["reverse_path_error"]<1e-8)
    design_pass=max(initial)<config.tol_initial_match and ablations["no_remodeling"]["ablation_common_mean"]<config.tol_no_remodeling
    primary_gauge_keys=[f"{REGIME_ORDER[0].value}__{regime.value}" for regime in REGIME_ORDER[1:]]
    stable_common_pass=bool(np.all(common_lcb[primary_indices]>common_threshold))
    all_pair_common_pass=bool(np.all(common_lcb>common_threshold))
    gauge_invariant_primary_pass=bool(np.all(primary_conjugacy_lcb>conjugacy_threshold))
    all_pair_conjugacy_pass=bool(np.all(all_conjugacy_lcb>conjugacy_threshold))
    def supported(name: str, metric: str = "paired_reduction_common") -> bool:
        return bool(ablations[name][metric]["lower"]>0.0)
    summary={"model_scope":{"primary_claim":"Pilot-calibrated endogenous retention-protention histories remodel a shared initial transport law and separate the stable regime from three non-stable regimes under held-out matched probes in a controlled rank-two SU(2) model.","global_four_regime_taxonomy_claim":False,"construct_checks_are_not_emergent_findings":True,"phenomenal_claim":False,"gauge_interpretation":"All branch pairs are reported in a declared shared counterfactual frame. The claim-aligned primary family is the three stable-versus-nonstable contrasts in both common-frame and conjugacy distance; complete pairwise separation of all four regimes is a stricter secondary criterion and is reported separately."},"design":{"pilot_only_ric_calibration":True,"paired_exogenous_streams_for_ablations":True,"pilot_clones":config.n_pilot_clones,"validation_clones":config.n_validation_clones,"repeats":config.n_repeats,"unit_of_inference":"clone","familywise_simultaneous_bounds":True},"ric_reference":{"center":reference.center,"scale":reference.scale},"null_thresholds":{"common_frame":common_threshold,"conjugacy":conjugacy_threshold,"no_remodeling_common_q95":float(np.quantile(null_common,config.null_quantile)),"same_history_independent_repeat_common_q95":float(np.quantile(within_common,config.null_quantile)),"same_history_independent_repeat_conjugacy_q95":float(np.quantile(within_conjugacy,config.null_quantile)),"practical_margin":config.practical_margin},"pairwise_validation":pair_summary,"familywise":{"common_frame_simultaneous_lower":{key:float(value) for key,value in zip(pair_keys,common_lcb,strict=True)},"primary_conjugacy_simultaneous_lower":{pair_keys[index]:float(value) for index,value in zip(primary_indices,primary_conjugacy_lcb,strict=True)},"all_pair_conjugacy_simultaneous_lower":{key:float(value) for key,value in zip(pair_keys,all_conjugacy_lcb,strict=True)}},"reliability":{"max_initial_branch_error":float(max(initial)),"mean_within_regime_repeat_distance":float(np.mean(within)),"mean_between_regime_distance":float(np.mean(between)),"between_within_ratio":reliability_ratio},"construct_checks":construct,"ablations":ablations,"numerical_qc":numerical,"criteria":{"design_pass":bool(design_pass),"numerical_pass":bool(numerical_pass),"stable_vs_nonstable_common_frame_familywise_pass":bool(stable_common_pass),"all_pairs_common_frame_familywise_pass":bool(all_pair_common_pass),"stable_vs_nonstable_conjugacy_familywise_pass":bool(gauge_invariant_primary_pass),"all_pairs_conjugacy_familywise_pass":bool(all_pair_conjugacy_pass),"global_four_regime_taxonomy_supported":bool(all_pair_common_pass and all_pair_conjugacy_pass),"retention_contribution_supported":supported("no_retention"),"protentional_relevance_contribution_supported":supported("no_protention"),"fast_ric_causality_supported":supported("constant_fast_gate"),"slow_ric_contribution_supported":supported("no_slow_kappa"),"overall_pass_for_stable_vs_nonstable_claim":bool(design_pass and numerical_pass and stable_common_pass and gauge_invariant_primary_pass),"overall_pass":bool(design_pass and numerical_pass and stable_common_pass and gauge_invariant_primary_pass)}}
    arrays={"main":main,"no_remodeling":no_remodel,"no_retention":no_ret,"no_protention":no_prot,"constant_gate":constant_gate,"no_slow_kappa":no_slow_kappa,"pilot_indices":np.arange(config.n_pilot_clones),"validation_indices":np.arange(config.n_pilot_clones,config.total_clones)}
    return Stage3Result(config,arrays,summary)
