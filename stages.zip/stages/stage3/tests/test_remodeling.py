import numpy as np
from inh_stage3.config import Stage3Config
from inh_stage3.remodeling import corrective_direction, remodeling_update


def test_corrective_direction_derived_and_orthogonal():
    active=np.ones((2,3)); mapping=np.eye(6,4)
    corr=corrective_direction(np.array([1.,0.]),np.array([0.,1.]),active,mapping)
    assert abs(np.dot(corr.ravel(),active.ravel()/np.linalg.norm(active)))<1e-12


def test_no_remodeling_is_identity():
    cfg=Stage3Config(n_validation_clones=4,n_repeats=2,n_learning_episodes=6,n_steps_learning=12,n_steps_probe=12,bootstrap_samples=50)
    xi=np.zeros((2,3)); active=np.ones((2,3)); corr=np.arange(6).reshape(2,3)
    out=remodeling_update(xi,active,corr,np.ones((2,3)),kappa=1,mismatch=1,coherence=.8,config=cfg,remodeling_enabled=False)
    assert np.allclose(out.theta_after,out.theta_before)
