import numpy as np
from inh_stage3.algebra import I2, T1, special_unitary_error, su2_angle, su2_expm


def test_stable_near_identity_angle():
    u=su2_expm(1e-9*T1)
    assert abs(su2_angle(u)-5e-10)<1e-14


def test_special_unitary_constraint():
    u=su2_expm(0.7*T1)
    assert special_unitary_error(u)<1e-12
    assert np.linalg.norm(u.conj().T@u-I2)<1e-12
