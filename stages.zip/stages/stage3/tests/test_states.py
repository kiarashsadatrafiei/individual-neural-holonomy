import numpy as np
from inh_stage3.config import Regime, Stage3Config
from inh_stage3.states import episode_input, initial_temporal_state, protention_distribution, temporal_descriptors, update_temporal_state


def test_protention_normalized_and_updates():
    cfg=Stage3Config(n_validation_clones=4,n_repeats=2,n_learning_episodes=6,n_steps_learning=12,n_steps_probe=12,bootstrap_samples=50)
    state=initial_temporal_state(); rng=np.random.default_rng(1)
    p=protention_distribution(np.linspace(0,1,11),state,cfg)
    assert np.allclose(np.sum(p,axis=-1),1.0)
    inp=episode_input(Regime.CORRECTIVE,8,rng,cfg)
    desc=temporal_descriptors(state,inp,cfg)
    new=update_temporal_state(state,inp,cfg)
    assert desc["mismatch"]>=0
    assert not np.allclose(new.retention,state.retention)
