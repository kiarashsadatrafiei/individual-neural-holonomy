import pytest
from inh_stage3.config import Stage3Config
from inh_stage3.experiment import run_stage3


@pytest.fixture(scope="module")
def result():
    cfg=Stage3Config(n_pilot_clones=4,n_validation_clones=8,n_repeats=2,n_pretrain_episodes=2,n_learning_episodes=6,n_steps_learning=12,n_steps_probe=16,bootstrap_samples=50,tol_gauge_covariance=1e-4,tol_reference_integrator=1e-5)
    return run_stage3(cfg)


def test_end_to_end_design_and_numerics(result):
    assert result.summary["criteria"]["design_pass"]
    assert result.summary["criteria"]["numerical_pass"]
    assert result.summary["reliability"]["max_initial_branch_error"]<1e-10
    assert result.summary["ablations"]["no_remodeling"]["ablation_common_mean"]<1e-9


def test_retention_and_protention_ablations_are_reported(result):
    assert "no_retention" in result.summary["ablations"]
    assert "no_protention" in result.summary["ablations"]
