from inh_stage3.cli import main

if __name__ == "__main__":
    main()
