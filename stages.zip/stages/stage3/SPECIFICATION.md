# Locked Stage 3 specification

## Causal sequence

1. Shared initialization and neutral pretraining.
2. Controlled branch-specific history schedules.
3. Endogenous update of retention, occupancy beliefs, and relevance weights.
4. Endogenous predictive/protentional mismatch and coherence.
5. Standardized RIC from recurrence support and symbolic dispersion.
6. Fast transport under the current connection.
7. Corrective direction derived from mismatch, not sampled as a target.
8. Slow bounded remodeling in theta-space.
9. Matched neutral probe after every episode.
10. Held-out validation using common-frame and conjugacy-invariant distances.

## Interpretation discipline

The model establishes causal sufficiency within the declared synthetic system. It does not establish biological uniqueness, phenomenality, or empirical identifiability from finite neural recordings.
