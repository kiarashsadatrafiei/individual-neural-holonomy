# Individual Neural Holonomy — Stage 3 v0.4.0

This package implements an endogenous, episode-resolved slow-remodeling model for the manuscript **Individual Neural Holonomy**.

## Scientific scope

All counterfactual branch copies begin with the same temporal state, slow parameters, fiber frame, connection, and probe holonomy. Branches differ only in controlled environmental histories. The code then computes, rather than assigns:

- retention updates;
- predicted occupancy and relevance-weighted protention;
- predictive and protentional mismatch vectors;
- mismatch coherence;
- a standardized RIC closure margin;
- a corrective remodeling direction derived from the mismatch vectors;
- bounded slow connection remodeling in theta-space;
- matched-probe common-frame and conjugacy-invariant holonomy differences.

The primary claim is latent and mechanistic. The package does **not** claim phenomenal differentiation or measurement recoverability from ECoG.

## Run

```bash
python -m pip install -e .[dev]
pytest
inh-stage3 --output results/stage3_confirmatory --strict
```

A faster smoke run is available with `--quick`.

## Primary vs construct-level outputs

Primary outcomes are held-out matched-probe holonomy distances and within/between reliability. Alignment and noise quantities that follow directly from the remodeling rule are labeled construct checks and are not treated as independent discoveries.

## Controls

- full training pipeline with remodeling disabled;
- retention removed;
- protention relevance removed;
- constant fast RIC gate;
- slow RIC input removed;
- numerical SU(2), projector, and reference-integrator checks.
