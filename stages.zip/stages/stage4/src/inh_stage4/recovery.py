from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray
from scipy.signal import butter, hilbert, sosfiltfilt

from inh_stage3.algebra import I2
from .algebra import project_to_su2, project_to_u2, special_unitary_error, unitarity_error

from .config import RecoveryCandidate, Stage4Config
from .observation import ObservationBatch

RealArray = NDArray[np.float64]
ComplexArray = NDArray[np.complex128]


@dataclass(frozen=True)
class PreparedRecovery:
    coordinates: ComplexArray  # regime, estimation trial, time, rank
    singular_values: RealArray
    basis: ComplexArray
    mean: ComplexArray
    frame_trial_indices: NDArray[np.int64]
    estimation_trial_indices: NDArray[np.int64]
    assumed_carrier_hz: float


@dataclass(frozen=True)
class RecoveryResult:
    holonomies: ComplexArray
    scalar_angles: RealArray
    raw_operators: ComplexArray
    max_unitarity_error: float
    max_special_unitary_error: float
    max_condition_number: float


def similarity_invariant_angle(matrix: ComplexArray) -> float:
    """Recover the SU(2) conjugacy angle from a general similarity transform.

    The eigenvalue ratio is invariant under unknown invertible sensor mixing and
    under a common complex scale. For an ideal SU(2) operator its phase is
    exp(2 i theta), so half the principal phase separation estimates theta.
    """
    eigenvalues = np.linalg.eigvals(np.asarray(matrix, dtype=np.complex128))
    if eigenvalues.size != 2 or np.min(np.abs(eigenvalues)) <= 1e-14:
        return float("nan")
    return float(0.5 * abs(np.angle(eigenvalues[0] / eigenvalues[1])))


def prepare_recovery(
    batch: ObservationBatch,
    config: Stage4Config,
    *,
    assumed_carrier_hz: float | None = None,
    latent_rank: int | None = None,
) -> PreparedRecovery:
    signals = np.asarray(batch.signals, dtype=np.float64)
    if signals.ndim != 4:
        raise ValueError("signals must have shape regime, trial, time, channel")
    rank = config.latent_rank if latent_rank is None else int(latent_rank)
    if rank < 1 or rank > signals.shape[-1]:
        raise ValueError("Invalid latent rank")
    carrier = config.carrier_hz if assumed_carrier_hz is None else float(assumed_carrier_hz)
    lower = carrier - config.carrier_bandwidth_hz
    upper = carrier + config.carrier_bandwidth_hz
    if lower <= 0 or upper >= config.sampling_rate_hz / 2:
        raise ValueError("Assumed carrier band is invalid")
    bandpass = butter(4, [lower, upper], btype="bandpass", fs=config.sampling_rate_hz, output="sos")
    lowpass = butter(3, config.envelope_lowpass_hz, btype="lowpass", fs=config.sampling_rate_hz, output="sos")
    filtered = sosfiltfilt(bandpass, signals, axis=2)
    analytic = hilbert(filtered, axis=2)
    seconds = np.arange(signals.shape[2], dtype=np.float64) / config.sampling_rate_hz
    analytic *= np.exp(-1j * 2.0 * np.pi * carrier * seconds)[None, None, :, None]
    envelope = sosfiltfilt(lowpass, analytic, axis=2)

    frame_data = envelope[:, batch.frame_trial_indices]
    flat = frame_data.reshape(-1, frame_data.shape[-1])
    mean = np.mean(flat, axis=0, keepdims=True)
    centered = flat - mean
    _, singular_values, right = np.linalg.svd(centered, full_matrices=False)
    basis = right[:rank].conj().T
    estimation = envelope[:, batch.estimation_trial_indices]
    coordinates = np.einsum("...c,ck->...k", estimation - mean.reshape(1, 1, 1, -1), basis)
    return PreparedRecovery(
        coordinates=np.asarray(coordinates, dtype=np.complex128),
        singular_values=np.asarray(singular_values, dtype=np.float64),
        basis=np.asarray(basis, dtype=np.complex128),
        mean=np.asarray(mean, dtype=np.complex128),
        frame_trial_indices=batch.frame_trial_indices,
        estimation_trial_indices=batch.estimation_trial_indices,
        assumed_carrier_hz=carrier,
    )


def recover_holonomies(prepared: PreparedRecovery, candidate: RecoveryCandidate) -> RecoveryResult:
    coordinates = prepared.coordinates
    if coordinates.shape[-1] != 2:
        raise ValueError("Holonomy recovery is defined for the rank-two primary model")
    if candidate.n_bins + 1 > coordinates.shape[2]:
        raise ValueError("Too many bins for the time grid")
    groups = np.array_split(np.arange(coordinates.shape[2]), candidate.n_bins + 1)
    if any(indices.size == 0 for indices in groups):
        raise ValueError("Empty time bin")
    holonomies = np.empty((coordinates.shape[0], 2, 2), dtype=np.complex128)
    raw_operators = np.empty_like(holonomies)
    scalar_angles = np.empty(coordinates.shape[0], dtype=np.float64)
    max_u = 0.0
    max_su = 0.0
    max_condition = 0.0
    for regime in range(coordinates.shape[0]):
        z = coordinates[regime]
        binned = np.stack([np.mean(z[:, indices], axis=1) for indices in groups], axis=1)
        holonomy = I2.copy()
        for index in range(candidate.n_bins):
            left = binned[:, index].T  # rank, trials
            right = binned[:, index + 1].T
            gram = left @ left.conj().T + candidate.ridge * I2
            max_condition = max(max_condition, float(np.linalg.cond(gram)))
            transition = right @ left.conj().T @ np.linalg.inv(gram)
            if candidate.projection == "step_u2":
                transition = project_to_u2(transition)
            elif candidate.projection == "step_su2":
                transition = project_to_su2(transition)
            elif candidate.projection != "final_su2":
                raise KeyError(candidate.projection)
            holonomy = transition @ holonomy
        raw_operators[regime] = holonomy
        scalar_angles[regime] = similarity_invariant_angle(holonomy)
        holonomy = project_to_su2(holonomy)
        holonomies[regime] = holonomy
        max_u = max(max_u, unitarity_error(holonomy))
        max_su = max(max_su, special_unitary_error(holonomy))
    return RecoveryResult(holonomies, scalar_angles, raw_operators, max_u, max_su, max_condition)
