from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from numpy.typing import NDArray
from scipy.stats import pearsonr, rankdata, spearmanr

RealArray = NDArray[np.float64]


@dataclass(frozen=True)
class Estimate:
    value: float
    lower: float
    upper: float

    def to_dict(self) -> dict[str, float]:
        return {"value": self.value, "lower": self.lower, "upper": self.upper}


def safe_pearson(left: RealArray, right: RealArray) -> float:
    left = np.asarray(left, dtype=np.float64).ravel()
    right = np.asarray(right, dtype=np.float64).ravel()
    if left.size < 3 or np.std(left) <= 1e-14 or np.std(right) <= 1e-14:
        return 0.0
    return float(pearsonr(left, right).statistic)


def safe_spearman(left: RealArray, right: RealArray) -> float:
    left = np.asarray(left, dtype=np.float64).ravel()
    right = np.asarray(right, dtype=np.float64).ravel()
    if left.size < 3 or np.std(left) <= 1e-14 or np.std(right) <= 1e-14:
        return 0.0
    return float(spearmanr(left, right).statistic)


def fit_positive_affine(raw: RealArray, truth: RealArray, min_slope: float = 1e-6) -> tuple[float, float]:
    x = np.asarray(raw, dtype=np.float64).ravel()
    y = np.asarray(truth, dtype=np.float64).ravel()
    variance = float(np.sum((x - np.mean(x)) ** 2))
    slope = min_slope if variance <= 1e-15 else float(np.sum((x - np.mean(x)) * (y - np.mean(y))) / variance)
    slope = max(min_slope, slope)
    intercept = float(np.mean(y) - slope * np.mean(x))
    return intercept, slope


def apply_affine(raw: RealArray, parameters: tuple[float, float]) -> RealArray:
    return parameters[0] + parameters[1] * np.asarray(raw, dtype=np.float64)


def icc_absolute_agreement(values: RealArray) -> float:
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 2:
        raise ValueError("ICC input must be target by repeat")
    n, k = values.shape
    if n < 2 or k < 2:
        raise ValueError("ICC requires at least two targets and two repeats")
    grand = float(np.mean(values))
    row_means = np.mean(values, axis=1)
    column_means = np.mean(values, axis=0)
    ms_row = k * np.sum((row_means - grand) ** 2) / (n - 1)
    ms_col = n * np.sum((column_means - grand) ** 2) / (k - 1)
    residual = values - row_means[:, None] - column_means[None, :] + grand
    ms_error = np.sum(residual * residual) / ((n - 1) * (k - 1))
    denominator = ms_row + (k - 1) * ms_error + k * (ms_col - ms_error) / n
    return 0.0 if abs(denominator) <= 1e-14 else float((ms_row - ms_error) / denominator)


def roc_auc(positive: RealArray, negative: RealArray) -> float:
    positive = np.asarray(positive, dtype=np.float64).ravel()
    negative = np.asarray(negative, dtype=np.float64).ravel()
    combined = np.concatenate((positive, negative))
    ranks = rankdata(combined)
    n_pos = positive.size
    n_neg = negative.size
    rank_sum = np.sum(ranks[:n_pos])
    return float((rank_sum - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def relative_distortion(truth: RealArray, estimate: RealArray) -> float:
    numerator = float(np.linalg.norm(np.asarray(estimate) - np.asarray(truth)))
    denominator = float(np.linalg.norm(np.asarray(truth)))
    return numerator / max(denominator, 1e-15)


def _interval(values: RealArray, ci_level: float) -> tuple[float, float]:
    alpha = (1.0 - ci_level) / 2.0
    lower, upper = np.quantile(values, [alpha, 1.0 - alpha])
    return float(lower), float(upper)


def cluster_bootstrap(
    truth: RealArray,
    estimate: RealArray,
    metric: Callable[[RealArray, RealArray], float],
    *, samples: int,
    ci_level: float,
    rng: np.random.Generator,
) -> Estimate:
    truth = np.asarray(truth, dtype=np.float64)
    estimate = np.asarray(estimate, dtype=np.float64)
    if truth.shape != estimate.shape or truth.ndim < 2:
        raise ValueError("Expected equal clone-indexed arrays")
    observed = metric(truth, estimate)
    boot = np.empty(samples, dtype=np.float64)
    for index in range(samples):
        selected = rng.integers(0, truth.shape[0], size=truth.shape[0])
        boot[index] = metric(truth[selected], estimate[selected])
    lower, upper = _interval(boot, ci_level)
    return Estimate(float(observed), lower, upper)


def nested_calibrated_metrics(
    calibration_raw: RealArray,
    calibration_truth: RealArray,
    validation_raw: RealArray,
    validation_truth: RealArray,
    *,
    min_slope: float,
    samples: int,
    ci_level: float,
    rng: np.random.Generator,
) -> tuple[tuple[float, float], dict[str, Estimate], RealArray]:
    calibration_raw = np.asarray(calibration_raw, dtype=np.float64)
    calibration_truth = np.asarray(calibration_truth, dtype=np.float64)
    validation_raw = np.asarray(validation_raw, dtype=np.float64)
    validation_truth = np.asarray(validation_truth, dtype=np.float64)
    calibration_truth_expanded = np.repeat(calibration_truth[:, None, :], calibration_raw.shape[1], axis=1)
    parameters = fit_positive_affine(calibration_raw, calibration_truth_expanded, min_slope)
    validation_mean = np.mean(validation_raw, axis=1)
    calibrated = apply_affine(validation_mean, parameters)
    metrics = {
        "spearman": safe_spearman(validation_truth, calibrated),
        "pearson": safe_pearson(validation_truth, calibrated),
        "mae": float(np.mean(np.abs(validation_truth - calibrated))),
        "rmse": float(np.sqrt(np.mean((validation_truth - calibrated) ** 2))),
    }
    boot = {name: np.empty(samples, dtype=np.float64) for name in metrics}
    n_cal = calibration_raw.shape[0]
    n_val = validation_raw.shape[0]
    for index in range(samples):
        cal_idx = rng.integers(0, n_cal, size=n_cal)
        val_idx = rng.integers(0, n_val, size=n_val)
        p = fit_positive_affine(calibration_raw[cal_idx], calibration_truth_expanded[cal_idx], min_slope)
        pred = apply_affine(validation_mean[val_idx], p)
        target = validation_truth[val_idx]
        boot["spearman"][index] = safe_spearman(target, pred)
        boot["pearson"][index] = safe_pearson(target, pred)
        boot["mae"][index] = float(np.mean(np.abs(target - pred)))
        boot["rmse"][index] = float(np.sqrt(np.mean((target - pred) ** 2)))
    estimates = {}
    for name, value in metrics.items():
        lower, upper = _interval(boot[name], ci_level)
        estimates[name] = Estimate(value, lower, upper)
    return parameters, estimates, calibrated


def bootstrap_icc(values: RealArray, *, samples: int, ci_level: float, rng: np.random.Generator) -> Estimate:
    values = np.asarray(values, dtype=np.float64)
    observed = icc_absolute_agreement(values)
    boot = np.empty(samples, dtype=np.float64)
    for index in range(samples):
        selected = rng.integers(0, values.shape[0], size=values.shape[0])
        boot[index] = icc_absolute_agreement(values[selected])
    lower, upper = _interval(boot, ci_level)
    return Estimate(observed, lower, upper)


def bootstrap_icc_clustered(
    values: RealArray,
    *,
    samples: int,
    ci_level: float,
    rng: np.random.Generator,
) -> Estimate:
    """Bootstrap ICC while preserving clone-level dependence.

    ``values`` is clone by target-within-clone by repeat.  Resampling flattened
    targets would treat the four branches as independent subjects and produce
    anticonservative intervals; here whole clones are sampled as clusters.
    """
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 3:
        raise ValueError("Clustered ICC input must be clone by target by repeat")
    observed = icc_absolute_agreement(values.reshape(-1, values.shape[-1]))
    boot = np.empty(samples, dtype=np.float64)
    for index in range(samples):
        selected = rng.integers(0, values.shape[0], size=values.shape[0])
        sample = values[selected].reshape(-1, values.shape[-1])
        boot[index] = icc_absolute_agreement(sample)
    lower, upper = _interval(boot, ci_level)
    return Estimate(observed, lower, upper)


def bootstrap_auc(positive: RealArray, negative: RealArray, *, samples: int, ci_level: float, rng: np.random.Generator) -> Estimate:
    positive = np.asarray(positive, dtype=np.float64)
    negative = np.asarray(negative, dtype=np.float64)
    if positive.shape[0] != negative.shape[0]:
        raise ValueError("Positive and null arrays must share clone dimension")
    observed = roc_auc(positive, negative)
    boot = np.empty(samples, dtype=np.float64)
    for index in range(samples):
        selected = rng.integers(0, positive.shape[0], size=positive.shape[0])
        boot[index] = roc_auc(positive[selected], negative[selected])
    lower, upper = _interval(boot, ci_level)
    return Estimate(observed, lower, upper)
