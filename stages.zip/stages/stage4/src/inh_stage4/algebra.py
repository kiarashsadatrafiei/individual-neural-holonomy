from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from inh_stage3.algebra import (
    I2,
    antihermitian_error,
    conjugacy_distance,
    group_distance,
    special_unitary_error,
    su2_angle,
    unitarity_error,
)

ComplexArray = NDArray[np.complex128]


def project_to_u2(matrix: ComplexArray) -> ComplexArray:
    left, _, right = np.linalg.svd(matrix)
    return (left @ right).astype(np.complex128)


def project_to_su2(matrix: ComplexArray) -> ComplexArray:
    unitary = project_to_u2(matrix)
    determinant = np.linalg.det(unitary)
    if abs(determinant) <= 1e-14:
        raise ValueError("Degenerate unitary projection")
    # Principal square root is sufficient for U(2) -> SU(2); sign ambiguity is
    # fixed by choosing the branch closest to the input.
    root = np.sqrt(determinant)
    candidate = unitary / root
    alternative = -candidate
    return candidate.astype(np.complex128) if np.linalg.norm(candidate - matrix) <= np.linalg.norm(alternative - matrix) else alternative.astype(np.complex128)
