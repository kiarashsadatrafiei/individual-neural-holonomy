from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from numpy.typing import NDArray

from inh_stage3.algebra import I2, group_distance, su2_angle

from .config import RecoveryCandidate, Stage4Config
from .lineage import Stage3Export, load_export
from .observation import (
    dynamic_zero_holonomy_path,
    gauge_equivalent_signal_error,
    generate_observation_batch,
)
from .recovery import PreparedRecovery, prepare_recovery, recover_holonomies
from .statistics import (
    Estimate,
    apply_affine,
    bootstrap_auc,
    bootstrap_icc_clustered,
    cluster_bootstrap,
    nested_calibrated_metrics,
    relative_distortion,
    roc_auc,
    safe_pearson,
    safe_spearman,
)

RealArray = NDArray[np.float64]
ComplexArray = NDArray[np.complex128]
PAIRS = tuple(combinations(range(4), 2))


@dataclass(frozen=True)
class RecoveryCollection:
    scalar_changes: RealArray  # clone, repeat, four branches relative to reference
    absolute_angles: RealArray  # clone, repeat, four branches
    reference_angles: RealArray  # clone, repeat
    pairwise: RealArray  # clone, repeat, pair
    max_unitarity_error: float
    max_special_unitary_error: float
    max_condition_number: float
    max_rms_mismatch: float


@dataclass(frozen=True)
class Stage4Result:
    config: Stage4Config
    selected_candidate: RecoveryCandidate
    calibration: dict[str, tuple[float, float]]
    arrays: dict[str, Any]
    pilot_table: list[dict[str, Any]]
    summary: dict[str, Any]


def angles(holonomies: ComplexArray) -> RealArray:
    return np.asarray([su2_angle(item) for item in holonomies], dtype=np.float64)


def pairwise(holonomies: ComplexArray) -> RealArray:
    return np.asarray([group_distance(holonomies[left], holonomies[right]) for left, right in PAIRS], dtype=np.float64)


def truth_arrays(export: Stage3Export, indices: Iterable[int]) -> tuple[RealArray, RealArray, RealArray]:
    selected = np.asarray(tuple(indices), dtype=np.int64)
    true_changes = np.empty((selected.size, 4), dtype=np.float64)
    true_absolute = np.empty((selected.size, 4), dtype=np.float64)
    true_pairs = np.empty((selected.size, len(PAIRS)), dtype=np.float64)
    for local, clone in enumerate(selected):
        branch_angles = angles(export.holonomy[clone])
        reference_angle = su2_angle(export.reference_holonomy[clone])
        true_absolute[local] = branch_angles
        true_changes[local] = branch_angles - reference_angle
        true_pairs[local] = pairwise(export.holonomy[clone])
    return true_changes, true_pairs, true_absolute


def _prepared_batches(
    export: Stage3Export,
    indices: tuple[int, ...],
    config: Stage4Config,
    *,
    null_kind: str | None = None,
    noise_ratio: float | None = None,
    carrier_offset: float = 0.0,
    channel_fraction: float = 1.0,
    mixing_drift: float = 0.0,
    repeats: int | None = None,
    independent_session: bool = False,
) -> tuple[list[list[PreparedRecovery]], float]:
    repeats = config.n_observation_repeats if repeats is None else repeats
    collection: list[list[PreparedRecovery]] = []
    max_rms = 0.0
    count = max(2, int(round(config.n_channels * channel_fraction)))
    channel_indices = np.linspace(0, config.n_channels - 1, count, dtype=np.int64)
    for clone in indices:
        clone_items: list[PreparedRecovery] = []
        for repeat in range(repeats):
            batch = generate_observation_batch(
                export, clone, repeat, config,
                null_kind=null_kind,
                noise_ratio=noise_ratio,
                mixing_drift=mixing_drift,
                channel_indices=channel_indices,
                independent_session=independent_session,
            )
            prepared = prepare_recovery(
                batch, config,
                assumed_carrier_hz=config.carrier_hz + carrier_offset,
            )
            clone_items.append(prepared)
            max_rms = max(max_rms, batch.max_rms_mismatch)
        collection.append(clone_items)
    return collection, max_rms


def _recover_collection(
    prepared: list[list[PreparedRecovery]],
    candidate: RecoveryCandidate,
) -> RecoveryCollection:
    n_clones = len(prepared)
    n_repeats = len(prepared[0])
    scalar_changes = np.empty((n_clones, n_repeats, 4), dtype=np.float64)
    absolute_angles = np.empty_like(scalar_changes)
    reference_angles = np.empty((n_clones, n_repeats), dtype=np.float64)
    pairs = np.empty((n_clones, n_repeats, len(PAIRS)), dtype=np.float64)
    max_u = max_su = max_condition = 0.0
    for clone in range(n_clones):
        for repeat in range(n_repeats):
            recovered = recover_holonomies(prepared[clone][repeat], candidate)
            if recovered.scalar_angles.shape[0] != 5:
                raise ValueError("Expected four branches plus one reference loop")
            absolute_angles[clone, repeat] = recovered.scalar_angles[:4]
            reference_angles[clone, repeat] = recovered.scalar_angles[4]
            scalar_changes[clone, repeat] = recovered.scalar_angles[:4] - recovered.scalar_angles[4]
            pairs[clone, repeat] = pairwise(recovered.holonomies[:4])
            max_u = max(max_u, recovered.max_unitarity_error)
            max_su = max(max_su, recovered.max_special_unitary_error)
            max_condition = max(max_condition, recovered.max_condition_number)
    return RecoveryCollection(scalar_changes, absolute_angles, reference_angles, pairs, max_u, max_su, max_condition, 0.0)


def _candidate_selection(
    export: Stage3Export,
    config: Stage4Config,
) -> tuple[RecoveryCandidate, list[dict[str, Any]], dict[str, RecoveryCollection], float]:
    indices = config.development_indices
    true_changes, true_pairs, _ = truth_arrays(export, indices)
    prepared, rms = _prepared_batches(export, indices, config)
    null_prepared, null_rms = _prepared_batches(export, indices, config, null_kind="dynamic_zero")
    rows: list[dict[str, Any]] = []
    selected: tuple[float, int, float, int, RecoveryCandidate] | None = None
    selected_data: dict[str, RecoveryCollection] = {}
    projection_complexity = {"final_su2": 0, "step_u2": 1, "step_su2": 2}
    for candidate in config.candidates:
        recovered = _recover_collection(prepared, candidate)
        null = _recover_collection(null_prepared, candidate)
        angle_mean = np.mean(recovered.scalar_changes, axis=1)
        pair_mean = np.mean(recovered.pairwise, axis=1)
        angle_spearman = safe_spearman(true_changes, angle_mean)
        pair_spearman = safe_spearman(true_pairs, pair_mean)
        auc = roc_auc(recovered.absolute_angles, null.absolute_angles)
        admissible = bool(
            angle_spearman >= config.min_dev_angle_spearman
            and pair_spearman >= config.min_dev_pairwise_spearman
            and auc >= config.min_dev_dynamic_null_auc
            and recovered.max_unitarity_error < config.tol_unitarity
            and recovered.max_special_unitary_error < config.tol_special_unitary
            and np.isfinite(recovered.max_condition_number)
        )
        score = (1.0 - pair_spearman) + 0.5 * (1.0 - angle_spearman) + 0.25 * (1.0 - auc)
        row = {
            **candidate.to_dict(),
            "label": candidate.label,
            "angle_spearman": angle_spearman,
            "pairwise_spearman": pair_spearman,
            "dynamic_null_auc": auc,
            "max_condition_number": recovered.max_condition_number,
            "max_unitarity_error": recovered.max_unitarity_error,
            "max_special_unitary_error": recovered.max_special_unitary_error,
            "score": score,
            "admissible": admissible,
        }
        rows.append(row)
        key = (score, candidate.n_bins, candidate.ridge, projection_complexity[candidate.projection], candidate)
        if admissible and (selected is None or key[:4] < selected[:4]):
            selected = key
            selected_data = {"observed": recovered, "null": null}
    if selected is None:
        raise RuntimeError("No recovery candidate passed development admissibility")
    return selected[4], rows, selected_data, max(rms, null_rms)


def _calibration_collection(export: Stage3Export, config: Stage4Config, candidate: RecoveryCandidate) -> tuple[RecoveryCollection, float]:
    prepared, rms = _prepared_batches(export, config.calibration_indices, config)
    return _recover_collection(prepared, candidate), rms


def _validation_collections(
    export: Stage3Export,
    config: Stage4Config,
    candidate: RecoveryCandidate,
) -> tuple[RecoveryCollection, RecoveryCollection, RecoveryCollection, float]:
    observed_prepared, rms_obs = _prepared_batches(export, config.validation_indices, config)
    null_prepared, rms_null = _prepared_batches(export, config.validation_indices, config, null_kind="dynamic_zero")
    order_prepared, rms_order = _prepared_batches(export, config.validation_indices, config, null_kind="path_order", repeats=1)
    return (
        _recover_collection(observed_prepared, candidate),
        _recover_collection(null_prepared, candidate),
        _recover_collection(order_prepared, candidate),
        max(rms_obs, rms_null, rms_order),
    )


def _validation_metrics(
    export: Stage3Export,
    config: Stage4Config,
    calibration_collection: RecoveryCollection,
    observed: RecoveryCollection,
    dynamic_null: RecoveryCollection,
) -> tuple[dict[str, tuple[float, float]], dict[str, Any], dict[str, RealArray]]:
    cal_truth_angles, cal_truth_pairs, _ = truth_arrays(export, config.calibration_indices)
    val_truth_angles, val_truth_pairs, val_truth_absolute = truth_arrays(export, config.validation_indices)
    rng = np.random.default_rng(np.random.SeedSequence([config.root_seed, 700]))
    calibration, angle_estimates, calibrated_mean = nested_calibrated_metrics(
        calibration_collection.scalar_changes,
        cal_truth_angles,
        observed.scalar_changes,
        val_truth_angles,
        min_slope=config.min_calibration_slope,
        samples=config.bootstrap_samples,
        ci_level=config.ci_level,
        rng=rng,
    )
    calibrated_repeats = apply_affine(observed.scalar_changes, calibration)
    pair_calibration, pair_estimates, calibrated_pair_mean = nested_calibrated_metrics(
        calibration_collection.pairwise,
        cal_truth_pairs,
        observed.pairwise,
        val_truth_pairs,
        min_slope=config.min_calibration_slope,
        samples=config.bootstrap_samples,
        ci_level=config.ci_level,
        rng=rng,
    )
    calibrated_pair_repeats = apply_affine(observed.pairwise, pair_calibration)
    pair_spearman = pair_estimates["spearman"]
    pair_pearson = pair_estimates["pearson"]
    pair_mae = pair_estimates["mae"]
    pair_distortion = cluster_bootstrap(
        val_truth_pairs, calibrated_pair_mean, relative_distortion,
        samples=config.bootstrap_samples, ci_level=config.ci_level, rng=rng,
    )
    icc_values = calibrated_repeats.transpose(0, 2, 1)
    icc = bootstrap_icc_clustered(
        icc_values, samples=config.bootstrap_samples,
        ci_level=config.ci_level, rng=rng,
    )
    auc = bootstrap_auc(
        observed.absolute_angles.reshape(observed.absolute_angles.shape[0], -1),
        dynamic_null.absolute_angles.reshape(dynamic_null.absolute_angles.shape[0], -1),
        samples=config.bootstrap_samples, ci_level=config.ci_level, rng=rng,
    )
    metrics = {
        "angles": {name: estimate.to_dict() for name, estimate in angle_estimates.items()},
        "pairwise_distance_ordering": {
            "spearman": pair_spearman.to_dict(),
            "pearson": pair_pearson.to_dict(),
            "mae": pair_mae.to_dict(),
            "relative_distortion": pair_distortion.to_dict(),
        },
        "repeat_icc_within_setup_absolute": icc.to_dict(),
        # Backward-compatible alias; interpretation is explicitly within-setup.
        "repeat_icc_absolute": icc.to_dict(),
        "dynamic_zero_holonomy_auc": auc.to_dict(),
    }
    arrays = {
        "truth_angles": val_truth_angles,
        "truth_pairwise": val_truth_pairs,
        "raw_scalar_changes": observed.scalar_changes,
        "absolute_angles": observed.absolute_angles,
        "reference_angles": observed.reference_angles,
        "truth_absolute_angles": val_truth_absolute,
        "calibrated_angles": calibrated_repeats,
        "calibrated_angle_mean": calibrated_mean,
        "estimated_pairwise_raw": observed.pairwise,
        "estimated_pairwise_calibrated": calibrated_pair_repeats,
        "estimated_pairwise_mean_calibrated": calibrated_pair_mean,
        "dynamic_null_absolute_angles": dynamic_null.absolute_angles,
    }
    return {"angle": calibration, "pairwise": pair_calibration}, metrics, arrays


def _stress_metrics(
    export: Stage3Export,
    config: Stage4Config,
    candidate: RecoveryCandidate,
    calibration: dict[str, tuple[float, float]],
) -> dict[str, Any]:
    # Secondary sensitivity analysis uses every confirmatory clone and every
    # observation repeat; uncertainty is clustered by clone.
    indices = tuple(config.validation_indices)
    true_changes, true_pairs, _ = truth_arrays(export, indices)
    output: dict[str, Any] = {"noise": {}, "channels": {}, "carrier_misspecification": {}, "mixing_drift": {}}

    rng = np.random.default_rng(np.random.SeedSequence([config.root_seed, 810]))

    def evaluate(**kwargs: float) -> dict[str, Any]:
        prepared, _ = _prepared_batches(export, indices, config, **kwargs)
        recovered = _recover_collection(prepared, candidate)
        angle = np.mean(apply_affine(recovered.scalar_changes, calibration["angle"]), axis=1)
        pair = np.mean(apply_affine(recovered.pairwise, calibration["pairwise"]), axis=1)
        angle_spearman = cluster_bootstrap(
            true_changes, angle, safe_spearman,
            samples=config.bootstrap_samples, ci_level=config.ci_level, rng=rng,
        )
        angle_mae = cluster_bootstrap(
            true_changes, angle, lambda a,b: float(np.mean(np.abs(a-b))),
            samples=config.bootstrap_samples, ci_level=config.ci_level, rng=rng,
        )
        pair_spearman = cluster_bootstrap(
            true_pairs, pair, safe_spearman,
            samples=config.bootstrap_samples, ci_level=config.ci_level, rng=rng,
        )
        pair_distortion = cluster_bootstrap(
            true_pairs, pair, relative_distortion,
            samples=config.bootstrap_samples, ci_level=config.ci_level, rng=rng,
        )
        return {
            "angle_spearman": angle_spearman.to_dict(),
            "angle_mae": angle_mae.to_dict(),
            "pairwise_spearman": pair_spearman.to_dict(),
            "pairwise_relative_distortion": pair_distortion.to_dict(),
        }

    for value in config.noise_grid:
        output["noise"][f"{value:.3f}"] = evaluate(noise_ratio=value)
    for value in config.channel_fractions:
        output["channels"][f"{value:.3f}"] = evaluate(channel_fraction=value)
    for value in config.carrier_offsets_hz:
        output["carrier_misspecification"][f"{value:.3f}"] = evaluate(carrier_offset=value)
    for value in config.mixing_drift_grid:
        output["mixing_drift"][f"{value:.3f}"] = evaluate(mixing_drift=value)
    return output


def _independent_session_metrics(
    export: Stage3Export,
    config: Stage4Config,
    candidate: RecoveryCandidate,
    calibration: dict[str, tuple[float, float]],
) -> tuple[dict[str, Any], dict[str, RealArray]]:
    """Secondary recovery when mixing, fibers and nuisance vary by session."""
    indices = tuple(config.validation_indices)
    truth_angle, truth_pair, _ = truth_arrays(export, indices)
    prepared, _ = _prepared_batches(
        export, indices, config, independent_session=True,
    )
    recovered = _recover_collection(prepared, candidate)
    angle_repeats = apply_affine(recovered.scalar_changes, calibration["angle"])
    pair_repeats = apply_affine(recovered.pairwise, calibration["pairwise"])
    angle = np.mean(angle_repeats, axis=1)
    pair = np.mean(pair_repeats, axis=1)
    rng = np.random.default_rng(np.random.SeedSequence([config.root_seed, 820]))
    metrics = {
        "scalar_spearman": cluster_bootstrap(
            truth_angle, angle, safe_spearman,
            samples=config.bootstrap_samples, ci_level=config.ci_level, rng=rng,
        ).to_dict(),
        "scalar_mae": cluster_bootstrap(
            truth_angle, angle, lambda a,b: float(np.mean(np.abs(a-b))),
            samples=config.bootstrap_samples, ci_level=config.ci_level, rng=rng,
        ).to_dict(),
        "pairwise_spearman": cluster_bootstrap(
            truth_pair, pair, safe_spearman,
            samples=config.bootstrap_samples, ci_level=config.ci_level, rng=rng,
        ).to_dict(),
        "pairwise_relative_distortion": cluster_bootstrap(
            truth_pair, pair, relative_distortion,
            samples=config.bootstrap_samples, ci_level=config.ci_level, rng=rng,
        ).to_dict(),
        "icc_absolute_across_independent_setups": bootstrap_icc_clustered(
            angle_repeats.transpose(0,2,1), samples=config.bootstrap_samples,
            ci_level=config.ci_level, rng=rng,
        ).to_dict(),
    }
    return metrics, {
        "independent_session_calibrated_angles": angle_repeats,
        "independent_session_calibrated_pairwise": pair_repeats,
    }


def _lineage_and_numerical_qc(export: Stage3Export, config: Stage4Config) -> dict[str, Any]:
    dynamic_endpoint = 0.0
    dynamic_excursion = np.inf
    for clone in config.validation_indices[:2]:
        for regime in range(4):
            path = dynamic_zero_holonomy_path(export.transport[clone, regime])
            dynamic_endpoint = max(dynamic_endpoint, float(np.linalg.norm(path[-1] - I2, ord="fro")))
            excursion = max(group_distance(I2, item) for item in path)
            dynamic_excursion = min(dynamic_excursion, excursion)
    gauge_error = gauge_equivalent_signal_error(export, config.validation_indices[0], config)
    return {
        "stage3_endpoint_error": export.endpoint_error,
        "stage3_max_unitarity_error": export.max_unitarity_error,
        "stage3_max_special_unitary_error": export.max_special_unitary_error,
        "gauge_equivalent_signal_error": gauge_error,
        "dynamic_null_endpoint_error": dynamic_endpoint,
        "dynamic_null_minimum_excursion": float(dynamic_excursion),
        "stage3_source_tree_sha256": export.metadata["stage3_source_tree_sha256"],
        "stage3_anchor_artifact_sha256": export.metadata["stage3_anchor_artifact_sha256"],
        "stage3_export_sha256": export.metadata.get("export_sha256"),
    }


def run_stage4(config: Stage4Config | None = None, *, package_root: str | Path | None = None) -> Stage4Result:
    config = Stage4Config() if config is None else config
    config.validate()
    root = Path(package_root) if package_root is not None else Path(__file__).resolve().parents[2]
    export_path = root / "data" / "stage3_v0.4.0_stage4_cohort_export.npz"
    export = load_export(export_path)
    if export.transport.shape[:2] != (config.n_total_clones, 4) or export.transport.shape[2] != config.n_samples:
        raise ValueError("Stage 3 export does not match the locked Stage 4 cohort")

    selected, pilot_table, development_data, development_rms = _candidate_selection(export, config)
    calibration_collection, calibration_rms = _calibration_collection(export, config, selected)
    observed, dynamic_null, order_surrogate, validation_rms = _validation_collections(export, config, selected)
    calibration, validation, arrays = _validation_metrics(export, config, calibration_collection, observed, dynamic_null)
    independent_session, independent_session_arrays = _independent_session_metrics(
        export, config, selected, calibration,
    )
    stress = _stress_metrics(export, config, selected, calibration)
    qc = _lineage_and_numerical_qc(export, config)
    max_recovery_u = max(observed.max_unitarity_error, dynamic_null.max_unitarity_error, order_surrogate.max_unitarity_error)
    max_recovery_su = max(observed.max_special_unitary_error, dynamic_null.max_special_unitary_error, order_surrogate.max_special_unitary_error)
    qc.update({
        "max_recovery_unitarity_error": max_recovery_u,
        "max_recovery_special_unitary_error": max_recovery_su,
        "max_recovery_condition_number": max(observed.max_condition_number, dynamic_null.max_condition_number),
        "max_rms_mismatch": max(development_rms, calibration_rms, validation_rms),
    })

    angle = validation["angles"]
    pair = validation["pairwise_distance_ordering"]
    numerical_pass = bool(
        qc["stage3_endpoint_error"] < config.tol_stage3_endpoint
        and qc["stage3_max_unitarity_error"] < config.tol_unitarity
        and qc["stage3_max_special_unitary_error"] < config.tol_special_unitary
        and qc["max_recovery_unitarity_error"] < config.tol_unitarity
        and qc["max_recovery_special_unitary_error"] < config.tol_special_unitary
        and qc["gauge_equivalent_signal_error"] < config.tol_gauge_signal
        and qc["dynamic_null_endpoint_error"] < config.tol_dynamic_null_endpoint
        and qc["max_rms_mismatch"] < config.tol_rms_match
    )
    angle_pass = bool(
        angle["spearman"]["lower"] > config.min_angle_spearman_lcb
        and angle["mae"]["upper"] < config.max_angle_mae_ucb
    )
    pair_pass = bool(
        pair["spearman"]["lower"] > config.min_pairwise_spearman_lcb
        and pair["relative_distortion"]["upper"] < config.max_pairwise_relative_distortion_ucb
    )
    reliability_pass = bool(validation["repeat_icc_absolute"]["lower"] > config.min_repeat_icc_lcb)
    null_pass = bool(validation["dynamic_zero_holonomy_auc"]["lower"] > config.min_dynamic_null_auc_lcb)
    summary = {
        "model_scope": {
            "primary_claim": "Cross-fitted recovery of scalar conjugacy angle and within-clone pairwise-distance ordering from controlled synthetic multichannel observations generated by the frozen Stage 3 v0.4.0 transport model.",
            "full_connection_claim": False,
            "real_ecog_claim": False,
            "phenomenal_claim": False,
            "shared_frame_interpretation": "A shared within-clone frame is fitted only on frame-training trials and applied to disjoint estimation trials across all four regimes.",
        },
        "lineage": export.metadata,
        "split": {
            "development_indices": list(config.development_indices),
            "calibration_indices": list(config.calibration_indices),
            "validation_indices": list(config.validation_indices),
            "overlap": False,
        },
        "selected_candidate": selected.to_dict(),
        "calibration": {
            "angle": {"intercept": calibration["angle"][0], "slope": calibration["angle"][1]},
            "pairwise": {"intercept": calibration["pairwise"][0], "slope": calibration["pairwise"][1]},
        },
        "validation": validation,
        "independent_session_generalization": independent_session,
        "path_order_surrogate": {
            "mean_absolute_angle": float(np.mean(order_surrogate.absolute_angles)),
            "mean_observed_absolute_angle": float(np.mean(observed.absolute_angles)),
            "interpretation": "Specificity diagnostic only; it is not a zero-holonomy null.",
        },
        "stress_tests": stress,
        "numerical_and_lineage_qc": qc,
        "criteria": {
            "numerical_and_lineage_pass": numerical_pass,
            "angle_claim_pass": angle_pass,
            "pairwise_ordering_claim_pass": pair_pass,
            "repeat_reliability_pass": reliability_pass,
            "dynamic_null_discrimination_pass": null_pass,
            "overall_pass": bool(numerical_pass and angle_pass and pair_pass and reliability_pass and null_pass),
        },
    }
    arrays.update(independent_session_arrays)
    arrays.update({
        "calibration_scalar_changes": calibration_collection.scalar_changes,
        "development_scalar_changes": development_data["observed"].scalar_changes,
        "development_null_absolute_angles": development_data["null"].absolute_angles,
        "order_surrogate_absolute_angles": order_surrogate.absolute_angles,
    })
    return Stage4Result(config, selected, calibration, arrays, pilot_table, summary)
