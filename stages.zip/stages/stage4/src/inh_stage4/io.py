from __future__ import annotations

import csv
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
from typing import Any

import matplotlib.pyplot as plt
import numpy as np

from . import __version__
from .experiment import Stage4Result
from .lineage import sha256_file, sha256_tree


def _json_default(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(type(value).__name__)


def _write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, default=_json_default), encoding="utf-8")


def _write_pilot_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def _write_validation_csv(path: Path, result: Stage4Result) -> None:
    arrays = result.arrays
    with path.open("w", newline="", encoding="utf-8") as handle:
        fields = [
            "clone_local", "regime", "repeat", "truth_scalar_change",
            "raw_scalar_change", "calibrated_scalar_change", "truth_absolute_angle",
            "estimated_absolute_angle", "reference_angle",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        truth = arrays["truth_angles"]
        truth_abs = arrays["truth_absolute_angles"]
        raw = arrays["raw_scalar_changes"]
        calibrated = arrays["calibrated_angles"]
        absolute = arrays["absolute_angles"]
        reference = arrays["reference_angles"]
        for clone in range(raw.shape[0]):
            for repeat in range(raw.shape[1]):
                for regime in range(4):
                    writer.writerow({
                        "clone_local": clone,
                        "regime": regime,
                        "repeat": repeat,
                        "truth_scalar_change": truth[clone, regime],
                        "raw_scalar_change": raw[clone, repeat, regime],
                        "calibrated_scalar_change": calibrated[clone, repeat, regime],
                        "truth_absolute_angle": truth_abs[clone, regime],
                        "estimated_absolute_angle": absolute[clone, repeat, regime],
                        "reference_angle": reference[clone, repeat],
                    })


def _plot_main(result: Stage4Result, path: Path) -> None:
    arrays = result.arrays
    truth_change = arrays["truth_angles"].ravel()
    estimated_change = arrays["calibrated_angle_mean"].ravel()
    truth_pair = arrays["truth_pairwise"].ravel()
    estimated_pair = arrays["estimated_pairwise_mean_calibrated"].ravel()
    positive = arrays["absolute_angles"].ravel()
    null = arrays["dynamic_null_absolute_angles"].ravel()

    fig, axes = plt.subplots(1, 3, figsize=(14, 4.3))
    axes[0].scatter(truth_change, estimated_change, alpha=0.75)
    low = min(np.min(truth_change), np.min(estimated_change))
    high = max(np.max(truth_change), np.max(estimated_change))
    axes[0].plot([low, high], [low, high], linestyle="--")
    axes[0].set_xlabel("True reference-anchored angle change")
    axes[0].set_ylabel("Recovered calibrated change")
    axes[0].set_title("Scalar conjugacy change")

    axes[1].scatter(truth_pair, estimated_pair, alpha=0.75)
    low = min(np.min(truth_pair), np.min(estimated_pair))
    high = max(np.max(truth_pair), np.max(estimated_pair))
    axes[1].plot([low, high], [low, high], linestyle="--")
    axes[1].set_xlabel("True pairwise distance")
    axes[1].set_ylabel("Recovered calibrated distance")
    axes[1].set_title("Within-clone transport geometry")

    axes[2].hist(positive, bins=20, alpha=0.65, label="Nontrivial paths")
    axes[2].hist(null, bins=20, alpha=0.65, label="Dynamic zero-holonomy null")
    axes[2].set_xlabel("Recovered absolute scalar angle")
    axes[2].set_ylabel("Count")
    axes[2].set_title("Path-dependence discrimination")
    axes[2].legend(frameon=False)
    fig.tight_layout()
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def _plot_stress(result: Stage4Result, path: Path) -> None:
    stress = result.summary["stress_tests"]
    families = [
        ("noise", "Noise ratio", False),
        ("channels", "Retained channel fraction", False),
        ("carrier_misspecification", "Carrier offset (Hz)", False),
        ("mixing_drift", "Mixing drift amplitude", False),
    ]
    fig, axes = plt.subplots(2, 2, figsize=(11, 8))
    for axis, (key, label, reverse) in zip(axes.ravel(), families, strict=True):
        items = sorted((float(value), metrics) for value, metrics in stress[key].items())
        x = np.array([item[0] for item in items])
        angle = np.array([item[1]["angle_spearman"]["value"] for item in items])
        angle_lo = np.array([item[1]["angle_spearman"]["lower"] for item in items])
        angle_hi = np.array([item[1]["angle_spearman"]["upper"] for item in items])
        pair = np.array([item[1]["pairwise_spearman"]["value"] for item in items])
        pair_lo = np.array([item[1]["pairwise_spearman"]["lower"] for item in items])
        pair_hi = np.array([item[1]["pairwise_spearman"]["upper"] for item in items])
        axis.plot(x, angle, marker="o", label="Scalar-change ordering")
        axis.fill_between(x, angle_lo, angle_hi, alpha=.15)
        axis.plot(x, pair, marker="s", label="Pairwise-distance ordering")
        axis.fill_between(x, pair_lo, pair_hi, alpha=.15)
        axis.set_xlabel(label)
        axis.set_ylabel("Spearman correlation")
        axis.set_ylim(-0.05, 1.05)
        if reverse:
            axis.invert_xaxis()
        axis.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)


def _validation_report(result: Stage4Result) -> str:
    summary = result.summary
    validation = summary["validation"]
    criteria = summary["criteria"]
    lines = [
        "# Stage 4 validation report",
        "",
        "## Scope",
        "",
        summary["model_scope"]["primary_claim"],
        "",
        "This stage does not claim recovery of the full connection, real ECoG validity, or experiential differentiation.",
        "",
        "## Frozen lineage",
        "",
        f"- Stage 3 version: `{summary['lineage']['stage3_version']}`",
        f"- Stage 3 source tree SHA256: `{summary['lineage']['stage3_source_tree_sha256']}`",
        f"- Stage 3 anchor artifact SHA256: `{summary['lineage']['stage3_anchor_artifact_sha256']}`",
        f"- Independent Stage 4 cohort seed: `{summary['lineage']['stage3_cohort_seed']}`",
        "- Scientific Stage 3 parameters were frozen; only seed and clone counts changed.",
        "",
        "## Selected claim-matched estimator",
        "",
        f"- Candidate: `{result.selected_candidate.label}`",
        f"- Angle calibration: intercept={result.calibration['angle'][0]:.8f}, slope={result.calibration['angle'][1]:.8f}",
        f"- Pairwise calibration: intercept={result.calibration['pairwise'][0]:.8f}, slope={result.calibration['pairwise'][1]:.8f}",
        "",
        "The shared complex frame was estimated only from frame-training trials and applied to disjoint estimation trials.",
        "",
        "## Confirmatory results",
        "",
        f"- Reference-anchored scalar-change Spearman: {validation['angles']['spearman']['value']:.4f} "
        f"[{validation['angles']['spearman']['lower']:.4f}, {validation['angles']['spearman']['upper']:.4f}]",
        f"- Scalar-change MAE: {validation['angles']['mae']['value']:.6f} "
        f"[{validation['angles']['mae']['lower']:.6f}, {validation['angles']['mae']['upper']:.6f}]",
        f"- Pairwise-distance Spearman: {validation['pairwise_distance_ordering']['spearman']['value']:.4f} "
        f"[{validation['pairwise_distance_ordering']['spearman']['lower']:.4f}, {validation['pairwise_distance_ordering']['spearman']['upper']:.4f}]",
        f"- Pairwise relative distortion: {validation['pairwise_distance_ordering']['relative_distortion']['value']:.4f} "
        f"[{validation['pairwise_distance_ordering']['relative_distortion']['lower']:.4f}, {validation['pairwise_distance_ordering']['relative_distortion']['upper']:.4f}]",
        f"- Within-setup absolute-agreement ICC: {validation['repeat_icc_absolute']['value']:.4f} "
        f"[{validation['repeat_icc_absolute']['lower']:.4f}, {validation['repeat_icc_absolute']['upper']:.4f}]",
        f"- Dynamic zero-holonomy AUC: {validation['dynamic_zero_holonomy_auc']['value']:.4f} "
        f"[{validation['dynamic_zero_holonomy_auc']['lower']:.4f}, {validation['dynamic_zero_holonomy_auc']['upper']:.4f}]",
        "",
        "## Decision",
        "",
        f"`overall_pass = {criteria['overall_pass']}`",
        "",
        "## Interpretation limits",
        "",
        "- Scalar recovery is reference-anchored within subject; it is not an unrestricted absolute cross-subject connection estimate.",
        "- Pairwise results concern within-clone distance ordering and calibrated distortion in a declared shared frame.",
        "- The observation model is controlled synthetic multichannel data, not a validated model of all ECoG acquisition effects.",
        "- Full connection identifiability remains outside the estimand.",
    ]
    return "\n".join(lines) + "\n"


def _sha256_sums(directory: Path) -> None:
    rows = []
    for file in sorted(directory.iterdir()):
        if file.is_file() and file.name != "SHA256SUMS.txt":
            rows.append(f"{sha256_file(file)}  {file.name}")
    (directory / "SHA256SUMS.txt").write_text("\n".join(rows) + "\n", encoding="utf-8")


def save_result(result: Stage4Result, output: str | Path, *, package_root: str | Path | None = None) -> Path:
    destination = Path(output)
    destination.mkdir(parents=True, exist_ok=True)
    root = Path(package_root) if package_root is not None else Path(__file__).resolve().parents[2]

    _write_json(destination / "config.json", result.config.to_dict())
    _write_json(destination / "summary.json", result.summary)
    _write_pilot_csv(destination / "development_candidate_table.csv", result.pilot_table)
    _write_validation_csv(destination / "validation_clone_metrics.csv", result)
    np.savez_compressed(destination / "recovery_arrays.npz", **result.arrays)
    (destination / "VALIDATION_REPORT.md").write_text(_validation_report(result), encoding="utf-8")
    _plot_main(result, destination / "INH_Stage4_Main_Figure.png")
    _plot_stress(result, destination / "INH_Stage4_Stress_Tests.png")

    config_bytes = json.dumps(result.config.to_dict(), sort_keys=True, default=_json_default).encode()
    manifest = {
        "version": __version__,
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "root_seed": result.config.root_seed,
        "config_sha256": hashlib.sha256(config_bytes).hexdigest(),
        "source_tree_sha256": sha256_tree(root / "src" / "inh_stage4"),
        "stage3_source_tree_sha256": result.summary["lineage"]["stage3_source_tree_sha256"],
        "stage3_anchor_artifact_sha256": result.summary["lineage"]["stage3_anchor_artifact_sha256"],
        "stage3_cohort_export_sha256": sha256_file(root / "data" / "stage3_v0.4.0_stage4_cohort_export.npz"),
        "selected_candidate": result.selected_candidate.to_dict(),
        "criteria": result.summary["criteria"],
        "blas_threads": {
            "OPENBLAS_NUM_THREADS": os.environ.get("OPENBLAS_NUM_THREADS"),
            "OMP_NUM_THREADS": os.environ.get("OMP_NUM_THREADS"),
            "MKL_NUM_THREADS": os.environ.get("MKL_NUM_THREADS"),
        },
    }
    _write_json(destination / "manifest.json", manifest)
    _sha256_sums(destination)
    return destination
