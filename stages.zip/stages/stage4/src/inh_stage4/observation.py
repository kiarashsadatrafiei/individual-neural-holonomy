from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray

from inh_stage3.algebra import I2
from .algebra import project_to_su2

from .config import Stage4Config
from .lineage import Stage3Export

RealArray = NDArray[np.float64]
ComplexArray = NDArray[np.complex128]


@dataclass(frozen=True)
class CloneObservationSetup:
    clone_id: int
    initial_fibers: ComplexArray  # trial, 2
    mixing: ComplexArray  # channel, 2
    mixing_drift: ComplexArray  # channel, 2
    nuisance_frequencies: RealArray
    nuisance_phases: RealArray


@dataclass(frozen=True)
class ObservationBatch:
    signals: RealArray  # regime, trial, time, channel
    rms_by_regime: RealArray
    max_rms_mismatch: float
    frame_trial_indices: NDArray[np.int64]
    estimation_trial_indices: NDArray[np.int64]


def _conditioned_mixing(rng: np.random.Generator, n_channels: int, condition: float) -> ComplexArray:
    left, _ = np.linalg.qr(rng.normal(size=(n_channels, 2)) + 1j * rng.normal(size=(n_channels, 2)))
    right, _ = np.linalg.qr(rng.normal(size=(2, 2)) + 1j * rng.normal(size=(2, 2)))
    singular = np.array([1.0, 1.0 / max(condition, 1.0)], dtype=np.float64)
    matrix = left[:, :2] @ np.diag(singular) @ right.conj().T
    matrix /= np.sqrt(np.mean(np.abs(matrix) ** 2))
    return matrix.astype(np.complex128)


def make_clone_setup(
    clone_id: int,
    repeat: int,
    config: Stage4Config,
    *,
    independent_session: bool = False,
) -> CloneObservationSetup:
    # Primary repeats share the same latent mixing/fibers and vary measurement
    # noise only.  The optional secondary design varies the full setup by
    # session so the two reliability questions are not conflated.
    session_token = repeat if independent_session else 0
    rng = np.random.default_rng(
        np.random.SeedSequence([config.root_seed, 110, clone_id, session_token])
    )
    raw = rng.normal(size=(config.n_trials, 2)) + 1j * rng.normal(size=(config.n_trials, 2))
    # Ensure well-conditioned trial coverage of the rank-two fiber.
    q, _ = np.linalg.qr(raw.T)
    basis = q.T
    if basis.shape[0] < config.n_trials:
        extra = rng.normal(size=(config.n_trials - basis.shape[0], 2)) + 1j * rng.normal(size=(config.n_trials - basis.shape[0], 2))
        extra /= np.linalg.norm(extra, axis=1, keepdims=True)
        fibers = np.vstack([basis, extra])
    else:
        fibers = basis[: config.n_trials]
    fibers /= np.linalg.norm(fibers, axis=1, keepdims=True)
    mixing = _conditioned_mixing(rng, config.n_channels, config.mixing_condition_target)
    drift = _conditioned_mixing(rng, config.n_channels, max(1.5, config.mixing_condition_target))
    drift -= mixing * (np.vdot(mixing, drift) / max(np.vdot(mixing, mixing), 1e-15))
    drift /= np.sqrt(np.mean(np.abs(drift) ** 2)) + 1e-15
    nuisance_frequencies = rng.uniform(1.0, 12.0, size=3)
    nuisance_phases = rng.uniform(0.0, 2.0 * np.pi, size=(3, config.n_channels))
    return CloneObservationSetup(clone_id, fibers.astype(np.complex128), mixing, drift, nuisance_frequencies, nuisance_phases)


def _pink_noise(rng: np.random.Generator, shape: tuple[int, ...], exponent: float) -> RealArray:
    n = shape[-2]
    frequencies = np.fft.rfftfreq(n)
    scale = np.ones_like(frequencies)
    scale[1:] = frequencies[1:] ** (-0.5 * exponent)
    white = rng.normal(size=shape)
    spectrum = np.fft.rfft(white, axis=-2)
    spectrum *= scale.reshape((1,) * (spectrum.ndim - 2) + (scale.size, 1))
    colored = np.fft.irfft(spectrum, n=n, axis=-2)
    colored -= np.mean(colored, axis=-2, keepdims=True)
    colored /= np.std(colored, axis=-2, keepdims=True) + 1e-12
    return colored.astype(np.float64)


def _nuisance(setup: CloneObservationSetup, config: Stage4Config) -> RealArray:
    times = np.arange(config.n_samples, dtype=np.float64) / config.sampling_rate_hz
    terms = []
    for index, frequency in enumerate(setup.nuisance_frequencies):
        terms.append(np.sin(2.0 * np.pi * frequency * times[:, None] + setup.nuisance_phases[index][None, :]))
    nuisance = np.mean(np.stack(terms), axis=0)
    nuisance /= np.std(nuisance) + 1e-12
    return nuisance.astype(np.float64)


def interpolate_su2_path(path: ComplexArray, progress: RealArray) -> ComplexArray:
    progress = np.clip(np.asarray(progress, dtype=np.float64), 0.0, 1.0)
    position = progress * (path.shape[0] - 1)
    lower = np.floor(position).astype(int)
    upper = np.minimum(lower + 1, path.shape[0] - 1)
    weight = position - lower
    output = np.empty((progress.size, 2, 2), dtype=np.complex128)
    for index in range(progress.size):
        output[index] = project_to_su2((1.0 - weight[index]) * path[lower[index]] + weight[index] * path[upper[index]])
    return output


def dynamic_zero_holonomy_path(path: ComplexArray) -> ComplexArray:
    """Traverse the observed path and its exact reverse with identity endpoint.

    The construction reuses exact SU(2) samples rather than interpolating and
    reprojecting them, preserving local dynamics while remaining inexpensive.
    """
    n = path.shape[0]
    half = (n + 1) // 2
    indices = np.rint(np.linspace(0, n - 1, half)).astype(np.int64)
    forward = path[indices]
    reverse = forward[-2::-1]
    output = np.concatenate((forward, reverse), axis=0)
    if output.shape[0] != n:
        output = output[:n]
    output[0] = I2
    output[-1] = I2
    return output.astype(np.complex128)


def path_order_surrogate(path: ComplexArray, rng: np.random.Generator) -> ComplexArray:
    # Preserve the multiset of local SU(2) increments while permuting their order.
    increments = np.array([path[index + 1] @ path[index].conj().T for index in range(path.shape[0] - 1)])
    order = rng.permutation(increments.shape[0])
    output = np.empty_like(path)
    output[0] = I2
    for index, source in enumerate(order):
        output[index + 1] = increments[source] @ output[index]
    return output


def _signals_from_paths(
    paths: ComplexArray,
    setup: CloneObservationSetup,
    repeat: int,
    config: Stage4Config,
    *,
    noise_ratio: float | None = None,
    actual_carrier_hz: float | None = None,
    mixing_drift: float = 0.0,
    channel_indices: NDArray[np.int64] | None = None,
) -> ObservationBatch:
    noise_ratio = config.main_noise_ratio if noise_ratio is None else float(noise_ratio)
    carrier_hz = config.carrier_hz if actual_carrier_hz is None else float(actual_carrier_hz)
    times = np.arange(config.n_samples, dtype=np.float64) / config.sampling_rate_hz
    carrier = np.exp(1j * 2.0 * np.pi * carrier_hz * times)
    drift_phase = np.sin(2.0 * np.pi * times / max(times[-1], 1e-12))
    mixing_t = setup.mixing[None, :, :] + mixing_drift * drift_phase[:, None, None] * setup.mixing_drift[None, :, :]
    nuisance = _nuisance(setup, config)
    shared_rng = np.random.default_rng(np.random.SeedSequence([config.root_seed, 220, setup.clone_id, repeat]))
    shared_pink = _pink_noise(shared_rng, (config.n_trials, config.n_samples, config.n_channels), config.pink_exponent)
    signals = np.empty((paths.shape[0], config.n_trials, config.n_samples, config.n_channels), dtype=np.float64)
    rms = np.empty(paths.shape[0], dtype=np.float64)
    shared_weight = np.sqrt(config.shared_pink_fraction)
    independent_weight = np.sqrt(max(0.0, 1.0 - config.shared_pink_fraction))
    for regime in range(paths.shape[0]):
        fiber = np.einsum("tij,rj->rti", paths[regime], setup.initial_fibers)
        envelope = np.einsum("tci,rti->rtc", mixing_t, fiber)
        signal = np.real(envelope * carrier[None, :, None]) + config.nuisance_scale * nuisance[None, :, :]
        signal /= np.std(signal) + 1e-12
        independent_rng = np.random.default_rng(np.random.SeedSequence([config.root_seed, 230, setup.clone_id, repeat, regime, int(round(noise_ratio * 1000))]))
        independent_pink = _pink_noise(independent_rng, signal.shape, config.pink_exponent)
        signal += noise_ratio * (shared_weight * shared_pink + independent_weight * independent_pink)
        signal += config.white_noise_ratio * independent_rng.normal(size=signal.shape)
        signal *= config.target_rms / (np.sqrt(np.mean(signal * signal)) + 1e-12)
        signals[regime] = signal
        rms[regime] = np.sqrt(np.mean(signal * signal))
    if channel_indices is not None:
        signals = signals[..., np.asarray(channel_indices, dtype=np.int64)]
    frame = np.arange(config.n_frame_trials, dtype=np.int64)
    estimate = np.arange(config.n_frame_trials, config.n_trials, dtype=np.int64)
    return ObservationBatch(signals, rms, float(np.ptp(rms)), frame, estimate)


def generate_observation_batch(
    export: Stage3Export,
    clone_index: int,
    repeat: int,
    config: Stage4Config,
    *,
    null_kind: str | None = None,
    noise_ratio: float | None = None,
    actual_carrier_hz: float | None = None,
    mixing_drift: float = 0.0,
    channel_indices: NDArray[np.int64] | None = None,
    independent_session: bool = False,
) -> ObservationBatch:
    setup = make_clone_setup(
        int(export.clone_ids[clone_index]), repeat, config,
        independent_session=independent_session,
    )
    paths = np.concatenate((export.transport[clone_index], export.reference_transport[clone_index][None, ...]), axis=0)
    if null_kind == "dynamic_zero":
        paths = np.stack([dynamic_zero_holonomy_path(path) for path in paths])
    elif null_kind == "identity":
        paths = np.repeat(I2[None, None, :, :], paths.shape[0] * config.n_samples, axis=0).reshape(paths.shape[0], config.n_samples, 2, 2)
    elif null_kind == "path_order":
        rng = np.random.default_rng(np.random.SeedSequence([config.root_seed, 240, clone_index, repeat]))
        paths = np.stack([path_order_surrogate(path, rng) for path in paths])
    elif null_kind is not None:
        raise KeyError(null_kind)
    return _signals_from_paths(paths, setup, repeat, config, noise_ratio=noise_ratio, actual_carrier_hz=actual_carrier_hz, mixing_drift=mixing_drift, channel_indices=channel_indices)


def gauge_equivalent_signal_error(export: Stage3Export, clone_index: int, config: Stage4Config) -> float:
    setup = make_clone_setup(int(export.clone_ids[clone_index]), 0, config)
    rng = np.random.default_rng(np.random.SeedSequence([config.root_seed, 999, clone_index]))
    # Generate and project a random complex matrix to SU(2).
    matrix = rng.normal(size=(2, 2)) + 1j * rng.normal(size=(2, 2))
    gauge = project_to_su2(matrix)
    path = export.transport[clone_index, 0]
    transformed_path = np.einsum("ij,tjk,kl->til", gauge.conj().T, path, gauge)
    transformed_fibers = np.einsum("ij,rj->ri", gauge.conj().T, setup.initial_fibers)
    transformed_mixing = setup.mixing @ gauge
    original_fiber = np.einsum("tij,rj->rti", path, setup.initial_fibers)
    transformed_fiber = np.einsum("tij,rj->rti", transformed_path, transformed_fibers)
    original = np.einsum("rti,ci->rtc", original_fiber, setup.mixing)
    transformed = np.einsum("rti,ci->rtc", transformed_fiber, transformed_mixing)
    return float(np.max(np.abs(original - transformed)))
