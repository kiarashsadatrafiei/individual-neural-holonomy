from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
from numpy.typing import NDArray

from inh_stage3.algebra import I2, special_unitary_error, su2_expm, unitarity_error
from inh_stage3.config import REGIME_ORDER, Stage3Config
from inh_stage3.experiment import _pretrain_state, _simulate_branch, make_clones
from inh_stage3.ric import calibrate_reference
from inh_stage3.states import TemporalState
from inh_stage3.transport import integrate_transport, pullback_coefficients

from .config import Stage4Config

RealArray = NDArray[np.float64]
ComplexArray = NDArray[np.complex128]


@dataclass(frozen=True)
class Stage3Export:
    transport: ComplexArray  # clone, regime, time, 2, 2
    holonomy: ComplexArray  # clone, regime, 2, 2
    stage3_reported_holonomy: ComplexArray
    reference_transport: ComplexArray  # clone, time, 2, 2
    reference_holonomy: ComplexArray
    final_theta: RealArray  # clone, regime, 2, 3
    final_retention: RealArray
    final_occupancy_logits: RealArray
    final_relevance_logits: RealArray
    neutral_retention: RealArray
    neutral_occupancy_logits: RealArray
    neutral_relevance_logits: RealArray
    base_scale: RealArray
    temporal_scale: RealArray
    clone_ids: NDArray[np.int64]
    endpoint_error: float
    max_unitarity_error: float
    max_special_unitary_error: float
    metadata: dict[str, Any]


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_tree(path: str | Path, pattern: str = "*.py") -> str:
    root = Path(path)
    digest = hashlib.sha256()
    for file in sorted(root.rglob(pattern)):
        digest.update(str(file.relative_to(root)).encode())
        digest.update(file.read_bytes())
    return digest.hexdigest()


def _constant_zero(times: RealArray) -> RealArray:
    return np.zeros(np.asarray(times).shape, dtype=np.float64)


def transport_path(
    theta: RealArray,
    state: TemporalState,
    *,
    base_scale: float,
    temporal_scale: float,
    config3: Stage3Config,
    n_samples: int,
) -> tuple[ComplexArray, float, float, float]:
    """High-resolution probe path using the frozen Stage 3 CF4 integrator."""
    n_steps = n_samples - 1
    dt = 1.0 / n_steps
    sqrt3 = np.sqrt(3.0)
    c1, c2 = 0.5 - sqrt3 / 6.0, 0.5 + sqrt3 / 6.0
    b1, b2 = (3.0 - 2.0 * sqrt3) / 12.0, (3.0 + 2.0 * sqrt3) / 12.0
    starts = np.arange(n_steps, dtype=np.float64) * dt
    g1 = pullback_coefficients(
        starts + c1 * dt, theta, state, base_scale=base_scale,
        temporal_scale=temporal_scale, kappa_function=_constant_zero, config=config3,
    )
    g2 = pullback_coefficients(
        starts + c2 * dt, theta, state, base_scale=base_scale,
        temporal_scale=temporal_scale, kappa_function=_constant_zero, config=config3,
    )
    path = np.empty((n_samples, 2, 2), dtype=np.complex128)
    path[0] = I2
    current = I2.copy()
    max_u = 0.0
    max_su = 0.0
    for index in range(n_steps):
        left = -dt * (b1 * g1[index] + b2 * g2[index])
        right = -dt * (b2 * g1[index] + b1 * g2[index])
        from inh_stage3.algebra import matrix_from_coefficients
        step = su2_expm(matrix_from_coefficients(left)) @ su2_expm(matrix_from_coefficients(right))
        current = step @ current
        path[index + 1] = current
        max_u = max(max_u, unitarity_error(current))
        max_su = max(max_su, special_unitary_error(current))
    reference = integrate_transport(
        theta, state, base_scale=base_scale, temporal_scale=temporal_scale,
        kappa_function=_constant_zero, n_steps=n_steps, config=config3,
    ).holonomy
    endpoint_error = float(np.linalg.norm(path[-1] - reference, ord="fro"))
    return path, endpoint_error, max_u, max_su


def frozen_stage3_config(config: Stage4Config) -> Stage3Config:
    # All scientific parameters retain the Stage 3 v0.4.0 defaults. Only cohort
    # seed and clone counts differ for an independent Stage 4 cohort.
    return replace(
        Stage3Config(),
        root_seed=config.stage3_cohort_seed,
        n_pilot_clones=max(2, config.n_development_clones),
        n_validation_clones=config.n_total_clones - max(2, config.n_development_clones),
        n_repeats=2,
    )


def generate_export(config: Stage4Config, package_root: str | Path) -> Stage3Export:
    root = Path(package_root)
    config3 = frozen_stage3_config(config)
    config3.validate()
    rng = np.random.default_rng(config3.root_seed)
    clones = make_clones(config3, rng)
    pretrain: list[TemporalState] = []
    raw_ric: list[float] = []
    for clone in clones:
        pretrain_rng = np.random.default_rng(
            np.random.SeedSequence([config3.root_seed, 302, clone.clone_id])
        )
        state, values = _pretrain_state(config3, clone, pretrain_rng)
        pretrain.append(state)
        if clone.clone_id < config3.n_pilot_clones:
            raw_ric.extend(values)
    reference = calibrate_reference(np.asarray(raw_ric, dtype=np.float64), config3)

    n_clones = len(clones)
    n_regimes = len(REGIME_ORDER)
    transport = np.empty((n_clones, n_regimes, config.n_samples, 2, 2), dtype=np.complex128)
    holonomy = np.empty((n_clones, n_regimes, 2, 2), dtype=np.complex128)
    reported = np.empty_like(holonomy)
    final_theta = np.empty((n_clones, n_regimes, 2, 3), dtype=np.float64)
    reference_transport = np.empty((n_clones, config.n_samples, 2, 2), dtype=np.complex128)
    reference_holonomy = np.empty((n_clones, 2, 2), dtype=np.complex128)
    final_retention = np.empty((n_clones, n_regimes, 2), dtype=np.float64)
    final_occupancy = np.empty((n_clones, n_regimes, 4), dtype=np.float64)
    final_relevance = np.empty_like(final_occupancy)
    neutral_retention = np.stack([state.retention for state in pretrain])
    neutral_occupancy = np.stack([state.occupancy_logits for state in pretrain])
    neutral_relevance = np.stack([state.relevance_logits for state in pretrain])
    endpoint_error = 0.0
    max_u = 0.0
    max_su = 0.0

    for clone_index, clone in enumerate(clones):
        from inh_stage3.remodeling import theta_from_xi
        initial_theta = theta_from_xi(clone.initial_xi, config3)
        reference_path, error, local_u, local_su = transport_path(
            initial_theta, pretrain[clone_index], base_scale=clone.base_scale,
            temporal_scale=clone.temporal_scale, config3=config3,
            n_samples=config.n_samples,
        )
        reference_transport[clone_index] = reference_path
        reference_holonomy[clone_index] = reference_path[-1]
        endpoint_error = max(endpoint_error, error)
        max_u = max(max_u, local_u)
        max_su = max(max_su, local_su)
        for regime_index, regime in enumerate(REGIME_ORDER):
            branch = _simulate_branch(
                clone, regime, 0, pretrain[clone_index], clone.initial_xi,
                reference, config3,
            )
            theta = np.asarray(branch["theta"][-1], dtype=np.float64)
            final_theta[clone_index, regime_index] = theta
            final_retention[clone_index, regime_index] = branch["retention"][-1]
            final_occupancy[clone_index, regime_index] = branch["occupancy"][-1]
            final_relevance[clone_index, regime_index] = branch["relevance"][-1]
            path, error, local_u, local_su = transport_path(
                theta, pretrain[clone_index], base_scale=clone.base_scale,
                temporal_scale=clone.temporal_scale, config3=config3,
                n_samples=config.n_samples,
            )
            transport[clone_index, regime_index] = path
            holonomy[clone_index, regime_index] = path[-1]
            reported[clone_index, regime_index] = branch["holonomies"][-1]
            endpoint_error = max(endpoint_error, error)
            max_u = max(max_u, local_u)
            max_su = max(max_su, local_su)

    anchor_path = root / "data" / "stage3_v0.4.0_anchor_episode_trajectories.npz"
    anchor_config_path = root / "data" / "stage3_v0.4.0_anchor_config.json"
    anchor_config = json.loads(anchor_config_path.read_text(encoding="utf-8"))
    generated_config = config3.to_dict()
    allowed_changes = {"root_seed", "n_pilot_clones", "n_validation_clones"}
    mismatches = {
        key: {"anchor": anchor_config.get(key), "generated": generated_config.get(key)}
        for key in sorted(set(anchor_config) | set(generated_config))
        if key not in allowed_changes and anchor_config.get(key) != generated_config.get(key)
    }
    if mismatches:
        raise RuntimeError(f"Frozen Stage 3 parameter mismatch: {mismatches}")
    from inh_stage3.algebra import group_distance
    resolution_distance = max(
        group_distance(stage3_reported, high_resolution)
        for stage3_reported, high_resolution in zip(reported.reshape(-1, 2, 2), holonomy.reshape(-1, 2, 2), strict=True)
    )
    stage3_source = root / "src" / "inh_stage3"
    metadata = {
        "stage3_version": "0.4.0",
        "stage3_source_tree_sha256": sha256_tree(stage3_source),
        "stage3_anchor_artifact_sha256": sha256_file(anchor_path),
        "stage3_anchor_config_sha256": sha256_file(anchor_config_path),
        "stage3_cohort_seed": config.stage3_cohort_seed,
        "stage3_frozen_parameters": config3.to_dict(),
        "ric_reference": {"center": reference.center, "scale": reference.scale},
        "ric_reference_calibration": "pilot/development clones only",
        "only_changed_from_confirmatory_design": ["root_seed", "n_pilot_clones", "n_validation_clones"],
        "frozen_parameter_match": True,
        "max_anchor_to_high_resolution_holonomy_distance": float(resolution_distance),
        "regimes": [regime.value for regime in REGIME_ORDER],
    }
    return Stage3Export(
        transport=transport,
        holonomy=holonomy,
        stage3_reported_holonomy=reported,
        reference_transport=reference_transport, reference_holonomy=reference_holonomy,
        final_theta=final_theta,
        final_retention=final_retention,
        final_occupancy_logits=final_occupancy,
        final_relevance_logits=final_relevance,
        neutral_retention=neutral_retention,
        neutral_occupancy_logits=neutral_occupancy,
        neutral_relevance_logits=neutral_relevance,
        base_scale=np.asarray([clone.base_scale for clone in clones], dtype=np.float64),
        temporal_scale=np.asarray([clone.temporal_scale for clone in clones], dtype=np.float64),
        clone_ids=np.asarray([clone.clone_id for clone in clones], dtype=np.int64),
        endpoint_error=endpoint_error,
        max_unitarity_error=max_u,
        max_special_unitary_error=max_su,
        metadata=metadata,
    )


def save_export(export: Stage3Export, path: str | Path) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        destination,
        transport=export.transport,
        holonomy=export.holonomy,
        stage3_reported_holonomy=export.stage3_reported_holonomy,
        reference_transport=export.reference_transport, reference_holonomy=export.reference_holonomy,
        final_theta=export.final_theta,
        final_retention=export.final_retention,
        final_occupancy_logits=export.final_occupancy_logits,
        final_relevance_logits=export.final_relevance_logits,
        neutral_retention=export.neutral_retention,
        neutral_occupancy_logits=export.neutral_occupancy_logits,
        neutral_relevance_logits=export.neutral_relevance_logits,
        base_scale=export.base_scale,
        temporal_scale=export.temporal_scale,
        clone_ids=export.clone_ids,
    )
    destination.with_suffix(".json").write_text(json.dumps({
        **export.metadata,
        "endpoint_error": export.endpoint_error,
        "max_unitarity_error": export.max_unitarity_error,
        "max_special_unitary_error": export.max_special_unitary_error,
        "export_sha256": sha256_file(destination),
    }, indent=2), encoding="utf-8")
    return destination


def load_export(path: str | Path) -> Stage3Export:
    source = Path(path)
    data = np.load(source)
    metadata = json.loads(source.with_suffix(".json").read_text(encoding="utf-8"))
    return Stage3Export(
        transport=data["transport"], holonomy=data["holonomy"],
        stage3_reported_holonomy=data["stage3_reported_holonomy"],
        reference_transport=data["reference_transport"], reference_holonomy=data["reference_holonomy"],
        final_theta=data["final_theta"], final_retention=data["final_retention"],
        final_occupancy_logits=data["final_occupancy_logits"],
        final_relevance_logits=data["final_relevance_logits"],
        neutral_retention=data["neutral_retention"],
        neutral_occupancy_logits=data["neutral_occupancy_logits"],
        neutral_relevance_logits=data["neutral_relevance_logits"],
        base_scale=data["base_scale"], temporal_scale=data["temporal_scale"],
        clone_ids=data["clone_ids"], endpoint_error=float(metadata["endpoint_error"]),
        max_unitarity_error=float(metadata["max_unitarity_error"]),
        max_special_unitary_error=float(metadata["max_special_unitary_error"]),
        metadata=metadata,
    )
