from __future__ import annotations

import argparse
import json
import os
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Stage 4 cross-fitted holonomy recovery")
    parser.add_argument("--output", default="results/stage4_confirmatory")
    parser.add_argument("--quick", action="store_true", help="Use reduced bootstrap and stress grids; cohort/splits remain frozen")
    parser.add_argument("--strict", action="store_true", help="Exit nonzero when confirmatory criteria fail")
    args = parser.parse_args()

    # Reproducible single-threaded linear algebra avoids severe oversubscription
    # on small complex matrix operations.
    os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")

    from .config import Stage4Config
    from .experiment import run_stage4
    from .io import save_result

    config = Stage4Config(
        bootstrap_samples=200,
        candidate_bins=(10, 32),
        candidate_ridges=(1e-3,),
        candidate_projections=("final_su2", "step_su2"),
        noise_grid=(0.14, 0.50),
        channel_fractions=(1.0, 0.25),
        carrier_offsets_hz=(0.0, 4.0),
        mixing_drift_grid=(0.0, 0.12),
    ) if args.quick else Stage4Config()
    result = run_stage4(config)
    output = save_result(result, args.output)
    print(json.dumps(result.summary, indent=2))
    print(f"\nSaved outputs to: {output.resolve()}")
    if args.strict and not result.summary["criteria"]["overall_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
