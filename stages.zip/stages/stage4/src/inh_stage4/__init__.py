"""Stage 4: cross-fitted recovery of selected neural-holonomy invariants."""
__version__ = "0.5.0"
