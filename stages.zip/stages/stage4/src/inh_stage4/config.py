from __future__ import annotations

from dataclasses import asdict, dataclass
from itertools import product
from typing import Any


@dataclass(frozen=True)
class RecoveryCandidate:
    n_bins: int
    ridge: float
    projection: str  # final_su2, step_u2, step_su2

    @property
    def label(self) -> str:
        return f"bins{self.n_bins}_ridge{self.ridge:g}_{self.projection}"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Stage4Config:
    """Locked Stage 4 design.

    Stage 3 model parameters remain frozen. Only the independent cohort seed and
    sample size differ from the Stage 3 confirmatory run.
    """

    root_seed: int = 20260724
    stage3_cohort_seed: int = 20260724

    # Independent Stage 3-derived cohort: development / calibration / confirmatory
    n_development_clones: int = 6
    n_calibration_clones: int = 6
    n_validation_clones: int = 16
    n_latent_repeats: int = 1

    # Synthetic multichannel observation
    n_channels: int = 24
    n_trials: int = 20
    n_frame_trials: int = 8
    n_samples: int = 161  # 160 integration intervals
    sampling_rate_hz: float = 128.0
    carrier_hz: float = 24.0
    carrier_bandwidth_hz: float = 6.0
    envelope_lowpass_hz: float = 4.0
    main_noise_ratio: float = 0.14
    white_noise_ratio: float = 0.03
    shared_pink_fraction: float = 0.45
    pink_exponent: float = 1.0
    nuisance_scale: float = 0.18
    target_rms: float = 1.0
    mixing_condition_target: float = 3.0
    n_observation_repeats: int = 3

    # Recovery candidates selected only on development clones
    candidate_bins: tuple[int, ...] = (10, 20, 32)
    candidate_ridges: tuple[float, ...] = (1e-3, 1e-2)
    candidate_projections: tuple[str, ...] = ("final_su2", "step_su2")
    latent_rank: int = 2

    # Calibration and uncertainty
    bootstrap_samples: int = 20_000
    ci_level: float = 0.95
    min_calibration_slope: float = 1e-6

    # Development admissibility
    min_dev_angle_spearman: float = 0.45
    min_dev_pairwise_spearman: float = 0.55
    min_dev_dynamic_null_auc: float = 0.75

    # Confirmatory criteria use confidence bounds
    min_angle_spearman_lcb: float = 0.72
    max_angle_mae_ucb: float = 0.045
    min_pairwise_spearman_lcb: float = 0.72
    max_pairwise_relative_distortion_ucb: float = 0.65
    min_repeat_icc_lcb: float = 0.70
    min_dynamic_null_auc_lcb: float = 0.85

    # Secondary stress tests (reported, not all required for primary pass)
    noise_grid: tuple[float, ...] = (0.14, 0.30, 0.50)
    channel_fractions: tuple[float, ...] = (1.0, 0.5, 0.25)
    carrier_offsets_hz: tuple[float, ...] = (0.0, 2.0, 4.0)
    mixing_drift_grid: tuple[float, ...] = (0.0, 0.06, 0.12)

    # Numerical / lineage QC
    tol_unitarity: float = 1e-8
    tol_special_unitary: float = 1e-8
    tol_rms_match: float = 1e-10
    tol_gauge_signal: float = 1e-10
    tol_stage3_endpoint: float = 5e-10
    tol_dynamic_null_endpoint: float = 1e-10

    @property
    def n_total_clones(self) -> int:
        return self.n_development_clones + self.n_calibration_clones + self.n_validation_clones

    @property
    def development_indices(self) -> tuple[int, ...]:
        return tuple(range(self.n_development_clones))

    @property
    def calibration_indices(self) -> tuple[int, ...]:
        start = self.n_development_clones
        return tuple(range(start, start + self.n_calibration_clones))

    @property
    def validation_indices(self) -> tuple[int, ...]:
        start = self.n_development_clones + self.n_calibration_clones
        return tuple(range(start, self.n_total_clones))

    @property
    def candidates(self) -> tuple[RecoveryCandidate, ...]:
        return tuple(RecoveryCandidate(*values) for values in product(
            self.candidate_bins, self.candidate_ridges, self.candidate_projections
        ))

    def validate(self) -> None:
        if min(self.n_development_clones, self.n_calibration_clones) < 4 or self.n_validation_clones < 8:
            raise ValueError("Development/calibration require >=4 clones and validation >=8 clones")
        if self.n_observation_repeats < 2:
            raise ValueError("At least two observation repeats are required for reliability")
        if self.n_trials < 12 or not (4 <= self.n_frame_trials <= self.n_trials - 4):
            raise ValueError("Cross-fitted frame and estimation trial counts are insufficient")
        if self.n_channels < 8 or self.n_samples < 129:
            raise ValueError("Observation resolution is insufficient")
        if self.carrier_hz + self.carrier_bandwidth_hz >= self.sampling_rate_hz / 2:
            raise ValueError("Carrier band exceeds Nyquist")
        if self.latent_rank != 2:
            raise ValueError("Primary model is locked to the rank-two complex fiber")
        if self.bootstrap_samples < 200:
            raise ValueError("At least 200 bootstrap samples are required")
        if any(mode not in {"final_su2", "step_u2", "step_su2"} for mode in self.candidate_projections):
            raise ValueError("Unknown projection mode")
        if not all(0 < value <= 1 for value in self.channel_fractions):
            raise ValueError("Channel fractions must lie in (0,1]")

    def to_dict(self) -> dict[str, Any]:
        output = asdict(self)
        output["candidates"] = [candidate.to_dict() for candidate in self.candidates]
        output["development_indices"] = list(self.development_indices)
        output["calibration_indices"] = list(self.calibration_indices)
        output["validation_indices"] = list(self.validation_indices)
        return output
