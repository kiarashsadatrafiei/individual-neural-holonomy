from __future__ import annotations

import argparse
import json
from dataclasses import replace

from .config import Stage3Config
from .experiment import run_stage3
from .io import save_result


def main() -> None:
    parser=argparse.ArgumentParser(description="Run Stage 3 endogenous remodeling validation")
    parser.add_argument("--output",default="results/stage3_confirmatory")
    parser.add_argument("--quick",action="store_true")
    parser.add_argument("--strict",action="store_true")
    args=parser.parse_args()
    config=Stage3Config()
    if args.quick:
        config=replace(config,n_pilot_clones=1,n_validation_clones=4,n_repeats=2,n_pretrain_episodes=2,n_learning_episodes=6,n_steps_learning=12,n_steps_probe=16,bootstrap_samples=80)
    result=run_stage3(config); save_result(result,args.output)
    print(json.dumps(result.summary["criteria"],indent=2))
    if args.strict and not result.summary["criteria"]["overall_pass"]: raise SystemExit(2)

if __name__=="__main__": main()
