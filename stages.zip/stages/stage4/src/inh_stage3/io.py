from __future__ import annotations

import csv
import hashlib
import json
import platform
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np

from .config import REGIME_ORDER
from .experiment import Stage3Result


def _json_default(value: Any):
    if isinstance(value, np.ndarray): return value.tolist()
    if isinstance(value, np.generic): return value.item()
    raise TypeError(type(value).__name__)


def save_result(result: Stage3Result, output_dir: str | Path) -> Path:
    output=Path(output_dir); output.mkdir(parents=True,exist_ok=True)
    (output/"summary.json").write_text(json.dumps(result.summary,indent=2,default=_json_default),encoding="utf-8")
    (output/"config.json").write_text(json.dumps(result.config.to_dict(),indent=2),encoding="utf-8")
    main=result.arrays["main"]
    np.savez_compressed(output/"episode_trajectories.npz",holonomies=main["holonomies"],theta=main["theta"],kappa=main["kappa"],mismatch=main["mismatch"],coherence=main["coherence"],updates=main["updates"],pilot_indices=result.arrays["pilot_indices"],validation_indices=result.arrays["validation_indices"])
    with (output/"clone_level_metrics.csv").open("w",newline="",encoding="utf-8") as handle:
        writer=csv.writer(handle); writer.writerow(["clone","regime","repeat","final_angle","mean_kappa","mean_mismatch","mean_coherence","theta_change"])
        p=result.config.n_pilot_clones
        for c in range(main["holonomies"].shape[0]):
            for r,regime in enumerate(REGIME_ORDER):
                for q in range(result.config.n_repeats):
                    from .algebra import su2_angle
                    writer.writerow([c,regime.value,q,su2_angle(main["holonomies"][c,r,q,-1]),float(np.mean(main["kappa"][c,r,q])),float(np.mean(main["mismatch"][c,r,q])),float(np.mean(main["coherence"][c,r,q])),float(np.linalg.norm(main["theta"][c,r,q,-1]-main["theta"][c,r,q,0]))])
    make_figures(result,output)
    report_lines=["# Stage 3 Validation Report","",f"Overall pass: **{result.summary['criteria']['overall_pass']}**","", "## Scope",result.summary["model_scope"]["primary_claim"],"", "## Key criteria", "```json",json.dumps(result.summary["criteria"],indent=2),"```","", "## Interpretation", "The primary result concerns held-out latent matched-probe transport differentiation after endogenous temporal-state updating and slow remodeling. Construct checks describe implementation behavior and are not treated as independent discoveries. Gauge-invariant conjugacy distances are reported alongside common-frame counterfactual distances."]
    (output/"VALIDATION_REPORT.md").write_text("\n".join(report_lines),encoding="utf-8")
    manifest={"python":platform.python_version(),"platform":platform.platform(),"root_seed":result.config.root_seed,"version":"0.4.0"}
    (output/"manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
    checks=[]
    for path in sorted(output.iterdir()):
        if path.is_file() and path.name!="SHA256SUMS.txt": checks.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}")
    (output/"SHA256SUMS.txt").write_text("\n".join(checks)+"\n",encoding="utf-8")
    return output


def make_figures(result: Stage3Result, output: Path) -> None:
    main=result.arrays["main"]; v=slice(result.config.n_pilot_clones,None); episodes=np.arange(result.config.n_learning_episodes+1)
    fig,axes=plt.subplots(2,2,figsize=(12,9))
    for r,regime in enumerate(REGIME_ORDER):
        theta_change=np.linalg.norm(main["theta"][v,r]-main["theta"][v,r,:,:,0:1] if False else main["theta"][v,r]-main["theta"][v,r,:,:,0:1],axis=(-2,-1))
    # explicit broadcasting
    for r,regime in enumerate(REGIME_ORDER):
        branch_theta=main["theta"][v,r]
        base=branch_theta[:,:,0][:,:,None,:,:]
        change=np.linalg.norm(branch_theta-base,axis=(-2,-1))
        axes[0,0].plot(episodes,np.mean(change,axis=(0,1)),label=regime.value)
        axes[0,1].plot(np.arange(result.config.n_learning_episodes),np.mean(main["kappa"][v,r],axis=(0,1)),label=regime.value)
        axes[1,0].plot(np.arange(result.config.n_learning_episodes),np.mean(main["mismatch"][v,r],axis=(0,1)),label=regime.value)
        axes[1,1].plot(np.arange(result.config.n_learning_episodes),np.mean(main["coherence"][v,r],axis=(0,1)),label=regime.value)
    axes[0,0].set_title("Slow connection remodeling"); axes[0,0].set_ylabel(r"$||\theta_n-\theta_0||_F$")
    axes[0,1].set_title("Endogenous closure margin"); axes[0,1].set_ylabel(r"$\kappa$")
    axes[1,0].set_title("Endogenous mismatch"); axes[1,0].set_ylabel("Mismatch")
    axes[1,1].set_title("Mismatch directional coherence"); axes[1,1].set_ylabel("Coherence")
    for ax in axes.ravel(): ax.set_xlabel("Episode"); ax.legend(fontsize=7); ax.grid(alpha=.2)
    fig.tight_layout(); fig.savefig(output/"INH_Stage3_Main_Figure.png",dpi=300); plt.close(fig)

    labels=[]; common=[]; conj=[]
    for key,val in result.summary["pairwise_validation"].items(): labels.append(key.replace("adaptive_consolidation","stable").replace("corrective_reopening","corrective").replace("rigid_closure","rigid").replace("dispersive_instability","diffuse")); common.append(val["common_frame"]["mean"]); conj.append(val["conjugacy"]["mean"])
    x=np.arange(len(labels)); fig,ax=plt.subplots(figsize=(12,5)); width=.36
    ax.bar(x-width/2,common,width,label="Common-frame"); ax.bar(x+width/2,conj,width,label="Conjugacy-invariant"); ax.axhline(result.summary["null_threshold"],linestyle="--",label="Null threshold"); ax.set_xticks(x,labels,rotation=25,ha="right"); ax.set_ylabel("Final holonomy distance"); ax.set_title("Held-out matched-probe transport differentiation"); ax.legend(); fig.tight_layout(); fig.savefig(output/"INH_Stage3_Transport_Effects.png",dpi=300); plt.close(fig)

    abl=result.summary["ablations"]; fig,ax=plt.subplots(figsize=(9,5)); ax.bar(list(abl.keys()),list(abl.values())); ax.set_ylabel("Mean final common-frame distance"); ax.set_title("Mechanistic ablations"); ax.tick_params(axis="x",rotation=25); fig.tight_layout(); fig.savefig(output/"INH_Stage3_Ablations.png",dpi=300); plt.close(fig)
