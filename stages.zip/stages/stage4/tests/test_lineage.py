from pathlib import Path

from inh_stage4.config import Stage4Config
from inh_stage4.lineage import load_export


def _root() -> Path:
    return Path(__file__).resolve().parents[1]


def test_stage3_export_contract_and_endpoint_qc():
    config = Stage4Config()
    export = load_export(_root() / "data" / "stage3_v0.4.0_stage4_cohort_export.npz")
    assert export.transport.shape == (config.n_total_clones, 4, config.n_samples, 2, 2)
    assert export.reference_transport.shape == (config.n_total_clones, config.n_samples, 2, 2)
    assert export.endpoint_error < config.tol_stage3_endpoint
    assert export.max_unitarity_error < config.tol_unitarity
    assert export.metadata["stage3_version"] == "0.4.0"
    assert export.metadata["only_changed_from_confirmatory_design"] == [
        "root_seed", "n_pilot_clones", "n_validation_clones"
    ]
