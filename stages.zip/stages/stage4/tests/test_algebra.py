import numpy as np

from inh_stage3.algebra import matrix_from_coefficients, su2_expm, su2_angle
from inh_stage4.algebra import project_to_su2
from inh_stage4.recovery import similarity_invariant_angle


def test_similarity_invariant_angle_recovers_su2_conjugacy_angle():
    holonomy = su2_expm(matrix_from_coefficients(np.array([0.21, -0.13, 0.17])))
    sensor = np.array([[1.7 + 0.2j, 0.4 - 0.1j], [0.2 + 0.3j, 0.8 - 0.2j]])
    observed = np.linalg.inv(sensor) @ holonomy @ sensor
    assert abs(similarity_invariant_angle(observed) - su2_angle(holonomy)) < 1e-12


def test_projection_returns_special_unitary_matrix():
    matrix = np.array([[1.2 + 0.1j, 0.3 - 0.2j], [-0.1 + 0.4j, 0.8 + 0.2j]])
    projected = project_to_su2(matrix)
    assert np.linalg.norm(projected.conj().T @ projected - np.eye(2)) < 1e-12
    assert abs(np.linalg.det(projected) - 1.0) < 1e-12
