import os
from pathlib import Path

import pytest

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

from inh_stage4.config import Stage4Config
from inh_stage4.experiment import run_stage4


@pytest.mark.slow
def test_confirmatory_pipeline_passes_locked_quick_design():
    config = Stage4Config(
        bootstrap_samples=200,
        candidate_bins=(10, 32),
        candidate_ridges=(1e-3,),
        candidate_projections=("final_su2", "step_su2"),
        noise_grid=(0.14,),
        channel_fractions=(1.0,),
        carrier_offsets_hz=(0.0,),
        mixing_drift_grid=(0.0,),
    )
    result = run_stage4(config, package_root=Path(__file__).resolve().parents[1])
    assert result.summary["criteria"]["overall_pass"] is True
