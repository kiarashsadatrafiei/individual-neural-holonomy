from pathlib import Path

import numpy as np

from inh_stage3.algebra import I2, group_distance
from inh_stage4.config import Stage4Config
from inh_stage4.lineage import load_export
from inh_stage4.observation import (
    dynamic_zero_holonomy_path,
    gauge_equivalent_signal_error,
    generate_observation_batch,
)


def _data():
    root = Path(__file__).resolve().parents[1]
    return load_export(root / "data" / "stage3_v0.4.0_stage4_cohort_export.npz")


def test_cross_fitted_trials_are_disjoint_and_rms_is_matched():
    config = Stage4Config()
    batch = generate_observation_batch(_data(), 0, 0, config)
    assert set(batch.frame_trial_indices).isdisjoint(set(batch.estimation_trial_indices))
    assert batch.signals.shape[0] == 5  # four branches plus reference loop
    assert batch.max_rms_mismatch < config.tol_rms_match


def test_dynamic_null_has_identity_endpoint_but_nonzero_excursion():
    path = _data().transport[0, 0]
    null = dynamic_zero_holonomy_path(path)
    assert np.linalg.norm(null[-1] - I2) < 1e-12
    assert max(group_distance(I2, item) for item in null) > 0.05


def test_gauge_equivalent_signal_is_unchanged():
    config = Stage4Config()
    assert gauge_equivalent_signal_error(_data(), 0, config) < config.tol_gauge_signal
