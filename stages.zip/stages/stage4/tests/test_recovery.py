from pathlib import Path

import numpy as np

from inh_stage4.config import RecoveryCandidate, Stage4Config
from inh_stage4.lineage import load_export
from inh_stage4.observation import generate_observation_batch
from inh_stage4.recovery import prepare_recovery, recover_holonomies


def test_recovery_uses_disjoint_frame_trials_and_returns_su2_holonomies():
    root = Path(__file__).resolve().parents[1]
    export = load_export(root / "data" / "stage3_v0.4.0_stage4_cohort_export.npz")
    config = Stage4Config()
    batch = generate_observation_batch(export, 0, 0, config)
    prepared = prepare_recovery(batch, config)
    result = recover_holonomies(prepared, RecoveryCandidate(10, 1e-3, "step_su2"))
    assert result.holonomies.shape == (5, 2, 2)
    assert result.scalar_angles.shape == (5,)
    assert np.all(np.isfinite(result.scalar_angles))
    assert result.max_unitarity_error < config.tol_unitarity
    assert result.max_special_unitary_error < config.tol_special_unitary
