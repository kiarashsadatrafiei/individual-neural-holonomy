import pytest

from inh_stage4.config import Stage4Config


def test_default_config_is_valid():
    Stage4Config().validate()


def test_reliability_requires_multiple_observation_repeats():
    with pytest.raises(ValueError):
        Stage4Config(n_observation_repeats=1).validate()
