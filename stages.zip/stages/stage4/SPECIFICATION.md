# Stage 4 locked computational specification

## 1. Lineage contract

The bundled Stage 3 v0.4.0 source is treated as frozen upstream code. Stage 4 may call it and extend its output contract, but may not redefine its scientific equations.

Required export fields:

- `transport[clone, branch, time, 2, 2]`
- `holonomy[clone, branch, 2, 2]`
- `reference_transport[clone, time, 2, 2]`
- `reference_holonomy[clone, 2, 2]`
- final slow and temporal states
- clone scales and identifiers
- source and artifact hashes

Endpoint parity and SU(2) constraints are automatic-fail QC checks.

## 2. Estimands

### 2.1 Reference-anchored scalar conjugacy change

\[
\Delta\theta_{s,r}=\theta(H_{s,r})-\theta(H_{s,\mathrm{ref}}).
\]

The raw scalar estimator uses the phase separation of the two eigenvalues of the unprojected recovered operator. This quantity is invariant under general invertible similarity transformations of the latent coordinate frame.

### 2.2 Pairwise transport distance

For branches represented in the same cross-fitted frame:

\[
d_{s,ij}=d_G(H_{s,i},H_{s,j}).
\]

Both ordering and calibrated metric distortion are reported.

### 2.3 Nontrivial path dependence

Nontrivial-path scores are compared against a dynamic forward–reverse null with identity endpoint.

## 3. Split and information flow

Development, calibration, and confirmatory clone sets are disjoint. Candidate selection never sees calibration or confirmatory clones. Calibration parameters are fit only on calibration clones. Confirmatory uncertainty uses nested resampling of calibration and validation clones.

## 4. Observation frame

The PCA frame is estimated from frame-training trials only. Estimation trials are disjoint. The same fitted frame is applied to all branches and the reference loop for a clone/repeat.

## 5. Recovery

Local complex operators are estimated by ridge regression:

\[
\widehat T_k=Z_{k+1}Z_k^\dagger
\left(Z_kZ_k^\dagger+\lambda I\right)^{-1}.
\]

Candidate projection modes are:

- final SU(2) projection only;
- per-step SU(2) projection.

Candidate choice is frozen on development clones.

## 6. Confirmatory criteria

Confidence-bound criteria are applied to:

- scalar-change Spearman correlation;
- scalar-change MAE;
- pairwise-distance Spearman correlation;
- relative pairwise distortion;
- absolute-agreement ICC;
- dynamic-null AUC.

Numerical, lineage, gauge-signal, RMS, and null-endpoint checks must all pass.

## 7. Claim hierarchy

Passing Stage 4 supports only the selected coarse claims above. It does not imply identifiability of the full connection or all holonomy invariants.
