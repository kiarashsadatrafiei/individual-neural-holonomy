# Individual Neural Holonomy — Stage 4 v0.5.0

## Purpose

Stage 4 tests which **selected holonomy claims** can be recovered from controlled synthetic multichannel observations when the estimator has no access to retention, protention, RIC, connection coefficients, slow-remodeling parameters, or true holonomy.

The primary confirmatory claims are:

1. recovery of **reference-anchored SU(2) conjugacy-angle change**;
2. recovery of **within-clone pairwise transport-distance ordering and calibrated distortion**;
3. repeat reliability;
4. discrimination of nontrivial paths from a **dynamic zero-holonomy null**.

It does not claim recovery of the full connection, validity on real ECoG, or phenomenal differentiation.

## Frozen Stage 3 lineage

The repository bundles the unmodified `inh_stage3` v0.4.0 source and the confirmatory Stage 3 anchor artifact. Stage 4 creates an independent 28-clone cohort with all scientific Stage 3 parameters frozen. Only the cohort seed and clone counts differ.

The Stage 3-derived export contains:

- high-resolution matched-probe transport paths;
- final holonomies;
- pre-remodeling reference transport paths;
- final slow parameters and temporal-state summaries;
- source, anchor-artifact, configuration, and export hashes.

Stage 4 never redefines the Stage 3 retention, protention, RIC, remodeling, or transport equations.

## Split

- 6 development clones: estimator selection only;
- 6 calibration clones: positive-slope angle and pairwise calibration only;
- 16 confirmatory clones: used once for final inference.

No clone overlaps across splits.

## Cross-fitted shared frame

For every clone and observation repeat:

- the complex channel frame is learned from frame-training trials;
- disjoint estimation trials are projected into that frozen frame;
- all four post-history branches and the pre-remodeling reference loop share the same within-clone frame.

The scalar estimand is reference-anchored:

\[
\Delta\theta_{s,r}=\theta(H_{s,r})-\theta(H_{s,\mathrm{ref}}).
\]

This removes clone-specific observation offsets without using confirmatory truth.

## Observation model

The controlled synthetic signals include:

- rank-two complex transported fibers;
- subject-specific complex mixing;
- carrier modulation;
- colored shared and independent noise;
- white sensor noise;
- low-frequency nuisance activity;
- exact RMS matching across branches.

The estimator knows the primary rank and approximate carrier band; stress tests vary noise, retained channels, carrier specification, and time-varying mixing.

## Dynamic null

The null traverses the observed path and then its exact reverse. It contains nonzero local dynamics but ends at identity:

\[
H[\gamma\circ\gamma^{-1}]=I.
\]

This is the primary path-dependence null. A path-order surrogate is reported separately and is not treated as zero holonomy.

## Run

```bash
python -m pip install -e .[test]
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 \
  inh-stage4 --output results/stage4_confirmatory --strict
```

Reduced stress-grid run:

```bash
inh-stage4 --quick --strict
```

## Outputs

- `summary.json`
- `config.json`
- `manifest.json`
- `development_candidate_table.csv`
- `validation_clone_metrics.csv`
- `recovery_arrays.npz`
- `VALIDATION_REPORT.md`
- `INH_Stage4_Main_Figure.png`
- `INH_Stage4_Stress_Tests.png`
- `SHA256SUMS.txt`

## Interpretation limits

- The absolute unrestricted cross-subject scalar holonomy is not the primary estimand; the supported scalar claim is within-subject reference-anchored change.
- Pairwise distances are recovered in a declared shared within-clone frame.
- Projection to SU(2) is a model-based structural assumption and is explicitly recorded in candidate selection.
- Stress analyses are secondary and do not convert this controlled benchmark into real-data validation.
