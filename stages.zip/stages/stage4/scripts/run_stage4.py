#!/usr/bin/env python3
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
from inh_stage4.cli import main

if __name__ == "__main__":
    main()
