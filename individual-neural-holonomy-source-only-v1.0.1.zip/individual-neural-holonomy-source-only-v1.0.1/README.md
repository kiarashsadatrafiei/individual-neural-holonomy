# Individual Neural Holonomy — source code

Source-only implementation of the five-stage computational pipeline.

The repository excludes manuscript text, abstracts, conclusions, figures,
tables, generated numerical results, validation reports, quality-control
outputs, submission files, and author metadata.

## Install

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements-dev.txt
```

## Run data-independent tests

```bash
make test
```

## Regenerate the full computational analysis

```bash
python scripts/run_all.py
```

The run generates all intermediate arrays and numerical outputs locally under
`integrated/`; that directory is ignored by Git.

## Licence

MIT. See `LICENSE`.
